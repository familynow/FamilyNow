'use strict';
app.controller('userMaintenanceController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		$parse, Idle, $sessionStorage){
	
	$scope.sortType="name";
	$scope.getListUsers = function(){
		$scope.showLoader('Fetching Data..')
		$http({
			method : 'GET',
			url : 'userMaintenance/getListUser/'
		}).then(function(response) {
			$scope.hideLoader();
			$scope.userList=response.data;
		})
	};
	$scope.deleteUser = function(userId) {
		$scope.userToDeleteId = userId;
		$scope.showConfirmModal('Delete', 'Do you really want to delete ?',
				$scope.deleteRecord, $scope.onCancel);
	};	
	$scope.deleteRecord = function() {
		$scope.hideConfirmModal();
		$scope.showLoader('Deleting Record..')
    	$http(
				{
					method : 'DELETE',
					url : 'userMaintenance/deleteUser/'
							+ $scope.userToDeleteId
					}).then(function(response) {	
						$scope.hideLoader();
						$state.reload();						
					}, function(errResponse) {
						return $q.reject(errResponse);
					});
	};
	$scope.onCancel = function() { //On Click of Cancel in the confirmation popup
	    $scope.hideConfirmModal();;
    }
})