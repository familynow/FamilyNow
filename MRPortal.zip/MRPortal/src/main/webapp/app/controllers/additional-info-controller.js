'use strict';

app.controller('AdditionalInfoController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse, DateFormatService) {
	
	$scope.config = APP_CONFIG;
	var domainCodes = ["FeedbackRequestedType","ComplaintNarrativeRefCode"];
	InitPageService.initPage($scope, domainCodes);
	$scope.showLoader('Please Wait..');
	$scope.pageInit = function() {
		$stateParams.complaintId = $rootScope.complaint.complaintId;
		
		$http({
					method : 'GET',
					url : 'additionalInfo/questionAnswers/'
							+ $stateParams.complaintId
			}).then(function(response) {
				$scope.additionalInfoData = response.data;
				if(!$scope.additionalInfoData.feedbackTypeCode)
					$scope.additionalInfoData.feedbackTypeCode="NONEREQUESTED";
				$scope.additionalInfoCopy = angular.copy($scope.additionalInfoData);
				$scope.hideLoader();
		});
	}
	
	$scope.saveInfo = function(continueFlag) {
		$scope.showLoader('Saving Data..');
		
		angular.forEach($scope.additionalInfoData.additionalInfoList, function(value, key){
			value.complaintId = $rootScope.complaint.complaintId;
			if(value.narrativeText == null || value.narrativeText == undefined) {
				value.narrativeText = '';
			}
		});
		$scope.additionalInfoCopy = $scope.additionalInfoData;
		
		$http.post(
			 'additionalInfo/answers/',
			 $scope.additionalInfoData).then(							
			 function(response) {
				 $scope.additionalInfoData=response.data;
				 $rootScope.additionalInfoSaved = true;
				 $rootScope.disableSupportingDocs = false;
				 $rootScope.complaint.narrativeDataAvailableFlag = 1;
				 $scope.additionalInfoCopy = angular.copy($scope.additionalInfoData);
				 $scope.hideLoader();
				 if(continueFlag) {
					 $state.transitionTo("mrpApp.supportingDocs", {
						'complaintId' : $stateParams.complaintId
					}, {
						notify : true,
						reload : true
					});
				 }
				else {
					$scope.showModal('Saved Successfully','Additional Information saved','success');
					$scope.scrollToTop();
					$rootScope.additionalInfoDataChanged = false;
				}
			 },function(errResponse) {
					$scope.hideLoader();
					$scope.showModal('Error','Error! Data not saved','error');
					$timeout(function() {
						$scope.closeModal();
					},3000);
					return $q.reject(errResponse);
			}
		);

	}
	
	$scope.cancel = function(){
    	$scope.additionalInfoData={};
    	$rootScope.additionalInfoDataChanged = false;
    	$state.transitionTo("mrpApp.home",{ notify: true ,reload: true});
    };
    
    $scope.$watch('additionalInfoData', function () {
		if($scope.additionalInfoCopy!=undefined && $scope.additionalInfoCopy!=null && $scope.additionalInfoData!=undefined && $scope.additionalInfoData!=null){
			$rootScope.additionalInfoDataChanged = !angular.equals($scope.additionalInfoCopy, $scope.additionalInfoData);
		}
	}, true);
});