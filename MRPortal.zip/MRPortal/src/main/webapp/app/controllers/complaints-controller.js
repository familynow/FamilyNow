'use strict';

app.controller('ComplaintsController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse){
	
	var domainCodes = ["ComplaintStatus","Race","ParticipantRole","PriorityAllegationCategory","DocumentType","YesNo", "IntakeStatus"]; 
	InitPageService.initPage($scope,domainCodes); 
	$scope.config = APP_CONFIG;
	
	
	$scope.getListComplaints = function(){
		$rootScope.viewMode=false;
		$rootScope.showWizard = false;
		$rootScope.complaintSummarySaved=false;
		var userId=$rootScope.userData.userAccountId;
		$scope.sortType = 'createdDate';
		$scope.sortReverse=true;
			
		$http({method: 'GET', url: 'complaint/complaintlist/'+userId })
  		.then(
  			function(response){
  				$scope.reportingPerson ={};
  				$scope.reportingPerson['userAccountId'] = userId;
  				$scope.reportingPerson['complaints']= response.data;
  				$rootScope.allegationSaved = false;
  				angular.forEach(response.data, function(value, key){
  					if(value.complaintStatus == "SUBMITTED"){
  						$http({
  							method : 'GET',
  							url : '/main-web/intake/getScreeningDecision/'+ value.complaintId
  						}).then(function(response) {
  							//$rootScope.complaint.screeningDecision = response.data.screeningDecisionCode;
  							angular.forEach($scope.reportingPerson['complaints'], function(compVal, compKey){
  								if(compVal.complaintId === value.complaintId){
  									compVal.screeningDecision= response.data.screeningDecisionCode;
  									compVal.receivedDate= response.data.receivedDate;
  								}
  							})
  						});
  					}
  				});
  			}
  		);
	}


	$scope.addNew = function(userId){
		$rootScope.complaint={};
		$state.transitionTo("mrpApp.personProfile",{userState:'login',complaintState:'new',userId:userId,complaintId:null});
	}
	$scope.showDetails = function (complaint){
		if(complaint.complaintStatus == "SUBMITTED"){
			$rootScope.viewMode=true;
			$rootScope.complaintSummarySaved=true;
			//if(complaint != null && !$rootScope.complaint)
			$rootScope.complaint=complaint;
			$state.transitionTo("mrpApp.complaintSummary");
		}else{
			$state.transitionTo("mrpApp.personProfile",{userState:'login',complaintState:'edit',complaintId:complaint.complaintId,userId:$scope.reportingPerson.userAccountId,complaint:complaint});
		}
	}
	$rootScope.showBreadcrumbs = false;
	
	/**
	 * Delete complaint
	 */
	$scope.deleteComplaint = function(complaint){
		$scope.deleteComplaintVal = complaint;
		$scope.showConfirmModal('Delete', 'Are you sure, you want to delete the selected complaint?', $scope.comfirmDelete, $scope.calcelConfirmModal );
			
	}; 
	
	
	
	$scope.comfirmDelete = function(){
		$scope.hideConfirmModal();
		$scope.showLoader('Deleting Complaint..');
		$http({
             method:'DELETE',
             url: 'complaint/deletecomplaint/'+$scope.deleteComplaintVal.complaintId,
		 	 }).then(function(response){
		 		$scope.hideLoader();;;
		 		var idx = $scope.reportingPerson['complaints'].indexOf($scope.deleteComplaintVal);
				if (idx != -1) {
					$scope.reportingPerson['complaints'].splice(idx,	1);
				}
				$scope.showModal('Success','Complaint Id '+$scope.deleteComplaintVal.complaintId+' has been deleted successfully.','success');
				$timeout(function() {
					$scope.closeModal();
				},3000);
		 });
	}
	
	
	$scope.calcelConfirmModal = function(complaint){
		$scope.hideConfirmModal();
	}
	
	$scope.sortColum = function(key){
		$scope.sortType=key;
		$scope.sortReverse = !($scope.sortReverse);
	}
});
