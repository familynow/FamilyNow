'use strict';

app.controller('myProfileController', function($rootScope,
		$q, $scope, $state, $stateParams, APP_CONFIG, $http, $location,
		InitPageService,$window,$timeout,$parse) {
	var domainCodes = ["ComplaintStatus", "Gender", "ReferentRole", "ReferentCategory", "State"];
	InitPageService.initPage($scope, domainCodes);
	$scope.getProfileInfo=function(){
		$scope.showLoader('Please Wait..');
		var userId = $rootScope.userData.userAccountId;
		$http({method: 'GET', url: 'reportingPerson/personProfile/'+userId })
  		.then(
  			function(response){
  				$scope.reportingPerson = response.data;
  				if($scope.reportingPerson.contactEmail==null || $scope.reportingPerson.contactEmail=='')
  					$scope.reportingPerson.contactEmail = $scope.reportingPerson.email;
  				
  				if($scope.reportingPerson.stateCode==null)
  					$scope.reportingPerson.stateCode ='';
  				if($scope.reportingPerson.reporterPersonCategory==null)
  					$scope.reportingPerson.reporterPersonCategory ='';
  				if($scope.reportingPerson.reporterPersonRoleCode==null)
  					$scope.reportingPerson.reporterPersonRoleCode ='';
  				if($scope.reportingPerson.genderCode==null)
  					$scope.reportingPerson.genderCode ='';
  				
  				$scope.user = angular.copy($scope.reportingPerson);
  				$rootScope.personProfilechanged = false;
  				$scope.hideLoader();
  			}
  		);
	}
	
	$scope.saveReportingPersonProfile = function(saveStatus,reportingPerson){
		$scope.savingProfileDisable = true;
		reportingPerson.passwordChanged = false;
		if($scope.user.password!=reportingPerson.password){
			reportingPerson.passwordChanged = true;
		}
		var url = 'reportingPerson/saveReportingPersonDetail';
		$http.post(url, reportingPerson)
    	.then(
    			function(response){
    				$window.scrollTo(0, 0);
    				$scope.savingProfileDisable = false;
    				$scope.reportingPerson = response.data;
    				$rootScope.personProfilechanged = false;
    				$scope.user = angular.copy($scope.reportingPerson);
    				if(saveStatus=='save'){
    					$state.transitionTo('mrpApp.home');
    				}
    				$scope.showModal('Success','Person profile is saved successfully.','success');
    				$timeout(function() {
						$scope.closeModal();
					},3000);
    			},
    			function(errResponse){
    				$scope.disableAll = false;
    				$scope.savingProfileDisable = false;
    				$scope.showModal('Error','Error while saving Reporting Person Profile.','error');
    				return $q.reject(errResponse);
    			}
    	);
	}
	
	$scope.cancelReportingPersonProfile = function(reportingPerson){
		if($rootScope.personProfilechanged){
			$scope.showConfirmModal('Warning', 'You have unsaved data on your page. Are you sure you want to cancel?', $scope.cancelBtnSuccess, $scope.cancelBtnCancel);
		}else{
			$rootScope.personProfilechanged = false;
			$state.transitionTo('mrpApp.home');
		}
	}
	
	$scope.cancelBtnSuccess = function() {
		$scope.hideConfirmModal();
		$rootScope.personProfilechanged = false;
		$state.transitionTo('mrpApp.home');
	}
	
	$scope.cancelBtnCancel = function() {
		$scope.hideConfirmModal();
	}
	
	$scope.$watch('reportingPerson', function () {
		if($scope.user!=undefined && $scope.user!=null && $scope.reportingPerson!=undefined && $scope.reportingPerson!=null){
			$rootScope.personProfilechanged = !angular.equals($scope.user, $scope.reportingPerson);
		}
	}, true);

	$scope.numberValidation = function(key,maxlength){
		if ($scope.reportingPerson[key] !='' && /\D/g.test($scope.reportingPerson[key])) 
			$scope.reportingPerson[key] = $scope.reportingPerson[key].replace(/\D/g,'');
		if($scope.reportingPerson[key].length>maxlength)
			$scope.reportingPerson[key] = $scope.reportingPerson[key].substring(0,maxlength);
	}
	
	$scope.lengthValidation = function(){
		var flag = false;
		if($scope.reportingPerson.zipCode!=null && $scope.reportingPerson.zipCode!=undefined){
			if($scope.reportingPerson.zipCode.length<5){
				$scope.ziplength = false;
				return false;
			}else{
				$scope.ziplength = true;
				return true;
			}
			
		}
			return flag;
	}
	
	$scope.focusError = function(){
		var flag = true;
		if($scope.reportingPerson.zipCode!=null && $scope.reportingPerson.zipCode!=undefined){
			$scope.reportingPerson['zipCode'] = $scope.reportingPerson['zipCode'].replace(/\D/g,'');
			if($scope.reportingPerson.zipCode.length!=5){
				$scope.ziplength = false;
				flag = false;
			}else
				$scope.ziplength = true;
				
		}
		if(!$scope.personProfileForm.$valid){
			$scope.scrollToFormError();
			return false;
		}
			return flag;
	}
});
