'use strict';

app.controller('StartguideController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout, $location,
		InitPageService, $parse){
	$http({method: 'GET', url: 'priorityTool/getPriorityTools/' })
	.then(
		function(response){
			$scope.abuseList = response.data;
		}
	);
	$scope.exit = function(){
		var url = $location.$$absUrl;
		window.location.href = url.substring(0,url.indexOf("MRPortal"))+"child-protection-portal";
		
	};
});
