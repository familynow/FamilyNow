'use strict';

app.controller('ReportingPersonController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse) {
	
	$scope.config = APP_CONFIG;
	$rootScope.showBreadcrumbs = true;
	$rootScope.currentState = $state.current.name;
	
	var domainCodes = ["ComplaintStatus", "Gender", "ReferentRole", "ReferentCategory", "State"];
	InitPageService.initPage($scope, domainCodes);
	
	
	$scope.getReportingPersonProfile = function(){
		$rootScope.linkToActive="personProfile";
		$scope.showLoader('Please Wait..');
		var userId="";
		if($stateParams.userId!=null)
			userId = $stateParams.userId;
		else
			userId = $rootScope.userData.userAccountId;
		if($stateParams.complaint!=null){//edit scenario
			$rootScope.complaint=$stateParams.complaint;
			if($rootScope.complaint.complaintStatus=='SUBMITTED'){
				$rootScope.viewMode=true;
			}
			/*var continueLoop=true;
			if($rootScope.complaint && continueLoop){
				angular.forEach($rootScope.complaint.complaintParticipants, function(complaintParticipant){
					if(continueLoop){
						if(complaintParticipant.complaintReferenceName=='1'){
							$rootScope.coplaintName =complaintParticipant.lastName+', '+complaintParticipant.firstName;
							continueLoop=false;
						}
					}
				})
			}*/

		}
			
		
		if($stateParams.complaintState!=null)
			$rootScope.complaintState = $stateParams.complaintState;
		
		if($stateParams.userState!=null)
			$rootScope.userState = $stateParams.userState;
		else
			$rootScope.userState = null;
		
		if($rootScope.userState=='signup' || $rootScope.userState=='editUser'){
			$rootScope.sidebar = '';
		}else{
			$rootScope.sidebar = 'complaint';
		}

		$http({method: 'GET', url: 'reportingPerson/personProfile/'+userId })
  		.then(
  			function(response){
  				$scope.reportingPerson = response.data;
  				if($scope.reportingPerson.contactEmail==null || $scope.reportingPerson.contactEmail=='')
  				$scope.reportingPerson.contactEmail = $scope.reportingPerson.email;
  				
  				if($scope.reportingPerson.stateCode==null)
  					$scope.reportingPerson.stateCode ='';
  				if($scope.reportingPerson.reporterPersonCategory==null)
  					$scope.reportingPerson.reporterPersonCategory ='';
  				if($scope.reportingPerson.reporterPersonRoleCode==null)
  					$scope.reportingPerson.reporterPersonRoleCode ='';
  				if($scope.reportingPerson.genderCode==null)
  					$scope.reportingPerson.genderCode ='';
  				
  				$scope.user = angular.copy($scope.reportingPerson);
  				$rootScope.personProfilechanged = false;
  				$scope.hideLoader();
  			}
  		);
	}
	
	$scope.saveReportingPersonProfile = function(saveStatus,reportingPerson){
		$scope.savingProfileDisable = true;
		reportingPerson.passwordChanged = false;
		if($scope.user.password!=reportingPerson.password){
			reportingPerson.passwordChanged = true;
		}
		var url = 'reportingPerson/saveReportingPersonDetail';
		if($rootScope.userState=='login' && $rootScope.complaintState=='new'){
			var url = 'reportingPerson/updatePersonAndCreateComplaint';
		}
		$http.post(url, reportingPerson)
    	.then(
    			function(response){
    				$window.scrollTo(0, 0);
    				$scope.savingProfileDisable = false;
    				if($rootScope.complaintState=='new'){
      					$rootScope.complaint = response.data['complaint'];
      					$scope.reportingPerson = response.data['userAccount'];
      					$rootScope.complaintState='edit';
      					$rootScope.profileSaved = true;
      				}else{
      					$scope.reportingPerson = response.data;
      				}

    				if(saveStatus=='savecontinue')
    					$state.transitionTo('mrpApp.complaintParticipants');

    				$rootScope.disableParticipant=false;
    				
    				$rootScope.personProfilechanged = false;
    				$scope.user = angular.copy($scope.reportingPerson);
    				if(saveStatus=='save'){
    					if($rootScope.userState=='signup')
    						$state.transitionTo('mrpApp.home');
    					if($rootScope.userState=='editUser')
    						$state.transitionTo('mrpApp.userList');
    				}
    				$scope.showModal('Success','Person profile is saved successfully.','success');
    				$timeout(function() {
						$scope.closeModal();
					},3000);
    			},
    			function(errResponse){
    				$scope.disableAll = false;
    				$scope.savingProfileDisable = false;
    				$scope.showModal('Error','Error while saving Reporting Person Profile.','error');
    				return $q.reject(errResponse);
    			}
    	);
	}
	
	$scope.cancelReportingPersonProfile = function(reportingPerson){
		if($rootScope.personProfilechanged){
			$scope.showConfirmModal('Warning', 'You have unsaved data on your page. Are you sure you want to cancel?', $scope.cancelBtnSuccess, $scope.cancelBtnCancel);
		}else{
			$rootScope.personProfilechanged = false;
			$state.transitionTo('mrpApp.home');
		}
	}
	
	$scope.cancelBtnSuccess = function() {
		$scope.hideConfirmModal();
		$rootScope.personProfilechanged = false;
		$state.transitionTo('mrpApp.home');
	}
	
	$scope.cancelBtnCancel = function() {
		$scope.hideConfirmModal();
	}
	
	$scope.$watch('reportingPerson', function () {
		if($scope.user!=undefined && $scope.user!=null && $scope.reportingPerson!=undefined && $scope.reportingPerson!=null){
			$rootScope.personProfilechanged = !angular.equals($scope.user, $scope.reportingPerson);
		}
	}, true);
	
	$scope.numberValidation = function(key,maxlength){
		if ($scope.reportingPerson[key] !='' && /\D/g.test($scope.reportingPerson[key])) 
			$scope.reportingPerson[key] = $scope.reportingPerson[key].replace(/\D/g,'');
		if($scope.reportingPerson[key].length>maxlength)
			$scope.reportingPerson[key] = $scope.reportingPerson[key].substring(0,maxlength);
	}
	
	$scope.lengthValidation = function(){
		var flag = false;
		if($scope.reportingPerson.zipCode!=null && $scope.reportingPerson.zipCode!=undefined){
			if($scope.reportingPerson.zipCode.length<5){
				$scope.ziplength = false;
				return false;
			}else{
				$scope.ziplength = true;
				return true;
			}
			
		}
			return flag;
	}
	
	$scope.focusError = function(){
		var flag = true;
		if($scope.reportingPerson.zipCode!=null && $scope.reportingPerson.zipCode!=undefined){
			$scope.reportingPerson['zipCode'] = $scope.reportingPerson['zipCode'].replace(/\D/g,'');
			if($scope.reportingPerson.zipCode.length!=5){
				$scope.ziplength = false;
				flag = false;
			}else
				$scope.ziplength = true;
				
		}
		if(!$scope.personProfileForm.$valid){
			$scope.scrollToFormError();
			return false;
		}
			return flag;
	}
});
