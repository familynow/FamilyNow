'use strict';
if (!String.prototype.endsWith) {
   String.prototype.endsWith = function(suffix) {
     return this.indexOf(suffix, this.length - suffix.length) !== -1;
   };
 }
app.controller('reportParticipantController',function($rootScope, $q, $scope, $state, $stateParams, 
		APP_CONFIG, $http, $window, InitPageService,DateFormatService,$timeout,$filter) {
	
	var domainCodes = ["Gender","Suffix","Race","ParticipantRole","State", "YesNo"]; 
	InitPageService.initPage($scope,domainCodes); 
	$scope.config = APP_CONFIG;
	$rootScope.showBreadcrumbs = true;
	$rootScope.currentState = $state.current.name;
	
	/**
	 * listParticipantData object is used to display already added participant list on top of the page
	 * participantData object is used to capture user entered details for a new participant
	 */
	$scope.initReportParticipant = function (){
		$rootScope.participantDataChanged=false;
		$rootScope.linkToActive="participant";
		if(!$scope.saveAndAdd)
			$scope.saveAndAdd=false;
		if(!$scope.editMode){
			$scope.participantData={};
			$scope.participantDataCopy ={};// angular.copy($scope.allegationData);
			$scope.selectedRoles = [];
			$scope.selectedRaces = [];
			$scope.sameAs=null;
			$scope.assembleToDisplay();
			$scope.submitted = false;
		}
		var complaint=$rootScope.complaint;
		
		$http({
				method : 'GET',
				url : 'complaintParticipant/retrieveAllComplaintParticipants/'+ complaint.complaintId
		}).then(function(response) {
			$scope.listParticipantData = response.data.listParticipant;
			$scope.sortType="-complaintParticipantId";
			$scope.assembleToDisplay();
			if($scope.listParticipantData && $scope.listParticipantData.length>0)
				$scope.disableAllegation=false;
			var continueLoop=true;
			if($scope.listParticipantData && continueLoop){
				angular.forEach($scope.listParticipantData, function(complaintParticipant){
					if(continueLoop){
						if(complaintParticipant.complaintReferenceName=='1'){
							$rootScope.complaint.complaintName = complaintParticipant.lastName+', '+complaintParticipant.firstName;
							continueLoop=false;
						}
					}
				})
			}
		},
		function(errResponse){
			
		});
	};
	
	$scope.editParticipant = function(complaintParticipantId){
		$state.transitionTo("mrpApp.editParticipant", {complaintParticipantId:complaintParticipantId, notify: true ,reload: true});
	}
	$scope.$watch('participantProfileForm.$dirty', function() {
		if($scope.participantProfileForm)	
			$rootScope.participantDirty = $scope.participantProfileForm.$dirty;
    });
	$scope.showFormattedValue = function(mobileNumber){
		if(mobileNumber && (mobileNumber.length==3 || mobileNumber.length==7)){
			mobileNumber=mobileNumber+"-";
		}
	}
	$scope.assembleToPersist = function(participantData){
    	// selected races - persist as csv
    	var persistRaces = [];
    	for(var i in $scope.selectedRaces){
    		persistRaces.push($scope.selectedRaces[i].lookupCode);
    	}
    	participantData.raceCode = persistRaces.join(",");
    	// selected roles 
    	var persistRoles = [];
    	for(var i in $scope.selectedRoles){
    		persistRoles.push($scope.selectedRoles[i].lookupCode);
    	}
    	participantData.roleCode = persistRoles.join(",");;
    }
	
	$scope.assembleToDisplay = function(){
    	$scope.availableRaces = [].concat($filter('filter')($scope.refDataService.getRefdata('Race'), {inactiveFlag:0}));
    	//;

    	$scope.availableRoles = [].concat($filter('filter')($scope.refDataService.getRefdata('ParticipantRole'), {inactiveFlag:0}));
		// races from csv to refdata objects - to be shown in moverbox
		if($scope.participantData && !_.isEmpty($scope.participantData.raceCode)){
			var races = $scope.participantData.raceCode.split(",");
			$scope.selectedRaces = [];
			for(var i in races){	
				var item = _.find($scope.availableRaces,function(o){return o.lookupCode===races[i]})
				var idx = $scope.availableRaces.indexOf(item);
	            if (idx != -1) {
	            	$scope.availableRaces.splice(idx, 1);
	            	$scope.selectedRaces.push(item);      
	            }
			}			
		}else{
			$scope.selectedRaces = [];
		}
		// roles
		if($scope.participantData && !_.isEmpty($scope.participantData.roleCode)){
			$scope.selectedRoles = [];
			var roles = $scope.participantData.roleCode.split(",");
			for(var i in roles){
				var item = _.find($scope.availableRoles,function(o){return o.lookupCode===roles[i]})
				var idx = $scope.availableRoles.indexOf(item);
	            if (idx != -1) {
	            	$scope.availableRoles.splice(idx, 1);
	            	$scope.selectedRoles.push(item);      
	            }
			}			
		}else{
			$scope.selectedRoles = [];
		}
	}
	
 	$scope.saveParticipant = function(participantData, action, valid){
 		$scope.submitted = true;
 		var update =false;
 		$scope.saveAndAdd=false;
 		$scope.workNoErr=false;
 		$scope.mobileErr=false;
 		$scope.noRole=false;
 		
 		if(participantData.complaintParticipantId >= 0)
 			update=true
		if(!$scope.selectedRoles || $scope.selectedRoles.length<=0){
			$scope.noRole=true;
			$scope.focusTo("roleErr");
			$('#roleErr').addClass('ng-invalid');
			return;
		}else {
			$('#roleErr').removeClass('ng-invalid');
		}
 		
 		if(participantData.mobileNumber && (""+participantData.mobileNumber).length>0 && (""+participantData.mobileNumber).length<10){
 			$scope.focusTo("mobile");
 			$scope.mobileErr=true;
 		}
 		if(participantData.workNumber && (""+participantData.workNumber).length>0 && (""+participantData.workNumber).length<10){
 			$scope.focusTo("workNumber");
 			$scope.workNoErr=true;
 		}
 		if($scope.workNoErr || $scope.mobileErr){
 			return;
 		}
 		if(valid) {
 			$scope.showLoader('Please Wait');
 			$rootScope.participantDataChanged=false;
	 		var complaint = $rootScope.complaint;
	 		var bDate=participantData.birthDate;
	 		participantData.complaint=complaint;
	 		$scope.assembleToPersist(participantData);
	    	$http.post('complaintParticipant/saveComplaintParticipant/', participantData)
	    	.then(
	    			function(response){   
	    				$rootScope.disableAllegation=false;
	    				$rootScope.participantDataChanged=false;
	    				$scope.scrollToTop();
	    				$scope.hideLoader();
	    				$scope.saveflag = true;
	    				$scope.listParticipantData = response.data.listParticipant;
	    				$rootScope.complaint['complaintParticipants'] = $scope.listParticipantData;
	    				$rootScope.complaint.participantDataAvailableFlag=1;
	    				$rootScope.participantSaved = true;
	    				var msg ="added";
	    				if(update)
	    					msg="updated"
	    				
	    				var id=response.data.complaintParticipant.complaintParticipantId;
	    				var continueLoop=true;
    					if(response.data.listParticipant && continueLoop){
    						angular.forEach(response.data.listParticipant, function(complaintParticipant){
    							if(continueLoop){
    								if(complaintParticipant.complaintReferenceName=='1'){
    									$rootScope.complaint.complaintName =complaintParticipant.lastName+', '+complaintParticipant.firstName;
    									continueLoop=false;
    								}
    							}
    						})
    					}
	    				if(action == 'SAVEANDCONT'){
	    					$scope.selectedRoles = [];
	    					$scope.selectedRaces = [];
	    					$scope.participantData={};
	    					$rootScope.participantDataChanged = false;
	    					$state.transitionTo("mrpApp.allegations",{ notify: true ,reload: true});
	    				}else if(action == 'SAVEANDADD'){
	    					$scope.showModal('Success','Participant Id '+id+' has been '+msg+' successfully.','success');
	    					$scope.participantData={};
	    					$scope.participantDataCopy ={};// angular.copy($scope.allegationData);
	    					$scope.selectedRoles = [];
	    					$scope.selectedRaces = [];
	    					$scope.sameAs=null;
	    					$scope.submitted = true;
	    					$scope.saveAndAdd=true;
	    					$scope.assembleToDisplay();
	    					$rootScope.reset();
	    					$rootScope.participantDataChanged = false;
	    					$state.go("mrpApp.addComplaintParticipants",{ notify: true ,reload: true});
	    				}else if(action == 'SAVE'){
	    					$scope.submitted = false;
	    					$scope.showModal('Success','Participant Id '+id+' has been '+msg+' successfully.','success');
	    					$timeout(function() {
								$scope.closeModal();
							},3000);
	    					$scope.participantData=response.data.complaintParticipant;
	    					$scope.participantData.birthDate=bDate;
	    				}
	    				$scope.participantDataCopy=angular.copy($scope.participantData);
	    				$rootScope.participantDataChanged = false;
	    			},
	    			function(errResponse){
	    				$scope.hideLoader();
	    				$scope.showModal('Failure','An error has occurred while performing your request. Please try again later.','failure');
	    				$timeout(function() {
							$scope.closeModal();
						},3000);
	    			}
	    	);
 		}
 		else {
 			$scope.scrollToFormError();
 		}
    }; 
    
    $scope.populateAddress=function(sameAsValue,participantData){
    	if(sameAsValue != null && sameAsValue>0){
    		$http({
        		method : 'GET',
    			url : 'complaintParticipant/editComplaintParticipant/'+ sameAsValue
        	}).then(function(response){
        		participantData.unknowAddressFlag=response.data.complaintParticipant.unknowAddressFlag;
        		participantData.address_line_1=response.data.complaintParticipant.address_line_1;
        		participantData.address_line_2=response.data.complaintParticipant.address_line_2;
        		participantData.city=response.data.complaintParticipant.city;
        		participantData.stateCode=response.data.complaintParticipant.stateCode;
        		participantData.zipCode=response.data.complaintParticipant.zipCode;
        		//$scope.editMode=true;
        	});
    	}
    }
    $scope.makeComplaintName = function (participantId){
    	$scope.showLoader('Please Wait');
    	$http({
			method : 'GET',
			url : 'complaintParticipant/makeComplaintName/'+ participantId+'/'+ $rootScope.complaint.complaintId
    	}).then(function(response) {
    		$scope.listParticipantData = response.data.listParticipant;
    		var continueLoop=true;
			if($scope.listParticipantData && continueLoop){
				angular.forEach($scope.listParticipantData, function(complaintParticipant){
					if(continueLoop){
						if(complaintParticipant.complaintReferenceName=='1'){
							$rootScope.complaint.complaintName =complaintParticipant.lastName+', '+complaintParticipant.firstName;
							continueLoop=false;
						}
					}
				})
			}
			$scope.hideLoader();
    	});
    }

    $scope.deleteParticipant = function (participantData){
    	if(participantData.complaintReferenceName=='1'){
    		$scope.showModal('Information',"Participant selected as complaint name cannot be deleted.",'Info');
    	}else{
    		$scope.recordToDelete=participantData;
    		$scope.showConfirmModal('Delete', 'Do you really want to delete ?', $scope.deleteRecord, $scope.onCancel);
    	}
    }
    
    
    $scope.clearData = function(participantData){
    	if(participantData != undefined){
    		participantData.address_line_1 ='';
        	participantData.address_line_2 ='';
        	participantData.city ='';
        	participantData.stateCode = '';
        	participantData.zipCode = '';
        	$scope.participantData.sameAs="";
    	}
    }
    $scope.focusTo = function(focusItem){
    	$("#"+focusItem).addClass('ng-invalid');
    	$scope.scrollToFormError();
    }
    $scope.cancel = function(){
    	if($rootScope.participantDataChanged)
    		$scope.showConfirmModal('Cancel', 'You have unsaved data on your page. Are you sure you want to cancel?', $scope.cancelParticipant, $scope.onCancel);
    	else{
    		$scope.participantData={};
        	$state.transitionTo("mrpApp.home",{ notify: true ,reload: true});
    	}
    		
    }
    $scope.cancelParticipant = function(){
    	$scope.hideConfirmModal();
    	$rootScope.participantDataChanged=false;
    	$scope.participantData={};
    	$state.transitionTo("mrpApp.home", {notify: true ,reload: true});
    }
    /*$scope.filterList = function(listParticipantData){
    	return 
    }*/
    
    /***  Confirmation Popup Demo Implementation  ***/
    
    $scope.deleteRecord = function() {
    	$scope.hideConfirmModal();
    	$scope.showLoader('Please Wait');
    	$http({
			method : 'GET',
			url : 'complaintParticipant/deleteParticipant/'+ $scope.recordToDelete.complaintParticipantId+'/'+ $rootScope.complaint.complaintId
    	}).then(function(response) {
    		$scope.listParticipantData = response.data.listParticipant;
    		$scope.hideLoader();
    		$scope.showModal('Success','Participant Id '+$scope.recordToDelete.complaintParticipantId+' has been deleted successfully.','success');
			$timeout(function() {
				$scope.closeModal();
			},3000);
    	});
    }
    
    $scope.onCancel = function() { //On Click of Cancel in the confirmation popup
    	//Do something if need, then
    	//alert('Do your Stuff on cancel');
    	$scope.hideConfirmModal();;
    }
    $scope.$watch('participantData', function () {
		if($scope.participantDataCopy!=undefined && $scope.participantDataCopy!=null && $scope.participantData!=undefined && $scope.participantData!=null){
			$rootScope.participantDataChanged = !angular.equals($scope.participantDataCopy, $scope.participantData);
		}
	}, true);
});