'use strict';

app.controller('SupportingDocsController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse,$filter){ 
	$rootScope.documentchangedFlag = false;
	$rootScope.currentState = $state.current.name;
	$scope.config = APP_CONFIG;
	$scope.YESNOCODE = '';
	var domainCodes = ["DocumentType","YesNo"];
	InitPageService.initPage($scope, domainCodes);
	
	$scope.openFileExplorer = function() { // Open File
		// Explorer by
		// clicking hidden
		// Browse
		$('#js-upload-files').trigger('click');
	}
	
	$scope.fileName = '';
	$scope.file = '';
	$scope.documentList = [];
	$scope.fileSelected;
	
	$scope.saveAndUploadDocument = function(mode){
		$scope.documentOutputOnDisplay.complaintId = $rootScope.complaint.complaintId;
		$scope.documentOutputOnDisplay.fileName = $scope.fileName;
		var requestData = $scope.getRequestData();
		if($scope.fileSelected!=null && $scope.fileSelected!=undefined && $scope.fileSelected!=''){
			$scope.saveAndUploadToDB(requestData,mode)
		}else{
			$scope.saveDocument(requestData,mode);
		}

		// fd.append('file', files[0]);	
	}
	
	/**
	 * Load all document details corresponding to
	 * Complaint. 
	 */
	$scope.initializeDocumentUpload = function(){
		$scope.showLoader('Fetching Data...');
		$scope.showDocDetail = false;
		$scope.YESNOCODE = $rootScope.complaint.supportingDocCode;
		if($rootScope.complaint.supportingDocCode == 'YES')
			$scope.showDocDetail = true;
		$http({method: 'GET', url: 'document/getDocumentList/'+$rootScope.complaint.complaintId })
  		.then(
  			function(response){
  				$scope.hideLoader();
  				$scope.documentList = response.data;
  			}
  		);
	}
	
	/**
	 * file validation
	 */
	
	$scope.fileValidation = function(){
		var flag = true;
		if($scope.fileName==''){
			flag = false
		}
		/*if(!documentOutput.documentDate){
			flag = false;
			$scope.dateValidate = false;
		}else{
			$scope.dateValidate = true;
		}*/
			
		return flag;	
	}
	
	$scope.editDocumentDetails = function(documentOutput){
		$scope.editDocumentDetailOB = documentOutput;
		$scope.documentOutputOnDisplay = angular.copy(documentOutput);
		$scope.fileName = $scope.documentOutputOnDisplay.fileName;
		$scope.$parent.fileName = $scope.documentOutputOnDisplay.fileName;
		$scope.fileSelected = '';
		$scope.documentOutputOnDisplay.documentDate = new Date($scope.documentOutputOnDisplay.documentDate);
		/*$scope.documentOutputOnDisplay.documentDate = date.getMonth()+"/"+date.getDate()+"/"+date.getFullYear();
		
		var idate = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        var imonth = date.getMonth()+1 < 10 ? "0" + (date.getMonth()+1) : date.getMonth()+1;
        var finalDate = '';
        $scope.documentOutputOnDisplay.documentDate = date.getFullYear()+"-"+imonth+"-"+idate;*/
	}
	
	/**
	 * Download File
	 */
	$scope.downloadDocument = function(guid){
		var ull = 'document/download/';
		var deferred = $q.defer();
		$http({method: 'GET', url: ull+guid, responseType: 'arraybuffer'})
  		.then(
  			function(response){
  				var header = response.headers();
  				var contentType = header['content-type'].split(';')[0];
  				var fileName = header['content-disposition'].split(';')[1].replace('filename=','');
  				$scope.blobOb = new Blob([response.data], {type: contentType});
  				var fileURL = URL.createObjectURL($scope.blobOb);
  				saveAs( $scope.blobOb, fileName );
  			    //window.open(fileURL);
  			    //window.open($scope.blobOb);
  			  //deferred.resolve(response);
  			}
  		);
	}
	
	$scope.deleteDocumentOutput = function(documentOutput){
		$scope.documentOutputOb = documentOutput;
		$scope.showConfirmModal('Delete', 'Are you sure, you want to delete the selected Document?', $scope.comfirmDelete, $scope.calcelConfirmModal );	
	}
	
	$scope.comfirmDelete = function(){
		$scope.hideConfirmModal();
		$scope.showLoader('Deleting Document..');
		$http({
             method:'DELETE',
             url: 'document/delete/'+$scope.documentOutputOb.documentId,
		 	 }).then(function(response){
		 		$scope.hideLoader();
		 		$scope.removeDocumentFromList($scope.documentOutputOb);
				$scope.showModal('Success','Document Id '+$scope.documentOutputOb.documentId+' has been deleted successfully.','success');
		 		$scope.documentOutputOb = null;
				$timeout(function() {
					$scope.closeModal();
				},3000);
		 });
	}
	
	$scope.removeDocumentFromList = function(documentOutput){
		var idx = $scope.documentList.indexOf(documentOutput);
		if (idx != -1) {
			$scope.documentList.splice(idx,	1);
		}
	}
	
	$scope.calcelConfirmModal = function(){
		$scope.hideConfirmModal();
	}
	
	$scope.getRequestData = function(){
		var fd = {};
		if($scope.fileSelected!=null && $scope.fileSelected!=undefined && $scope.fileSelected!=''){
			fd.data = new FormData();
			//var blob = new Blob([ $scope.file ]);
			//var file1 = $("#js-upload-files")[0].files[0]; Please don't use this
			fd.data.append("file", $scope.fileSelected);
			var documentStr=JSON.stringify($scope.documentOutputOnDisplay);
			fd.data.append("documentOutput",documentStr);
			fd.url = "document/uploadSupportingDocumentAndSaveOutput/";
		}else{
			fd.data = $scope.documentOutputOnDisplay;
			fd.url = "document/saveDocumentOutput";;
		}
		return fd;
	}
	
	$scope.downloadFile = function (guid){
		var form; // dynamic form that will call controller	
	    form = $('<form />', {
	        action: "document/download/"+guid,
	        method: 'get',
	        style: 'display: none;'
	    });
	    form.appendTo('body').submit();	
	}
	
	$scope.clearData = function(){
		$scope.documentOutputOnDisplay = null;
		$scope.submitted = false;
		$scope.$parent.fileName = '';
		$scope.fileName = '';
		$scope.fileSelected = '';
		$rootScope.documentchangedFlag = false;
	}
	
	$scope.saveDocument = function(requestData,mode){
		$scope.showLoader('Saving...');
		$http.post(requestData.url, requestData.data)
    	.then(
    			function(response){
    				$scope.UIChangeAfterSave(response.data,mode);
    			}
    		);	
	}
	
	$scope.saveAndUploadToDB = function(requestData,mode){
		$scope.showLoader('Saving...');
		$http.post(	requestData.url,requestData.data,
		{
			transformRequest : angular.identity,
			headers : {
				'Content-Type' : undefined
			}
		})
		.then(
				function(response) {
					$scope.UIChangeAfterSave(response.data,mode);		
		});
	}
	
	$scope.UIChangeAfterSave = function(data,mode){
		$scope.hideLoader();
		$rootScope.SupportDocumentsSaved = true;
		$rootScope.complaint.documentUploadedFlag = 1;
		$rootScope.disableSummary=false;
		$scope.documentDetails = data;
		if($scope.fileSelected!=null && $scope.fileSelected!=undefined && $scope.fileSelected==''){//edit mode update
			$scope.removeDocumentFromList($scope.editDocumentDetailOB);
			$scope.editDocumentDetailOB = null;
			//$scope.documentList.unshift($scope.documentDetails);
		}//else
		//$scope.documentList.push($scope.documentDetails);
		$scope.documentList.unshift($scope.documentDetails);
		$rootScope.complaint.supportingDocCode = 'YES';
		
		$scope.clearData();
		if(mode=='SAVEANDCONTINUE'){
			$state.transitionTo("mrpApp.complaintSummary");
		}
		$scope.showModal('Success','Document uploaded successfully.','success');
		$timeout(function() {
			$scope.closeModal();
		},3000);
	}
	
	$scope.saveForNoUpload = function(mode){
		
		$scope.showLoader('Saving...');
		var formData = {"complaintId":$rootScope.complaint.complaintId,"docStatus":"NO"}
		$http({'url':"document/saveDocumentUploadStatus", 'params':formData,'method':'POST'})
    	.then(
    			function(response){
    				$rootScope.SupportDocumentsSaved = true;
    				$rootScope.complaint.supportingDocCode = 'NO';
    				$rootScope.documentchangedFlag = false;
    				$rootScope.complaint.documentUploadedFlag = 1;
    				$scope.hideLoader();
    				if(mode=='SAVEANDCONTINUE'){
    					$state.transitionTo("mrpApp.complaintSummary");
    				}
    				$scope.showModal('Success','Change has been saved.','success');
    				$timeout(function() {
    					$scope.closeModal();
    				},3000);
    			}
    		);
	}
	
	$scope.uploadStatusCodeChange = function(code){
		if(code=='YES'){
			$scope.showDocDetail = true;
		}else{
			$scope.showDocDetail = false;
		}
	}
	
	$scope.cancelBtn  = function(){
		if($rootScope.documentchangedFlag){
			$scope.showConfirmModal('Warning', 'You have unsaved data on your page. Are you sure you want to cancel?', $scope.cancelBtnSuccess, $scope.cancelBtnCancel);
		}else{
			$rootScope.documentchangedFlag = false;
			$state.transitionTo('mrpApp.home');
		}
	
	}
	
	$scope.cancelBtnSuccess = function() {
		$scope.hideConfirmModal();
		$rootScope.documentchangedFlag = false;
		$state.transitionTo('mrpApp.home');
	}
	
	$scope.cancelBtnCancel = function() {
		$scope.hideConfirmModal();
	}
	
	$scope.$watch('documentOutputOnDisplay', function () {
		if($scope.documentOutputOnDisplay!=undefined && $scope.documentOutputOnDisplay!=null && $scope.editDocumentDetailOB!=undefined && $scope.editDocumentDetailOB!=null){
			$rootScope.documentchangedFlag = !angular.equals($scope.documentOutputOnDisplay, $scope.editDocumentDetailOB);
		}
	}, true);
	
	$scope.noDetailAvailableCheck = function(){
		if(!$scope.documentUploadForm.$valid && $scope.documentList.length<1 ){
			$scope.showConfirmModal('Warning', 'No document uploaded, do you want to set upload document to No', $scope.uploadStatusNoSuccess, $scope.cancelBtnCancel);
		}
		return $scope.documentUploadForm.$valid;
	}
	$scope.uploadStatusNoSuccess = function(){
		$scope.showDocDetail = false;
		$scope.YESNOCODE = "NO";
		$scope.hideConfirmModal();
	}
});
