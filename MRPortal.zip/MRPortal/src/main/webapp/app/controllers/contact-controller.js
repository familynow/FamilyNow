'use strict';

app.controller('contactusController', function($scope,$http) {

	  $scope.getDetailsInfo=function(){
		  $http.get( 'loginController/fetchContactDetails/').then(function (response){
			 $scope.email=response.data.contactEmailId;
			 $scope.phone=response.data.contactPhone;
		  });
		  
		  
	  
	  }
	
});