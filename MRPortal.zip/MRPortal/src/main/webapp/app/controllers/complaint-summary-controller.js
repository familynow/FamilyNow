'use strict';
app.controller('complaintSummaryController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse,$filter){ 
	
	var domainCodes = ["Gender","ParticipantRole","AllegationType"]; 
	InitPageService.initPage($scope,domainCodes); 
	$scope.config = APP_CONFIG;
	$rootScope.showBreadcrumbs = true;
	$scope.showLessVictimsArr={};
	$scope.showLessPerpetratorsArr={};
	
	$scope.initSummary = function(complaintId){
		//$rootScope.allegationSaved = true;
		$rootScope.linkToActive="summary";
		$scope.sortType="-complaintParticipantId";
		$scope.sortType1="-allegationGroupId";
		$http({
			method : 'GET',
			url : 'complaintParticipant/retrieveAllComplaintParticipants/'+ $rootScope.complaint.complaintId
		}).then(function(response) {
			$scope.listParticipantData = response.data.listParticipant;
			$scope.sortType="-complaintParticipantId";
		},
		function(errResponse){
			
		});
		$http({
			method : 'GET',
			url : 'allegationGroup/retrieveAllegationGroups/'
							+ $rootScope.complaint.complaintId
		}).then(function(response) {
				$scope.allegationGroupRecords = response.data;
				angular.forEach($scope.allegationGroupRecords, function(record, index) {
					$scope.showLessVictimsArr[index]=true;
					$scope.showLessPerpetratorsArr[index]=true;
				});
		});
		
	};
	
	$scope.showMorePerpetrators = function(index){
		$scope.showLessPerpetratorsArr[index]=false;
	}
	$scope.showMoreVictims = function(index){
		$scope.showLessVictimsArr[index]=false;
	}
	$scope.showLessVictms = function (index){
		$scope.showLessVictimsArr[index]=true;
	}
	$scope.showLessPerpetrtors=function (index){
		$scope.showLessPerpetratorsArr[index]=true;
	}
	
	$scope.cancel = function(){
    	$state.transitionTo("mrpApp.home",{ notify: true ,reload: true});
    }
	$scope.formartAddress = function(participant){
		var address = "";
		if(participant.address_line_1 && participant.address_line_1 != ""){
			address=address+participant.address_line_1+", ";
		}
		if(participant.address_line_2 && participant.address_line_2 != ""){
			address=address+participant.address_line_2+", ";
		}
		if(participant.city && participant.city != ""){
			address=address+participant.city+", ";
		}
		if(participant.stateCode && participant.stateCode != ""){
			var stateDesc=$filter('refDataShortDescription')(participant.stateCode,'State');
			address=address+stateDesc+", ";
		}
		if(participant.zipCode && participant.zipCode != ""){
			address=address+participant.zipCode;
		}
		if(address.endsWith(", ")){
			address = address.substring(0, address.length - 2);
		}
		return address;
	}
	$scope.formatPhone = function(mob){
		var formattedMobileNo = "";
		/*var formattedWorkNo = "";
		var mob=participant.mobileNumber;
		var work=participant.workNumber;*/
		if(mob){
			mob=mob+"";
			formattedMobileNo = [mob.slice(0, 3), "-", mob.slice(3)].join('');
			formattedMobileNo = [formattedMobileNo.slice(0, 7), "-", formattedMobileNo.slice(7)].join('');
		}
		/*if(work){
			work=work+"";
			if(formattedMobileNo != "")
				formattedMobileNo=formattedMobileNo+"<br/>"
				formattedWorkNo = [work.slice(0, 3), "-", work.slice(3)].join('');
				formattedWorkNo = [formattedWorkNo.slice(0, 7), "-", formattedWorkNo.slice(7)].join('');
		}
		var no = formattedMobileNo+formattedWorkNo;*/
		return formattedMobileNo;
	}
	$scope.saveSummary=function(){
		$scope.showLoader('Please Wait');
		$http.post('complaintSummary/saveComplaint/', $rootScope.complaint.complaintId)
    	.then(function(response){
    		$scope.hideLoader();
			$scope.showModal('Success','Complaint has been submitted successfuly.','success');
			var intakeURL ='/main-web/intake/createIntakeFromComplaint/';// window.location.href;
			/*if(intakeURL.indexOf('localhost') >= 0) { // Local
				intakeURL = 'http://localhost:8080/main-web/intake/createIntakeFromComplaint/';
			}
			else if(intakeURL.indexOf('0603') >= 0) { //Test
				intakeURL = 'http://inblr-vm-0603.gtci-dev.com:8080/main-web/intake/createIntakeFromComplaint/';
			}
			else if(intakeURL.indexOf('0604') >= 0) { //UAT
				intakeURL = 'http://inblr-vm-0604.gtci-dev.com:8080/main-web/intake/createIntakeFromComplaint/';
			}
			else if(intakeURL.indexOf('0546') >= 0){	//Dev
				intakeURL = 'http://inblr-vm-0546.gtci-dev.com:8080/main-web/intake/createIntakeFromComplaint/';
			}else if(intakeURL.indexOf('52.70.147') >= 0){//AWS
				intakeURL = 'http://52.70.147.93:8080/main-web/intake/createIntakeFromComplaint/';
			}else {
				intakeURL = '/main-web/intake/createIntakeFromComplaint/';
			}
			intakeURL = '/main-web/intake/createIntakeFromComplaint/';*/
			$http.post(intakeURL,response.data)
    		.then(function(response){
    			var intakeId = response.data.intakeId;
    			if(intakeId){
    				$rootScope.complaint.intakeId=intakeId;
    				$http.post('complaintSummary/updateIntakeToComplaint/', $rootScope.complaint)
    				.then(function(response){
    				})
    			}
    		})
    		$timeout(function() {
				$scope.closeModal();
			},3000);
			$state.transitionTo("mrpApp.home",{ notify: true ,reload: true});
    	}),
		function(errResponse){
			$scope.hideLoader();
			$scope.showModal('Failure','An error has occurred while performing your request. Please try again later.','failure');
			$timeout(function() {
				$scope.closeModal();
			},3000);
		}
	}
});