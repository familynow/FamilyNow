'use strict';
app.controller('sdmManagementController', function($rootScope, $q,
		$scope, $state, APP_CONFIG, $http,
		InitPageService,$stateParams){
	
	var domainCodes = ["PriorityAllegationCategory","SDMOutcome"]; 
	InitPageService.initPage($scope,domainCodes); 
	$scope.config = APP_CONFIG;
	
	//$scope.sortType="-userName";
	$scope.getSDMList = function(){
		$scope.showLoader('Please Wait');
		$http({
			method : 'GET',
			url : 'manageSDMTool/getSDMList/'
		}).then(function(response) {
			$scope.toolList=response.data;
			$scope.sortType="createdDate";
			$scope.hideLoader();
		})
	}
	 $scope.onCancel = function() { //On Click of Cancel in the confirmation popup
	    	$scope.hideConfirmModal();;
	    }
	$scope.addSDM = function (){
		$state.go("mrpApp.addSDMTool",{sdmList:$scope.toolList});
	}
	$scope.editSDM = function(priorityToolId){
		$state.transitionTo("mrpApp.editSDMTool",{sdmToolId:priorityToolId, sdmList:$scope.toolList});
	}
	$scope.deleteSDMTool = function(priorityToolId){
		$scope.recordToDelete=priorityToolId;
		$scope.showConfirmModal('Delete', 'Do you want to delete the record?', $scope.deleteRecord, $scope.onCancel);
	}
	$scope.deleteRecord = function(){
		$scope.hideConfirmModal();
    	$scope.showLoader('Please Wait');
    	$http({
			method : 'DELETE',
			url : 'manageSDMTool/deleteSDMTool/'+ $scope.recordToDelete
    	}).then(function(response) {
    		//$scope.toolList=response.data;
			//$scope.sortType="createdDate";
			$scope.hideLoader();
			//$scope.showModal('Success','SDM Tool Id '+$scope.recordToDelete+' has been deleted successfully.','success');
			$scope.showModal('Success','SDM tool has been deleted successfully.','success');
			$state.reload();
    	});
	}
	$scope.saveSDMTool = function(actionType, valid){
		$scope.submitted = true;
		if($scope.sdmList && $scope.sdmList.length>0){
			for(var i=0;i<$scope.sdmList.length;i++){
				if(($scope.toolDetails.priorityAllegationCategory == $scope.sdmList[i].priorityAllegationCategory)
						&& ($scope.toolDetails.priorityToolId != $scope.sdmList[i].priorityToolId)){
					
					$scope.errorMessage="sdm.toolexists";
					$(window).scrollTop($('.error-msg'));
					return;
				}
			}
		}
		if(valid){
			$scope.showLoader('Please Wait');
			$http.post('manageSDMTool/saveSDMTool/', $scope.toolDetails)
	    	.then(function(response){
	    		$scope.submitted = false;
	    		$scope.toolDetails=response.data;//
	    		$scope.sortType="createdDate";
	    		$scope.showModal('Success','SDM tool has been saved successfully.','success');
	    		//$scope.$apply();
	    		if(actionType=='APPLY'){
	    			//$state.reload();
	    			$scope.hideLoader();
	    		}
	    		if(actionType == 'SAVE'){
	    			$state.go("mrpApp.sdmTool");
	    		}
	    	})
		}
	}
	$scope.cancelSDMTool = function(){
		$state.go("mrpApp.sdmTool");
	}
	$scope.addQuestion = function(priorityToolId){
		$state.go("mrpApp.addSDMQuestion",{sdmToolId:priorityToolId});
	}
	$scope.editSDMQuestion = function(priorityListId,questionId,toolDetails){
		$scope.showLoader('Please Wait');
		$state.go("mrpApp.editSDMQuestion",{priorityListId:priorityListId,questionId:questionId,sdmToolDetails:toolDetails});
	}
	$scope.saveSDMQuestion = function(record, priorityToolId, actionType){
		$scope.submitted = true;
		$scope.validated=true;
		$scope.noOptionsSelected=false;
		$scope.wrongNextOnNo=false;
		$scope.wrongNextOnYes=false;
		if(!record || !record.question || !record.questionDesc)
			return;
		if($scope.editMode){
			$scope.validated=$scope.validateQuestionData(record);
		}
		if($scope.validated){
			$scope.errorMessage=null;
			record.priorityToolId=priorityToolId;
			$scope.showLoader('Please Wait');
			$http.post('manageSDMTool/saveQuestion/', record)
	    	.then(function(response){
	    		$scope.questionDeatils=response.data;
	    		$scope.showModal('Success','Question has been saved successfully.','success');
	    		$scope.hideLoader();
	    		if(actionType=='APPLY'){
	    			$scope.submitted = false;
	    			$scope.noOptionsSelected=false;
	    			// $state.transitionTo($state.current, $stateParams, { reload: true, inherit: false, notify: true });
	    			$scope.hideLoader();
	    		}
	    		if(actionType == 'SAVE'){
	    			$state.go("mrpApp.editSDMTool",{sdmToolId:priorityToolId});
	    		}
	    	})
		}
		
	}
	$scope.validateQuestionData=function(record){
		$scope.errorMessage=null;
		$scope.sameSelectionError=null;
		if((!record.priorityOnNo && !record.nextOnNo) ||
				(!record.priorityOnYes && !record.nextOnYes)){
			//$scope.noOptionsSelected=true;
			$scope.errorMessage="sdm.wrongselection";
			return false;
		}else {
			if(record.nextOnNo && record.nextOnNo<=record.questionNumber){
				//$scope.wrongNextOnNo=true;
				$scope.errorMessage="sdm.questionnumber.error";
			}
			if(record.nextOnYes && record.nextOnYes<=record.questionNumber){
				//$scope.wrongNextOnYes=true;
				$scope.errorMessage="sdm.questionnumber.error";
			}
			if(record.nextOnYes && record.nextOnNo && record.nextOnYes==record.nextOnNo){
				$scope.errorMessage="sdm.sameoption.selected";
			}
			if($scope.sdmToolDetails && $scope.sdmToolDetails.priorityLists && $scope.sdmToolDetails.priorityLists.length>0){
				var questionList=$scope.sdmToolDetails.priorityLists;
				for(var i=0;i<questionList.length;i++){
					if(questionList[i].yesPriorityQuestionNumber && !isNaN(questionList[i].yesPriorityQuestionNumber)){
						if((record.nextOnYes == questionList[i].yesPriorityQuestionNumber)
								|| (record.nextOnNo == questionList[i].yesPriorityQuestionNumber)){
							$scope.sameSelectionError="Selected question number "+questionList[i].yesPriorityQuestionNumber+" has already been chosen for question "+questionList[i].priorityQuestionNumber
							+". Please select a different option.";
							//$scope.sameSelectionError = ErrorMessageService.getErrorMessage('password.reset.success')+" "+questionList[i].yesPriorityQuestionNumber+" "+
							break;
						}
					}
				}
				if(!$scope.errorMessage){
					for(var i=0;i<questionList.length;i++){
						if(questionList[i].noPriorityQuestionNumber && !isNaN(questionList[i].noPriorityQuestionNumber)){
							if((record.nextOnYes == questionList[i].noPriorityQuestionNumber)
									|| (record.nextOnNo == questionList[i].noPriorityQuestionNumber)){
								$scope.sameSelectionError="Selected question number "+questionList[i].noPriorityQuestionNumber+" has already been chosen for question "+questionList[i].priorityQuestionNumber
								+". Please select a different option.";
								break;
							}
						}
					}
				}
			}
			if($scope.errorMessage || $scope.sameSelectionError)
				return false;
			else
				return true;
		}
			
	}
	$scope.cancelSDMQuestion = function(priorityToolId){
		$state.go("mrpApp.editSDMTool",{sdmToolId:priorityToolId});
	}
	$scope.deleteQuestion = function(priorityToolId){
		$scope.questionRecordToDelete=priorityToolId;
		$scope.showConfirmModal('Delete', "Deleting this question will delete all the questions of the Priority Tool. Do you wish to continue?", $scope.deleteQuestionRecord, $scope.onCancel);
	}
	$scope.deleteQuestionRecord = function(){
		$scope.hideConfirmModal();
    	$scope.showLoader('Please Wait');
    	$http({
			method : 'DELETE',
			url : 'manageSDMTool/deleteSDMQuestions/'+ $scope.questionRecordToDelete
    	}).then(function(response) {
    		//$scope.toolList=response.data;
			//$scope.sortType="createdDate";
			$scope.hideLoader();
			$state.reload();
			$scope.showModal('Success','All questions have been deleted successfully.','success');
			//$scope.showModal('Success','SDM Tool Id '+$scope.recordToDelete+' has been deleted successfully.','success');
			//$state.go("mrpApp.editSDMTool",{sdmToolId:$scope.questionRecordToDelete});
    	});
	}
	
	$scope.errorOnFocus = function(isValid){
		if(!isValid){
			$scope.scrollToFormError();
			return false;
		}
	}
})