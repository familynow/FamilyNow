app.controller('AppController', function($scope,APP_CONFIG, $rootScope, $state,
		$stateParams, $timeout,InitPageService,$http, Idle) {	
	$scope.config = APP_CONFIG;
	
	$rootScope.isDesktop = (function() {
		   if(window.innerWidth > 800) {
		     return true;
		   } else {
		     return false;
		   }
	})();
	
	$scope.controlSideNav = function (){
		$rootScope.disableParticipant=false;
		$rootScope.disableAllegation=false;
		$rootScope.disableSummary=false;
		$rootScope.disableAdditionalInfo=false;

		if(!$rootScope.complaint || !$rootScope.complaint.complaintId){
			$rootScope.disableParticipant=true;
			$rootScope.disableAllegation=true;
			$rootScope.disableSummary=true;
			$rootScope.disableAdditionalInfo=true;
			$rootScope.profileSaved = false;
		}
		else {
			$rootScope.profileSaved = true;
		}
		if($rootScope.complaint.participantDataAvailableFlag != 1){
			$rootScope.disableAllegation=true;
			$rootScope.disableSummary=true;
			$rootScope.disableAdditionalInfo=true;
			$rootScope.participantSaved = false;
		}
		else {
			$rootScope.participantSaved = true;
		}
		if($rootScope.complaint.allegationDataAvailableFlag != 1){//need to check with marked for delete flag
			$rootScope.disableAdditionalInfo=true;
			$rootScope.disableSupportingDocs = true;
			$rootScope.allegationSaved = false;
		}
		else {
			$rootScope.allegationSaved = true;
		}
		
		if($rootScope.complaint.narrativeDataAvailableFlag != 1){//need to check with marked for delete flag
			$rootScope.disableSupportingDocs = true;
			$rootScope.additionalInfoSaved = false;
		}
		else {
			$rootScope.additionalInfoSaved = true;
		}
		
		
		if($rootScope.complaint.documentUploadedFlag != 1){//need to check with marked for delete flag
			$rootScope.disableSummary=true;
			$rootScope.SupportDocumentsSaved = false;
		}
		else {
			$rootScope.SupportDocumentsSaved = true;
		}
		/**
		 * Temporary logic to enable summary even when only allegation, participant and profile data available
		 */
		/*if($rootScope.complaint.allegationDataAvailableFlag == 1){
			$rootScope.disableSummary=false;
		}*/
	}
	
	$scope.showModal = function(msgTitle, msgContent,type) {
		$('#msgModal').fadeIn();
		$scope.modalTitle = msgTitle;
		$scope.modalContent = msgContent;
		$scope.type = type;
	}
	$scope.checkStatus = function(){
		if($rootScope.authenticatedUser){
			$state.transitionTo("mrpApp.home");
		}else
			$state.transitionTo("prelogin.login");
	}
	
	 $scope.$on('IdleTimeout', function() {
	    /*closeModals();
	    $scope.timedout = $uibModal.open({
	      templateUrl: 'timedout-dialog.html',
	      windowClass: 'modal-danger'
	    });*/
		 var currentState=$state.current.name;
		 if(currentState && currentState != "prelogin.login" && currentState != "prelogin.signup" && currentState != "prelogin" )
			 $rootScope.logout();
	  });
	 
	 $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){ 
	     // do something
		 Idle.watch();
	 })
	$scope.closeModal = function() {
		$('#msgModal').fadeOut();
	}
	
	$scope.showNotifyModal = function(notifyTitle, notifyContent,notifyType) {
		$('#notifyAway').fadeIn();
		$rootScope.notifyTitle = notifyTitle;
		$rootScope.notifyContent = notifyContent;
		$rootScope.notifyType = notifyType;
	}
	
	$scope.closeNotifyModal = function() {
		$('#notifyAway').fadeOut();
	}
	
	$scope.scrollToTop = function() {
		var bodyItem = $('body');
		$('html,body').animate({
	        scrollTop: bodyItem.offset().top - 150},
	        'slow');
	}
	
	$scope.scrollToTarget = function(element) {
		$('html,body').animate({
	        scrollTop: $('#'+element).offset().top},
	        'slow');
	}
	
	$scope.scrollToFormError = function() {
		$('form').addClass('form-submitted');
		var focusItem = $('form .ng-invalid').first();
		$('html,body').animate({
	        scrollTop: focusItem.offset().top - 150},
	        'slow',function() {
	        	focusItem.focus();
	    });
	}
	
	$scope.showLoader = function(loaderMsg) {
		$('#loaderOverlay').fadeIn();
		$scope.loaderMsg = loaderMsg;
	}
	
	$scope.hideLoader = function() {
		$('#loaderOverlay').fadeOut();
	}
	
	$scope.showConfirmModal = function(confirmTitle, confirmContent, onConfirm, onCancel) {
		$scope.confirmTitle = confirmTitle;
		$scope.confirmContent = confirmContent;
		$scope.confirmAction = onConfirm;
		$scope.cancelAction = onCancel;
		$('#confirm-popup').fadeIn();
	}
	
	$scope.hideConfirmModal = function() {
		$('#confirm-popup').fadeOut();
	}
	
	$scope.toggleSideBar = function() {
		$('.page-content').toggleClass('show-mobile-menu');
		$('.page-sidebar').toggleClass('show-mobile-menu');
	}
	
	
	$scope.$on('$viewContentLoaded', function(){
		$('.page-content').removeClass('show-mobile-menu');
		$('.page-sidebar').removeClass('show-mobile-menu');
	});
	
	$rootScope.currentState = 'mrpApp.personProfile'; 
	
	/*
	$scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
		$('.page-content').removeClass('show-mobile-menu');
		$('.page-sidebar').removeClass('show-mobile-menu');
	});*/
	
	$scope.navigateAway =function(stateName){
		//$scope.stateToMove = stateName;
	
		if($rootScope.personProfilechanged && $rootScope.viewMode==false)
			$scope.showNotifyModal('Information','Please save person form or cancel to navigate to other page','info');			
		else if($rootScope.participantDataChanged && $rootScope.viewMode==false)
			$scope.showNotifyModal('Information','Please save participant form or cancel to navigate to other page','info');
		else if($rootScope.allegationDataChanged && $rootScope.viewMode==false)
			$scope.showNotifyModal('Information','Please save allegation form or cancel to navigate to other page','info');
		else if($rootScope.additionalInfoDataChanged && $rootScope.viewMode==false)
			$scope.showNotifyModal('Information','Please save Additional Information form or cancel to navigate to other page','info');
		else if($rootScope.documentchangedFlag && $rootScope.viewMode==false)
			$scope.showNotifyModal('Information','Please save Document Details Information form or cancel to navigate to other page','info');
		else
			$state.transitionTo(stateName,{ notify: true ,reload: true});
			
		
	}
	
	$scope.cancelBtnCancel = function(){
		$scope.hideConfirmModal();
	}
	
	$scope.cancelBtnSuccess = function() {
		$scope.hideConfirmModal();
		$rootScope.documentchangedFlag = false;
		$state.transitionTo($scope.stateToMove,{ notify: true ,reload: true});
	}
	
	$scope.validateAndNavigate = function (state){
		$state.go(state);
		/*$http({method: 'GET', url: 'loginController/validateUser/' })
  		.then(
  			function(response){
  				if(response.data.admin==true){
  					$state.go(state)
  				}else{
  					alert("You don't have access to this page. Please re-login and try again");
  					$rootScope.logout();
  				}
  			}, function(errResponse) {
  				alert("You don't have access to this page. Please re-login and try again");
  				$rootScope.logout();
			}
  		);*/
	}
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){ 
	    // do something
	if(toState.name === 'mrpApp.home' || toState.name === 'mrpApp.userList' || toState.name === 'mrpApp.sdmTool' || toState.name === 'mrpApp.refDataSearch'){
		$rootScope.displayHambrgr=true;
	}else{
		$rootScope.displayHambrgr=false;
	}
})
});
