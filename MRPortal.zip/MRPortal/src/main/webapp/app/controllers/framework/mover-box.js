$(function () {
	$('body').on('click', '.list-group .list-group-item', function () {
		$(this).toggleClass('active');
	});
});

app.controller('MoverListCtrl', function ($scope,$filter) {
	$scope.moveItem = function (dataModel,source, destination) {		
		if(!dataModel){
			dataModel = [];
			var details = [];
			angular.forEach(source, function (value, key) {
				if (source[key].checked) {
					source[key].checked=null;
					dataModel.push(source[key]);
				}
			});
			/*if (details.length > 0)
				$scope.msg = 'Selected Values: '+details.toString();
			else
				$scope.msg = 'Please choose an option';*/
		}
		for (var i = 0; i < dataModel.length; i++) {
            var item = dataModel[i];
            var idx = source.indexOf(item);

            if (idx != -1) {
            	source.splice(idx, 1);
           		destination.push(item);
            }
        }
		
		destination.sort(function(prev, next) {
			if(prev.sortValue && next.sortValue){
				var prevSortValue = prev.sortValue; 
				var nextSortValue = next.sortValue; 
				if (prevSortValue < nextSortValue) {
					return -1;
				}
				if (prevSortValue > nextSortValue) {
					return 1;
				}
				return 0;
			}
			return 0;
		});
    };
});