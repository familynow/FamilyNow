app.controller('TypeaheadCtrl', function($scope, $http) {
});