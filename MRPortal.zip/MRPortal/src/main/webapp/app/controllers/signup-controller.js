'use strict';
app.controller('loginController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse, Idle, $sessionStorage, ErrorMessageService){
	//$scope.isLoginPageInitialized =false;
	var domainCodes = [];
	InitPageService.initPage($scope,domainCodes);
	$scope.initSignUp = function(){
		$scope.errorMessage=null;
		$scope.userAccount={};
		$scope.submitted = false;
	}
	
	$scope.initCheckLoggedIn = function(){
		//$rootScope.clearRootScopeData();
		$scope.clientData={};
		$rootScope.deleteUserInfo();
		if($stateParams.token){
			$scope.confirmUserSignup();
		}else if($stateParams.registrationMsg){
			$scope.registrationMsg=$stateParams.registrationMsg;
		}else{
			$http({method: 'GET', url: 'loginController/userLoginStatus' })
			.then(
	  			function(response){
	  				if(response.data.loggedIn){
	  					$scope.setUserInfo(response);
	  				}else{
	  					$state.transitionTo("prelogin.login");
	  				}
	  			},function (error){
	  				//$scope.displayLogin = true;
	  				$state.transitionTo("prelogin.login");
	  			}
	  		);
		}
	}
	$rootScope.deleteUserInfo = function(){
		$http.defaults.headers.common.Authorization = '';
		$rootScope.authenticatedUser = false;
		$sessionStorage.SessionMessage = '';
		$sessionStorage.userAccountId = null;
		$sessionStorage.userAccount=null;
		//$rootScope = $rootScope.$new(true);
		for (var prop in $rootScope) {
	        if (prop.substring(0,1) !== '$' && prop != 'settings') {
	            delete $rootScope[prop];
	        }
	    }
	}
	$scope.validatePass  = function(form){
		/*if($scope.userAccount.password && $scope.userAccount.password.length < 8){
			$scope.errorMessage="Password field cannot be blank and must contain at least 8 characters."
		}else
			$scope.errorMessage="";*/
		
		$http.post('loginController/validatePassword',form)
    	.then(function(response){
				if(response.data.validationMsgs != null){
					$scope.errorMessage="";
					$scope.validationMsgs=response.data.validationMsgs;
				}else{
					$scope.validationMsgs=null;
				}
  			}
    	);
	}
	$scope.validateResetPass  = function(form){
		/*if($scope.userAccount.password && $scope.userAccount.password.length < 8){
			$scope.errorMessage="Password field cannot be blank and must contain at least 8 characters."
		}else
			$scope.errorMessage="";*/
		var userAccount = {};
		userAccount.password=form.newPassword;
		$http.post('loginController/validatePassword',userAccount)
    	.then(function(response){
				if(response.data.validationMsgs != null){
					//$scope.errorMessage="";
					$scope.validationMsgs=response.data.validationMsgs;
					//ErrorMessageService.getErrorMessage('password.reset.success')
				}else{
					$scope.validationMsgs=null;
				}
  			}
    	);
	}
	$scope.signUp = function(userAccount,repassword){
		
		$scope.submitted=true;
		$scope.errorMessage=null;
		$scope.registrationMsg = null;
		$scope.matchMsg=null;
		//if(!$scope.signupForm.$valid){
			if(!userAccount.password && !$scope.validationMsgs){
				//$scope.errorMessage="Password field cannot be blank."
					$scope.validationMsgs = null;
					return;
			}else
				$scope.errorMessage="";
			//return;
		//}
		
		
		if(userAccount.password===repassword){
			userAccount.password=repassword;
			userAccount.applicationName = "MRP";
			$scope.showLoader('Please Wait');
			$http.post('loginController/signUp/', userAccount)
	    	.then(function(response){
					if(!response.data.errorMessage){
						$scope.hideLoader();
						$state.transitionTo("prelogin.login",{'registrationMsg' : ErrorMessageService.getErrorMessage('account.created')});
					}else{
						$scope.hideLoader();
						$scope.errorMessage=ErrorMessageService.getErrorMessage(response.data.errorMessage);
						$("#passerr").hide();
					}
					$scope.submitted = false;
	  			}
	    	);
		}else{
			//$scope.hideLoader();
			$scope.matchMsg="";
			$scope.matchMsg=$scope.errorMessage=ErrorMessageService.getErrorMessage('cofirm.password.mismatch');
		}
		
	}
	
	$scope.authenticate = function(argLoginData){
		$scope.submitted=true;
		$scope.errorMessage=null;
		$scope.registrationMsg = null;
		Idle.watch();
		if(!argLoginData.password){
			$scope.nopassword=true;
			return;
		}
		argLoginData.applicationName = "MRP";
		$scope.showLoader('Please Wait');
    	$http.post('loginController/login/',argLoginData )
    	.then(function(response){
    			//$rootScope.clearRootScopeData();
    			$scope.submitted=false;
				if(response.data.authenticatedFlag == true){
					//$scope.clientData = response.data;
					$scope.hideLoader();
					$scope.setUserInfo(response);
					//{complaintParticipantId:complaintParticipantId, notify: true ,reload: true}
				}else{
					$scope.hideLoader();
					$scope.errorMessage=ErrorMessageService.getErrorMessage(response.data.errorMessage);
				}
			},
			function(errResponse){
				$scope.hideLoader();
				$scope.errorMessage=ErrorMessageService.getErrorMessage(errResponse.data.errorMessage);
				//return $q.reject(errResponse);
			}
    	);
    }
	$rootScope.clearRootScopeData =function(){
		$rootScope = $rootScope.$new(true);
	}
	$scope.setUserInfo = function(response){
		$http.defaults.headers.common.Authorization = 'Bearer ' + response.data.token;
		$sessionStorage.token=response.data.token;
		$rootScope.authenticatedUser = response.data.authenticatedFlag;
		$rootScope.userData = response.data;
		$sessionStorage.SessionMessage = "Authenticated";
		$sessionStorage.userAccountId =  response.data.userAccountId;
		$sessionStorage.userAccount=response.data;
		$rootScope.$broadcast("userAuthenticated", {UserObject : $rootScope.userData });
		//$("#loginModal").modal('hide');
		$scope.hideLoader();
		if(response.data.admin==true){
			$state.transitionTo("mrpApp.userList",{notify: true ,reload: true});						
		}else{
			$state.transitionTo("mrpApp.home",{userId : response.data.userAccountId, notify: true ,reload: true});						
		}
	}
	$rootScope.logout = function(){
		$scope.errorMessage=null;
		$rootScope.allegationSaved=false;
    	$http.post('loginController/logout/' )
    	.then(function(response){
				$scope.clientData = response.data;
				$rootScope.deleteUserInfo();
				$state.transitionTo("prelogin.login");
			},
			function(errResponse){
				return $q.reject(errResponse);
			}
		
    	);
    }
	
	
	$scope.returnToLogin = function (){
		$state.transitionTo("prelogin.login");
	}
	$scope.prepareForm = function (){
		$scope.form = {};
	}
	$scope.validateEmailId =function(form){
		if(!form || !form.email){
			$scope.emailMessage=ErrorMessageService.getErrorMessage('login.email.requiered');
				return;
		}
			
		$scope.showLoader('Please Wait');
		$scope.submitted=true;
		$scope.errorMessage=null;
		$scope.emailMessage=null;
		$http.post('loginController/validateEmailId',form)
    	.then(function(response){
				if(response.data.errorMessage != null){
					$scope.hideLoader();
					$scope.errorMessage=response.data.errorMessage;
				}
  			}
    	);
	}
	$scope.confirmUserAccount = function(){
		$http.get('loginController/confirmUser/'+$stateParams.token).then(function(response){
			if(response.data.accountConfirmed){
				$scope.confirmed=true;
				$scope.userAccount=response.data;
			}else{
				$scope.notConfirmed =true;
				$scope.errorMessage = response.data.errorMessage; 
			}
		})
	}
	$scope.confirmUserSignup = function(){
		$http.get('loginController/confirmNewUser/'+$stateParams.token).then(function(response){
			if(response.data.accountConfirmed){
				$scope.errorMessage=ErrorMessageService.getErrorMessage('account.activated');
				$scope.userAccount=response.data;
			}
			
			else if(!response.data.accountConfirmed){
				$scope.errorMessage = response.data.errorMessage;
			}
			
			else{
				$scope.errorMessage = response.data.errorMessage;
			}
		})
	}
	$scope.updatePassword = function(userAccount,repassword){
		if($scope.validationMsgs && $scope.validationMsgs.length > 0)
			return;
		$scope.submitted=true;
		$scope.errorMessage=null;
		if(!userAccount.password || !repassword)
			return;
		if(userAccount.password===repassword){
			userAccount.password=repassword;
			userAccount.applicationName = "MRP";
			$scope.showLoader('Please Wait');
			$http.post('loginController/setForgottenPassword/', userAccount)
	    	.then(function(response){
					if(!response.data.errorMessage){
						$scope.hideLoader();
						$state.transitionTo("prelogin.login",{'registrationMsg' : ErrorMessageService.getErrorMessage('password.reset.success')});
					}else{
						$scope.hideLoader();
						$scope.errorMessage=response.data.errorMessage;
					}
					$scope.submitted = false;
	  			}
	    	);
		}else{
			$scope.hideLoader(); 
			$scope.errorMessage=ErrorMessageService.getErrorMessage('cofirm.password.mismatch');
		}
	}
	$rootScope.resetPassowordClose = function(){
		$("#reset-password").modal('hide');
		$scope.resetPsw={};
		$scope.submitted=false;
		$scope.errorMessage=null;
		$scope.validationMsgs=null;
	}
	$scope.resetPassword = function(resetPsw){
		$scope.submitted=true;
		$scope.errorMessage=null;
		if(resetPsw){
			if(!resetPsw.newPassword || !resetPsw.confirmNewPassword || !resetPsw.oldPassword){
				$scope.errorMessage=ErrorMessageService.getErrorMessage('all.mandatory');
				return;
			}
		}else{
			$scope.errorMessage=ErrorMessageService.getErrorMessage('all.mandatory');
			return;
		}
		if($scope.validationMsgs !=null && $scope.validationMsgs.length > 0){
			return;
		}
		//else if($scope.validationMsgs==null){
			if(resetPsw.newPassword===resetPsw.confirmNewPassword){
				
				resetPsw.newPassword=resetPsw.confirmNewPassword;
				resetPsw.applicationName = "MRP";
				$http.post('loginController/resetPassword/',resetPsw)
		    	.then(function(response){
						if(response.data.errorMessage != null){
							$scope.errorMessage=ErrorMessageService.getErrorMessage(response.data.errorMessage);
							$scope.hideLoader();
						}else{
							$scope.showModal('Success',ErrorMessageService.getErrorMessage('password.reset.success'),'success');
							//alert("Your password has been reset successfully. Please login to continue.")
							$scope.hideLoader();
							$http.post('loginController/logout/' )
					    	.then(function(response){
					    		setTimeout(function(){
					    			$rootScope.deleteUserInfo();
									location.reload();
					    		}, 2000);
									
								},
								function(errResponse){
									$scope.hideLoader(); 
									return $q.reject(errResponse);
								}
							
					    	);
							
						}
		  			}
		    	);
			}
			else{
				$scope.hideLoader();
				$scope.errorMessage=ErrorMessageService.getErrorMessage('cofirm.password.mismatch');
			}
	}
});
