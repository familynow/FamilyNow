'use strict';
app.controller('refDataController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse, Idle, $sessionStorage){
	var errorCodes = [];
	InitPageService.initPage($scope,errorCodes); 
	
	$rootScope.isReadyOnlyField=false;
	
	$scope.initRefDataPage = function(){
		$scope.errorMessage=null;
		$scope.refDataForm={};
		$scope.showLoader('Please wait');
		//if(!$rootScope.domainCodeList){
			$http({method: 'GET', url: 'refDataController/getDomainCodes/' })
	  		.then(function(response){
				$rootScope.domainCodeList = response.data.domainCodeList;
				$scope.hideLoader();
			})
		//}else{
			//$scope.hideLoader();
		//}
		
	}
	
	$scope.searchRefData = function(noMatchingDomainCode){
		$scope.errorMessage=null;
		if($scope.refDataForm.domainCode && noMatchingDomainCode){
			return;
		}
		if(!$scope.refDataForm.domainCode && !$scope.refDataForm.referenceCode && 
				!$scope.refDataForm.displayValue){
			$scope.errorMessage="narrative.search.error";
			$scope.scrollToTop();
			return;
		}
		$scope.showLoader('Please wait');
		$http.post('refDataController/getSearchResult/', $scope.refDataForm)
		.then(function(response){
			$scope.searchResult = response.data.searchResult;
			$scope.hideLoader();
		})
	}
	$scope.clearForm = function(){
		$scope.refDataForm.domainCode='';
		$scope.refDataForm.referenceCode='';
		$scope.refDataForm.displayValue='';
		$scope.refDataForm.statusCode='';
	}
	$scope.addRecord = function(){
		$rootScope.isReadyOnlyField=false;
		$state.go("mrpApp.addRefData");
	}
	$scope.editRecord = function(refDataId){
		$rootScope.isReadyOnlyField=true;
		$state.go("mrpApp.editRefData",{refDataId:refDataId});
	}
	$scope.saveRefData = function(action, validFlag){
		$scope.submitted=true;
		$scope.errorMessage=null;
		/*var domainList=$rootScope.domainCodeList;
		var domainCode=$scope.refData.domainCode;
		if(domainList.indexOf(domainCode) > -1){
			$scope.noMatchingDomainCode=false;
		}else{
			validFlag=false;
			$scope.noMatchingDomainCode=true;
		}*/
		if(validFlag){
			$scope.showLoader('Please wait');
			$http.post('refDataController/saveRefData/', $scope.refData)
			.then(function(response){
				$scope.submitted=false;
				if(response.data.errorOccured){
					$scope.errorMessage=response.data.errorMessage;
					$scope.hideLoader();
					$scope.scrollToTop();
				}else{
					$scope.showModal('Success','Ref Data has been saved successfully.','success');
					if(action=='APPLY'){
						$scope.hideLoader();
						$scope.refData = response.data.refData;
						$scope.refDataForHeader=response.data.refData;
					}else
						$state.go("mrpApp.refDataSearch");
				}
				
			})
		}
	}
	$scope.cancel = function(){
		$state.go("mrpApp.refDataSearch");
	}
	$scope.numberValidation = function(maxlength){
		if(!$scope.refData.sortValue)
			$scope.sortOrderErr = "narrative.nosortorder";
		else if ($scope.refData.sortValue !='' && /\D/g.test($scope.refData.sortValue)) {
			$scope.refData.sortValue = $scope.refData.sortValue.replace(/\D/g,'');
			$scope.sortOrderErr = "narrative.negetivesortorder"
		}
		if($scope.refData.sortValue.length>maxlength){
			$scope.refData.sortValue = $scope.refData.sortValue.substring(0,maxlength);
		}
			
		//if($scope.refData.sortValue<0)
			
	}
	$scope.errorOnFocus=function(isValid){
		if(!isValid){
			$scope.scrollToFormError();
			return false;
		}
	}
});