'use strict';

app.controller('PriorityController', function($rootScope,
		$q, $scope, $state, $stateParams, APP_CONFIG, $http, $location,
		InitPageService) {
	$scope.config = APP_CONFIG;
	var domainCodes = [ "SDMOutcome" ];
	InitPageService.initPage($scope, domainCodes);
	
	$scope.initQuestionaire = function() {	
		if(!isNaN($stateParams.priorityToolId)){
			$scope.showLoader('Please Wait..');
			$http(
					{
						method : 'GET',
						url : 'priorityTool/getQuestionaire/'
								+ $stateParams.priorityToolId 
					})
					.then(function(response) {
						$scope.toolName=$stateParams.toolName;
						$scope.questionData = response.data;
						$scope.priorityQuestions = $scope.questionData.questionaires;
						$scope.displayQuestion(1);
						$scope.hideLoader();
					});
		}
		
		
	};
	$scope.nextQuestion = function() {
		if(_.isEmpty($scope.current.selectedAnswer)){
			alert("Please select an option");//add validation
		}else{
			if(isNaN(parseInt($scope.current.selectedAnswer))){
				$scope.displaySummary($scope.current.selectedAnswer);
			}else if(!isNaN(parseInt($scope.current.selectedAnswer))){
				$scope.displayQuestion($scope.current.selectedAnswer)
			}
		}
	};
	
	$scope.previousQuestion = function() {
		$scope.displayQuestion($scope.current.questionNumber - 1);
	};
	
	$scope.displayQuestion = function(selection){
		angular.forEach($scope.priorityQuestions, function(question) {
			if (question.questionNumber == selection) {
				$scope.current = question;
			}
		});
	};
	
	$scope.displaySummary = function(priority){
		$state.transitionTo("intro.recommendation", {
			'priority' : priority
		}, {
			notify : true,
			reload : true
		});
	};
	
	$scope.exit = function(){
		var url = $location.$$absUrl;
		window.location.href = url.substring(0,url.indexOf("MRPortal"))+"child-protection-portal";
		
	};
	

});