'use strict';

app.controller('AllegationController', function($rootScope, $q,
		$scope, $state, $stateParams, APP_CONFIG, $http, $window,$timeout,
		InitPageService, $parse, DateFormatService) {
	
	$rootScope.showBreadcrumbs = true;
	$rootScope.currentState = $state.current.name;
	$scope.config = APP_CONFIG;
	var domainCodes = [ "AllegationType", "TimeZone", "AMPM" ];
	InitPageService.initPage($scope, domainCodes);
	$scope.showLessVictimsArr={};
	$scope.showLessPerpetratorsArr={};
	$scope.sortType = '-participantId'; // set the default sort type
	$scope.sortType1 = '-participantId';
	$scope.sortType2 = '-allegationGroupId';
	$scope.initAllegations = function() {
		$stateParams.complaintId = $rootScope.complaint.complaintId;
		$rootScope.linkToActive="allegation";
		$rootScope.disableAllegation=false;
		$scope.showLoader('Please Wait..')
		if (_.isEmpty($stateParams.allegationGroupId)
				|| $stateParams.allegationGroupId == 0) {
			$http(
					{
						method : 'GET',
						url : 'allegationGroup/getAllegationParticipants/'
								+ $stateParams.complaintId + '/0'
					}).then(function(response) {
				$scope.allegationData = response.data;//input ? trueValue : falseValue;
				$scope.allegationCopy = angular.copy($scope.allegationData);
  				$rootScope.allegationDataChanged = false;
				$scope.hideLoader();
			});
		} else {
			$http(
					{
						method : 'GET',
						url :  'allegationGroup/getAllegationParticipants/'
								+ $stateParams.complaintId + '/'
								+ $stateParams.allegationGroupId
					}).then(function(response) {
				$scope.allegationData = response.data;
				var formatedData = DateFormatService.getTimeAMPM($scope.allegationData.abuseOrNeglectDateTime);
				//allegationData.dateOfAbuse
				$scope.allegationData.dateOfAbuse = formatedData.receivedDate;
				if($scope.allegationData.dateOfAbuse)
					$scope.allegationData.dateOfAbuse = new Date($scope.allegationData.dateOfAbuse);
				$scope.allegationData.timeOfAbuse = formatedData.receivedTime;
				$scope.allegationData.ampm = formatedData.receivedAMPM;	
				$scope.allegationCopy = angular.copy($scope.allegationData);
  				$rootScope.allegationDataChanged = false;
				$scope.hideLoader();
			});
		}
		$http(
			{
				method : 'GET',
				url : 'allegationGroup/retrieveAllegationGroups/'
						+ $stateParams.complaintId
			}).then(
			function(response) {
				$scope.allegationGroupRecords = response.data;
				
				if(!$scope.allegationGroupRecords || $scope.allegationGroupRecords.length<1){
					$rootScope.disableAdditionalInfo=true;
					$rootScope.allegationSaved=false;
					
					
				}
				if($scope.allegationGroupRecords && $scope.allegationGroupRecords.length > 0){
					$rootScope.disableAdditionalInfo=false;
					$rootScope.allegationSaved=true;
					$rootScope.complaint.allegationDataAvailableFlag=1;
				}else{
					$rootScope.complaint.allegationDataAvailableFlag=0;
				}
					
				angular.forEach($scope.allegationGroupRecords, function(record, index) {
					$scope.showLessVictimsArr[index]=true;
					$scope.showLessPerpetratorsArr[index]=true;
				});
			});
	}
	
	
	$scope.saveAll = function(allegationData, action, noNarrative) {
		if(noNarrative){
			return;
		}
		$scope.submitted = true; // Flag to set form status
		if(!_.isEmpty($scope.allegationGroupRecords)){
		//if(allegationData.allegationNotes!=null){
			if(allegationData.allegationNotes==null)
				allegationData.allegationNotes=" ";
			$scope.showLoader('Saving Data..');
			$http.post(
				 'allegationGroup/saveNarrative/',
					allegationData).then(							
			function(response) {
				$scope.hideLoader();
				$rootScope.complaint.allegationDataAvailableFlag=1;
				$rootScope.allegationSaved=true;
				$rootScope.disableAdditionalInfo=false;
				$scope.showModal('Success','Allegation is saved','success');
				$timeout(function() {
					$scope.closeModal();
				},3000);
				if(action=="SAVE"){
					$state.transitionTo("mrpApp.allegations", {
						'complaintId' : $stateParams.complaintId
					}, {
						notify : true,
						reload : true
					});
				}
				if(action=="SAVEANDCONT"){
					$state.transitionTo("mrpApp.additionalInfo", {
						'complaintId' : $stateParams.complaintId
					}, {
						notify : true,
						reload : true
					});
				}
				$rootScope.allegationDataChanged = false;
			});		
		/*}else{
			$scope.scrollToFormError();
		}*/
		}else{
			$scope.showModal('Error','An allegation record has to be added to save allegation notes','error');
			/*$timeout(function() {
				$scope.closeModal();
			},3000);*/
		}
	}
	
	$scope.showMorePerpetrators = function(index){
		$scope.showLessPerpetratorsArr[index]=false;
	}
	$scope.showMoreVictims = function(index){
		$scope.showLessVictimsArr[index]=false;
	}
	$scope.showLessVictms = function (index){
		$scope.showLessVictimsArr[index]=true;
	}
	$scope.showLessPerpetrtors=function (index){
		$scope.showLessPerpetratorsArr[index]=true;
	}
	
	$scope.saveAllegations = function(allegationData) {
		var valid = true;
		$scope.submitted = true;
		
		if ($scope.validateForm(allegationData,valid)) {
			$scope.showLoader('Saving Data..')
			var fullDate = DateFormatService.getProperDate(
					allegationData.dateOfAbuse,
					allegationData.timeOfAbuse,
					allegationData.ampm);
			allegationData.abuseOrNeglectDateTime = fullDate;
			$http.post(
					 'allegationGroup/saveAllegationGroup/',
					allegationData).then(
							
			function(response) {
				$scope.hideLoader();
				if (response.data.errorMessage == undefined) {
					//alert("Allegation is saved");
					$rootScope.disableAllegation=false;
					$rootScope.disableAdditionalInfo=false;
					$rootScope.allegationSaved = true;
					$scope.showModal('Success','Allegation is saved','success');
					$scope.allegationData = response.data;
					$timeout(function() {
						$scope.closeModal();
						$rootScope.allegationDataChanged = false;
						$state.transitionTo("mrpApp.allegations", {
							'complaintId' : $stateParams.complaintId
						}, {
							notify : true,
							reload : true
						});
					},3000);					
				} else {
					$scope.showModal('Error',response.data.errorMessage,'error');
					/*$timeout(function() {
						$scope.closeModal();
					},3000);*/
				}
			}, function(errResponse) {
				$scope.hideLoader();
				$scope.showModal('Error','Error! Data not saved','error');
				/*$timeout(function() {
					$scope.closeModal();
				},3000);*/
				return $q.reject(errResponse);
			});
		}
		else {
			// Scroll top  to show Error
			$scope.scrollToFormError();
			return false;
		}
	};
	$scope.validateForm = function(allegationData,valid) {
		var victimSelected = false;
		var perpetratorSelected = false;

		$scope.dateOfAbuseErr = false;
		if (allegationData.dateOfAbuse==null || new Date(allegationData.dateOfAbuse) > new Date()) {
			$scope.dateOfAbuseErr = true;
			$scope.focusTo("dateOfAbuse");
			valid=false;
		}
		$scope.timeOfAbuseErr = false;
		if (allegationData.timeOfAbuse==null 
				|| _.isEmpty(allegationData.ampm)
				|| _.isEmpty(allegationData.timeZoneOfAbuseOrNeglect)) {
			$scope.timeOfAbuseErr = true;
			$scope.focusTo("timeOfAbuse");
			valid=false;
		}
		$scope.allegationTypeErr = false;
		if (_.isEmpty(allegationData.allegationType)
				|| allegationData.allegationType == "null") {
			$scope.allegationTypeErr = true;$scope.focusTo("AllegationType");
			valid=false;
		}
		$scope.victimSelectedErr = false;
		angular.forEach(allegationData.allegedVictims, function(victim) {
			if (victim.selected) {
				victimSelected = true;
			}
		});
		if (!victimSelected) {
			$scope.victimSelectedErr = true;
			valid=false;
		}
		$scope.perpSelectedErr = false;
		angular.forEach(allegationData.allegedPerpetrators, function(
				perpetrator) {
			if (perpetrator.selected) {
				perpetratorSelected = true;
			}
		});
		if (!perpetratorSelected) {
			$scope.perpSelectedErr = true;
			valid=false;
		}
		return valid;
	};
	
	$scope.deleteAllegationGroup = function(allegationGroupId) {
		$scope.allegationToDeleteId = allegationGroupId;
		$scope.showConfirmModal('Delete', 'Do you really want to delete ?',
				$scope.deleteRecord, $scope.onCancel);
	};	
	$scope.deleteRecord = function() {
	    	$scope.hideConfirmModal();
	    	$http(
					{
						method : 'GET',
						url : 'allegationGroup/deleteAllegationGroup/'
								+ $scope.allegationToDeleteId
						}).then(function(response) {
							if (response.data.errorMessages == undefined) {
								$state.transitionTo("mrpApp.allegations", {
									'complaintId' : $stateParams.complaintId
								}, {
									notify : true,
									reload : true
								});
							}else{
								$scope.errMsg = response.data.errorMessages;
								$('html, body').animate({scrollTop : 0},500);
							}
							
						}, function(errResponse) {
							return $q.reject(errResponse);
						});
	};
	$scope.onCancel = function() { //On Click of Cancel in the confirmation popup
	    $scope.hideConfirmModal();;
    }
	$scope.focusTo = function(focusItem){
    	focusItem=$("#"+focusItem);
    	$('html,body').animate({
            scrollTop: focusItem.offset().top - 150},
            'slow',function() {
            	focusItem.focus();
        });
    };
    $scope.cancel = function(){
    	$scope.allegationData={};
    	$rootScope.allegationDataChanged = false;
    	$state.transitionTo("mrpApp.home",{ notify: true ,reload: true});
    };
    $scope.$watch('allegationData', function () {
		if($scope.allegationCopy!=undefined && $scope.allegationCopy!=null && $scope.allegationData!=undefined && $scope.allegationData!=null){
			if($scope.allegationCopy.ampm!= $scope.allegationData.ampm
					||($scope.allegationCopy.timeOfAbuse!= $scope.allegationData.timeOfAbuse && $scope.allegationData.timeOfAbuse!='')
					||$scope.allegationCopy.timeZoneOfAbuseOrNeglect!= $scope.allegationData.timeZoneOfAbuseOrNeglect
					||$scope.allegationCopy.allegationType!= $scope.allegationData.allegationType
					||$scope.allegationCopy.dateOfAbuse!= $scope.allegationData.dateOfAbuse
					||$scope.allegationCopy.allegationNotes!= $scope.allegationData.allegationNotes)
			$rootScope.allegationDataChanged = true;
			else
				$rootScope.allegationDataChanged = false;
		}
	}, true);
});