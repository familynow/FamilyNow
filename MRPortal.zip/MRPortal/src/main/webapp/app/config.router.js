﻿'use strict';
angular.module('app')
    .run(
        [
            '$rootScope', '$state', '$stateParams','$location',
            function($rootScope, $state, $stateParams,$location) {
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
				var host = $location.host();
				console.log('host ' , host);
            }
        ]
    )
    .constant('APP_CONFIG', 
    		{'APP_NAME'		: 'Mandatory Reporter Portal',
    	 	 'APP_VERSION'	: '1.0',
    	 	 'BASE_URL'		: '/MRPortal/',
    	 	 'sortReverse'  : 'true',  // set the default sort order
    	 	 'itemsPerPage' : '5',		// set the maximum number of records per page
    	 	 'pageSize' 	: '11',		// set the maximum number of page links to be shown on the pagination bar (Set value to be +1 bug in the Framework)
    	 	 'dateOptions' 	: {formatYear: 'yy',startingDay: 1},
    	 	 'dateTimeFormat' : 'MMM dd, yyyy hh:mm a'
    		}
    )
    .config(
        [
            '$stateProvider', '$urlRouterProvider','$locationProvider','APP_CONFIG',
            function($stateProvider, $urlRouterProvider, $locationProvider,APP_CONFIG) {            	
            	//console.log('APP_CONFIG ' , APP_CONFIG);

            	// use the HTML5 History API
                $locationProvider.html5Mode(true);
                //$urlRouterProvider.otherwise('/prelogin/login');
                $urlRouterProvider.otherwise(function($injector, $location, $q) {
                    var $state = $injector.get('$state');
                    var url = $location.$$url;
                    
                    if (url != '') {
						if(url.indexOf('confirmRegistration') != -1){
							$state.go('prelogin.regConfirm',{'token':$location.search().token});
						}else if(url.indexOf('createPassword') != -1){
							$state.go('prelogin.resetForgotPassword',{'token':$location.search().token});
						}else{
							url = url.replace('/', '');
							if(url != '')
								$state.go(url);
							else
							$state.transitionTo('prelogin.login');
						}
					}
                    else {
						$state.transitionTo('prelogin.login');
					}
                });
                
                $stateProvider
                    .state('mrpApp', {
                        abstract: true,
                        url: '/mrpApp',
                        templateUrl: 'views/common/layout.html'
                    })

                    .state('mrpApp.home', {
                        url: '/home',
                        templateUrl: 'views/mrp/complaints/home.html',
                        ncyBreadcrumb: {
                            label: 'My Complaints',
                            description: ''
                        },
                        controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="home";
	                		$rootScope.showWizard = false;
	          
	                	}],
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/complaints-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                                        
                    .state('mrpApp.allegations', {
                        url: '/allegations',
                        templateUrl: 'views/mrp/complaints/complaint-allegations.html',
                        ncyBreadcrumb: {
                            label: 'Allegations',
                            description: 'Add and Display Allegations'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";
	                		$rootScope.participantDataChanged = false;
	                	}],
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/allegation-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    .state('mrpApp.editAllegation', {
                        url: '/allegations/edit-allegation/:allegationGroupId',
                        templateUrl: 'views/mrp/complaints/complaint-allegations.html',
                        ncyBreadcrumb: {
                            label: 'Allegations',
                            description: 'Add and Display Allegations'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";  
	                		$rootScope.showWizard = true;
	                	}],
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/allegation-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.personProfile', {
                        url: '/personProfile',
                        templateUrl: 'views/mrp/complaints/person-profile.html',
                        params:{userState:null,complaintState:null,complaintId:null,userId:null,complaint:null},
                        ncyBreadcrumb: {
                            label: 'Reporter Profile',
                            description: 'Reporter Profile'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                    	if($rootScope.complaint && $rootScope.complaint.complaintStatus=='SUBMITTED'){
	                    		
	                    	}
	                    	else{
	                    		$rootScope.coplaintName=null;
	                    	}
	                    	$rootScope.sidebar="complaint";
	                    	$rootScope.showWizard = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/reporting-person-controller.js']
                                    });
                                }
                            ]
                        }
                    })  
                    
                    .state('mrpApp.complaintParticipants', {
                        url: '/complaintParticipant',
                        templateUrl: 'views/mrp/complaints/complaint-participants.html',
                        ncyBreadcrumb: {
                            label: 'Complaint Participants',
                            description: 'Complaints Participants'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";
	                		$rootScope.showWizard = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/report-participant-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.addComplaintParticipants', {
                        url: '/complaintParticipant',
                        templateUrl: 'views/mrp/complaints/complaint-participants.html',
                        ncyBreadcrumb: {
                            label: 'Complaint Participants',
                            description: 'Complaints Participants'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";
	                		$rootScope.showWizard = true;
	                		$rootScope.profileSaved = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/report-participant-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.editParticipant', {
                        url: '/complaintParticipant/:complaintParticipantId',
                        templateUrl: 'views/mrp/complaints/complaint-participants.html',
                        ncyBreadcrumb: {
                            label: 'Complaint Participants',
                            description: 'Complaints Participants'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                    	$scope.editMode=true;
	                		$rootScope.sidebar="complaint";
	                		$http({
	                    		method : 'GET',
	                			url : 'complaintParticipant/editComplaintParticipant/'+ $stateParams.complaintParticipantId
	                    	}).then(function(response){
	                    		$scope.participantData=response.data.complaintParticipant;
	                    		if($scope.participantData.birthDate)
	                    			$scope.participantData.birthDate=new Date($scope.participantData.birthDate);
	                    		if($scope.editMode) {
	                    			$scope.scrollToTarget('fname');
	                    		}
	                    	});
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/report-participant-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.additionalInfo', {
                        url: '/additonal-information',
                        templateUrl: 'views/mrp/complaints/additonal-information.html',
                        ncyBreadcrumb: {
                            label: 'Additional Information',
                            description: 'Additional Information'
                        },
                        controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "complaint";
	                		$rootScope.showWizard = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/additional-info-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.supportingDocs', {
                        url: '/supporting-docs',
                        templateUrl: 'views/mrp/complaints/supporting-documentation.html',
                        ncyBreadcrumb: {
                            label: 'Supporting Documentation',
                            description: 'Supporting Documentation'
                        },
                        controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";
	                		$rootScope.showWizard = true;
	                		$rootScope.profileSaved = true;
	                		$rootScope.participantSaved = true;
	                		$rootScope.allegationSaved = true;
	                		$rootScope.additionalInfoDataChanged = false;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/supporting-docs-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.editUser',{
                    	url: '/editUser/:userAccountId',
                        templateUrl: 'views/mrp/userDetails.html',
                        ncyBreadcrumb: {
                            label: 'User Maintenance',
                            description: 'User Maintenance screen for editing Users'
                        },
                        controller: ['$http','$scope','$stateParams',function($http, $scope, $stateParams){
                    		return $http({method: 'GET', url: APP_CONFIG.BASE_URL + 'editUser/' + $stateParams.userAccountId})
                    		.then(
                    			function(response){
                    				console.log('response.data ', response.data);
                    				$scope.clientData = response.data;
                    			}
                    		);
                    	}]
                    })
                    .state('mrpApp.usergroup', {
                        url: '/usergroup',
                        templateUrl: 'views/tables-simple.html',
                        ncyBreadcrumb: {
                            label: 'User Groups',
                            description: 'User Group screen for adding and maintaining Users'
                        }
                    })
                    .state('mrpApp.assignusergroup', {
                        url: '/assignusergroup',
                        templateUrl: 'views/tables-simple.html',
                        ncyBreadcrumb: {
                            label: 'Tables',
                            description: 'Assign User Groups'
                        }
                    })
                     .state('mrpApp.complaintSummary', {
                        url: '/complaintSummary',
                        templateUrl: 'views/mrp/complaints/complaint-summary.html',
                        ncyBreadcrumb: {
                            label: 'Complaint Summary',
                            description: 'Complaints Summary'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="complaint";
	                		$rootScope.showWizard = true;
	                		$rootScope.profileSaved = true;
	                		$rootScope.participantSaved = true;
	                		$rootScope.allegationSaved = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/complaint-summary-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    /**** Admin related states ****/
                    .state('mrpApp.userList',{
                    	url: '/userList',
                        templateUrl: 'views/mrp/admin/maintain-user-list.html',
                        ncyBreadcrumb: {
                            label: 'Maintain User List',
                            description: 'Maintain User List'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "home";
	                		$rootScope.showWizard = false;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/user-maintenance-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.sdmTool',{
                    	url: '/sdmTools',
                        templateUrl: 'views/mrp/admin/sdm-tool.html',
                        ncyBreadcrumb: {
                            label: 'SDM Tool',
                            description: 'SDM Tool'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "home";
	                		$rootScope.showWizard = false;
	                		$scope.toolList={};
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/sdm-management-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.addSDMTool',{
                    	url: '/sdmTools/add',
                        templateUrl: 'views/mrp/admin/sdm-tool-details.html',
                        params:{sdmList:null},
                        ncyBreadcrumb: {
                            label: 'Add SDM Tool',
                            description: 'Add SDM Tool'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "";
	                		$rootScope.showWizard = false;
	                		$scope.toolDetails={};
	                		$scope.sdmList=$stateParams.sdmList;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/sdm-management-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.editSDMTool',{
                    	url: '/sdmTools/edit/:sdmToolId',
                        templateUrl: 'views/mrp/admin/sdm-tool-details.html',
                        params:{sdmToolId:null,sdmList:null},
                        ncyBreadcrumb: {
                            label: 'SDM Tool Details',
                            description: 'SDM Tool Details'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "";
	                		$rootScope.showWizard = false;
	                		$scope.showLoader('Please Wait');
	                		$scope.sdmList=$stateParams.sdmList;
	                		return	$http({method : 'GET',url : 'manageSDMTool/getSDMToolDetails/'+$stateParams.sdmToolId})
		                		.then(function(response) {
		                			$scope.toolDetails=response.data;
		                			$scope.sortType="priorityQuestionNumber";
		                			$scope.hideLoader();
		                		})
	                    }],
	                    resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/sdm-management-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    .state('mrpApp.addSDMQuestion',{
                    	url: '/question/add/:sdmToolId',
                        templateUrl: 'views/mrp/admin/sdm-question-details.html',
                        params:{sdmTool:null,sdmToolId:null},
                        ncyBreadcrumb: {
                            label: 'Add SDM Question',
                            description: 'Add SDM Question'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "";
	                		$rootScope.showWizard = false;
	                		$scope.question={};
	                		$scope.questionDeatils={};
	                		$scope.priorityToolId=$stateParams.sdmToolId;
	                		$scope.editMode=false;
	                    }],
	                    resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/sdm-management-controller.js']
                                    });
                                }
                            ]
                        }
                    })

                    .state('mrpApp.editSDMQuestion',{
                    	url: '/question/edit/:questionId',
                        templateUrl: 'views/mrp/admin/sdm-question-details.html',
                        params:{priorityListId:null,questionId:null,sdmToolDetails:null},
                        ncyBreadcrumb: {
                            label: 'Add SDM Question',
                            description: 'Add SDM Question'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "home";
	                		$rootScope.showWizard = false;
	                		$scope.question={};
	                		$scope.priorityToolId=$stateParams.sdmToolId;
	                		return	$http({method : 'GET',url : 'manageSDMTool/getQuestionDetails/'+$stateParams.priorityListId})
	                		.then(function(response) {
	                			$scope.questionDeatils=response.data;
	                			$scope.priorityToolId=response.data.priorityToolId;
	                			$scope.editMode=true;
	                			$scope.sdmToolDetails=$stateParams.sdmToolDetails;
	                			$scope.submitted = false;
	                			$scope.noOptionsSelected=false;
	                			$scope.hideLoader();
	                		})
	                    }],
	                    resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/sdm-management-controller.js']
                                    });
                                }
                            ]
                        }
                    })                  
                    
                    //mrpApp.myProfile
                 
                     .state('mrpApp.myProfile',{
                    	url: '/my-profile',
                        templateUrl: 'views/mrp/my-profile.html',
                        //params:{sdmList:null},
                        ncyBreadcrumb: {
                            label: 'My Profile',
                            description: 'My Profile'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                    	$rootScope.sidebar='';
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/my-profile-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('mrpApp.refDataSearch',{
                    	url: '/ref-data-search',
                        templateUrl: 'views/mrp/admin/narratives.html',
                        ncyBreadcrumb: {
                            label: 'Narratives',
                            description: 'Narratives'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar = "home";
	                		$rootScope.showWizard = false;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/ref-data-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    //mrpApp.editRefData
                     .state('mrpApp.editRefData', {
                        url: '/edit/:refDataId',
                        templateUrl: 'views/mrp/admin/narrative-details.html',
                        params: {refDataId:null},
                        ncyBreadcrumb: {
                            label: 'Ref data/Narrative Details',
                            description: 'Ref data/Narrative Details'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="home";
	                		$http({
	                    		method : 'GET',
	                			url : 'refDataController/getRefDataById/'+ $stateParams.refDataId
	                    	}).then(function(response){
	                    		$scope.editMode=true;
	                    		$scope.submitted=false;
	                    		$scope.refData=response.data.refData;
	                    		$scope.refDataForHeader = angular.copy(response.data.refData);
	                    	});
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/ref-data-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    .state('mrpApp.addRefData', {
                        url: '/add/',
                        templateUrl: 'views/mrp/admin/narrative-details.html',
                        ncyBreadcrumb: {
                            label: 'Ref data/Narrative Details',
                            description: 'Ref data/Narrative Details'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$rootScope.sidebar="home";
	                		$scope.editMode=false;
	                		$scope.noMatchingDomainCode=false;
	                		$scope.refData={};
                    		$scope.refDataForHeader = {};
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/ref-data-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    /**** Before Login States ****/
                    
                    .state('intro', {
                        abstract: true,
                        url: '/intro',
                        templateUrl: 'views/common/layout-intro.html'
                    })
                    
                    .state('intro.startGuide', {
                        url: '/start-guide',
                        templateUrl: 'views/common/guide/start-guide.html',
                        ncyBreadcrumb: {
                            label: 'Start Guide',
                            description: 'Start Guide'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		//$rootScope.hideLogin = true;
	                	}]
                    })
                    
                    .state('intro.priorityQuestions', {
                        url: '/priority-questions/:priorityToolId',
                        templateUrl: 'views/common/guide/priority-questions.html',
                        ncyBreadcrumb: {
                            label: 'Priority Questions',
                            description: 'Priority Questions'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		//$rootScope.hideLogin = true;
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/priority-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
                    .state('intro.recommendation', {
                        url: '/priority-recommendation/:priority',
                        templateUrl: 'views/common/guide/recommendation.html',
                        ncyBreadcrumb: {
                            label: 'Recommendation',
                            description: 'Recommendation'
                        },
	                    controller: ['$http','$scope','$stateParams','$rootScope',function($http, $scope, $stateParams, $rootScope){
	                		$scope.priority = $stateParams.priority
	                	}],
	                	resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/priority-controller.js']
                                    });
                                }
                            ]
                        }
                    })
                    
	                .state('prelogin', {
	                    url: '/prelogin',
	                    templateUrl: 'views/common/layout-prelogin.html',
	                    resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        serie: true,
                                        files: ['app/controllers/framework/dashboard.js','app/controllers/signup-controller.js']
                                    });
                                }
                            ]
                        }
	                })
	                
	                .state('prelogin.login', {
	                    url: '/login',
	                    templateUrl: 'views/common/login.html',
	                    params : {registrationMsg : null}
	                })
	                .state('prelogin.regConfirm', {
	                    url: '/regConfirm',
	                    templateUrl: 'views/common/login.html',
	                    params : {token:null}
	                })
	                .state('prelogin.forgotpassword', {
	                    url: '/forgotpassword',
	                    templateUrl: 'views/common/forgot-password.html',
	                    //params : {registrationMsg : null}
	                })
	                .state('prelogin.resetForgotPassword', {
	                    url: '/reset-password-confirm',
	                    templateUrl: 'views/common/reset-forgot-password.html',
	                    params:{token:null}
	                })
	                
	                .state('prelogin.unauthorized', {
	                    url: '/unauthorized-access',
	                    templateUrl: 'views/common/unauthozed-access.html'
	                })
	                .state('prelogin.resetpassword', {
	                    url: '/resetPassword',
	                    templateUrl: 'views/common/resetpassword.html'
	                    
	                })
	                
	                .state('prelogin.signup', {
	                    url: '/signup',
	                    templateUrl: 'views/common/signup.html'
	                })
	                .state('mrpApp.regConfirm',{
						url : '/confirm',
						templateUrl : 'views/common/reg-confirm.html',
						params:{token:null}
					})
	                .state('prelogin.postSignup', {
	                    url: '/post-signup',
	                    templateUrl: 'views/common/post-signup.html'
	                })	
	                
	                 .state('mrpApp.contactUs', {
                        url: '/contactUs',
                        templateUrl: 'views/common/contact-us.html',
                        label: 'Contact Us'
                     })
                  
	                
            }
        ]
    );