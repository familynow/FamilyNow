/**
 * Ref Data Filter - This filter get lookupcode and domain code as in input and return their respective short description.
 */
app.filter('refDataShortDescription',['RefdataService' , function(refdataService)  {
	
	return function(lookupCode,domainCode) {
		var shortDesc='';		
		var refDataArray =  refdataService.getRefdata(domainCode);
		for(var i in refDataArray){
			if(refDataArray[i].lookupCode == lookupCode)
				shortDesc = refDataArray[i].shortDescription;				
		}
		return shortDesc;
	}
}]);

app.filter('refDataLongDescription',['RefdataService' , function(refdataService)  {
	
	return function(lookupCode,domainCode) {
		var longDesc='';		
		var refDataArray =  refdataService.getRefdata(domainCode);
		for(var i in refDataArray){
			if(refDataArray[i].lookupCode == lookupCode)
				longDesc = refDataArray[i].longDescription;				
		}
		return longDesc;
	}
}]);
app.filter('errorMessageText',['ErrorMessageService' , function(errorMessageService)  {	
	return function(errorCode) {
		var errorDesc =  errorMessageService.getErrorMessage(errorCode);
		console.log('errorMessageText ', errorDesc);
		return errorDesc;
	}
}]);
app.filter('PhoneNumberFormat', function () {
    return function (PhoneNumberFormat) {
        console.log(PhoneNumberFormat);
        if (!PhoneNumberFormat) { return ''; }

        var value = PhoneNumberFormat.toString().trim().replace(/^\+/, '');

        if (value.match(/[^0-9]/)) {
            return PhoneNumberFormat;
        }

        var country, city, number;

        switch (value.length) {
            case 1:
            case 2:
            case 3:
                city = value;
                break;

            default:
                city = value.slice(0, 3);
                number = value.slice(3);
        }

        if(number){
            if(number.length>3){
                number = number.slice(0, 3) + '-' + number.slice(3,7);
            }
            else{
                number = number;
            }

            return ("(" + city + ") " + number).trim();
        }
        else{
            return "(" + city;
        }

    };
});