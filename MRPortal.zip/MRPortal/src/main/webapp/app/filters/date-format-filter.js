/**
 * 
 */

app.filter('dateFormatFilter',[ function()  {
	
	return function(input) {
		var expectedDateFormat='';
		//alert(input);
		if(input!=null){			
		
				var intakeDate = new Date(input);
				var currentDate = new Date();
				var timeDiff = Math.abs(currentDate.getTime() - intakeDate.getTime());
				var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
				var amOrPM='';
				var hours = intakeDate.getHours();
				if(hours < 12){					
					amOrPM = 'AM'
				}else{					
					hours = hours - 12;					
					amOrPM='PM'
				}
				hours = hours==0?12:hours;
				//var hours = intakeDate.getHours();
				if(hours < 10){
				hours='0'+hours;
				}
				
				hours = hours+':'+intakeDate.getMinutes();
				
				var intakeDateWithZero= intakeDate.getDate();
				if(intakeDateWithZero < 10){
					intakeDateWithZero='0'+intakeDateWithZero;
				}
				
				var intakeMonthWithZero= intakeDate.getMonth()+1;
				if(intakeMonthWithZero < 10){
					intakeMonthWithZero='0'+intakeMonthWithZero;
				}
				
				var dateFormatToDisplay = (intakeMonthWithZero) + '/' + intakeDateWithZero + '/' +  intakeDate.getFullYear();
				
				expectedDateFormat = diffDays+' days  (on '+ hours+' '+amOrPM+ ' '+dateFormatToDisplay+')';
	}
		return expectedDateFormat;
	    }
    }]);

app.filter('ageFormat', function () {
	return function (dob){
		try{
			if(!dob || dob == "" || (dob+"").trim()=="")
	    		return "";
			var bornMonth=new Date(dob).getMonth();
			var currentMonth=new Date().getMonth();
			var difInMoths=currentMonth-bornMonth;
			var diffInYr=new Date().getFullYear() - new Date(dob).getFullYear();
			var difInMothsText="";
			var diffInDays = new Date().getDate()-new Date(dob).getDate();
			var diffInDaysText="";
			if(diffInDays<=0)
				diffInDaysText="";
			if(diffInDays>1)
				diffInDaysText=diffInDays+" Days";
			else
				diffInDaysText=diffInDays+" Day";
			
			
			if(difInMoths != 0){
				if(difInMoths<0){
					difInMoths=12-difInMoths*(-1);
					if(diffInYr >0 )
						diffInYr=diffInYr-1;
				}
					
				if(difInMoths == 1){
	    			difInMothsText = difInMoths+" Month";
	    		}else{
	    			
	    			difInMothsText = difInMoths+" Months";
	    		}
			}else{
				if(diffInYr>1)
		    		return (diffInYr+" Years ");
				else if(diffInYr == 1)
					return "1 Year";
				return diffInDaysText;
			}
	    	if(diffInYr == 0){
	    		if(difInMoths==0)
	    			return ;
	    		else
	    			return difInMothsText;
	    	}
	    		
	    	if(diffInYr == 1){
	    		return ("1 Year "+difInMothsText);
	    	}
	    		
	    	if(diffInYr>1)
	    		return (diffInYr+" Years "+difInMothsText);
	        return "";	
		}catch(err){
			return "";
		}
	}
});