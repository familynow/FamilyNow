app.factory('exceptionHandler', ['$log', function($log) {  
    $log.debug('$log is here to show you that this is a regular factory with injection');

    var exceptionHandler = {
    	exceptionHandler: exceptionHandler
    };
    return exceptionHandler;
    function exceptionHandler(rejection) {
        console.error("An error occurerd here");
        return $q.reject(rejection);
    }
}]);