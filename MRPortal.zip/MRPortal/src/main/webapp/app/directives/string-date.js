angular.module('app')
  .directive('convertStringDate', function () {
      return {
          restrict: 'A',
          scope: {
          	datevalue: '='
          },
          link: function (scope, el, attrs) {
        	  //scope.dateValue = new Date(scope.dateValue);
          }
      };
  });