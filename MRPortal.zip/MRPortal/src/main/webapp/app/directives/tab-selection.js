angular.module('app')
	.directive('tabSelected', function ($compile) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
            	element.on('click', function() {
            		$('.selection-tabs li a').removeClass('selected');
            		element.addClass('selected');
            		$('.abuse-description').addClass('hidden');
            		console.log(attr.tabSelected);
            		$('#'+attr.tabSelected).removeClass('hidden');
            		$compile(element)(scope);
            	});
            }
        };
    })
    .directive('goBack', function ($compile,$window) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
            	element.on('click', function() {
                    $window.history.back();
                });
            }
        };
    });