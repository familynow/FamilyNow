// Directive For File Drag and Drop
angular.module('app').directive('fileDropzone',['$rootScope', function($rootScope) {
	return {
        restrict : "A",
        link: function (scope, element, attrs) {
        	 var checkSize,
            isTypeValid,
            processDragOverOrEnter,
            validMimeTypes;
        	processDragOverOrEnter = function (event) {
        		$('.dropzone').addClass('drag-on');
                if (event != null) {
                  event.preventDefault();
                }
                // event.dataTransfer.effectAllowed = 'copy';
                return false;
              };
              
              validMimeTypes = attrs.fileDropzone;
              
              checkSize = function(size) {
                var _ref;
                if (((_ref = attrs.maxFileSize) === (void 0) || _ref === '') || (size / 1024) / 1024 < attrs.maxFileSize) {
                  return true;
                } else {
                 // alert("File must be smaller than " + attrs.maxFileSize +
					// " MB");
                	scope.showModal('Information',"File must be smaller than " + attrs.maxFileSize + " MB",'info');
                	scope.$apply();
                  return false;
                }
              };

              isTypeValid = function(type) {//abc - //ABC
                if ((validMimeTypes === (void 0) || validMimeTypes === '') || validMimeTypes.toLowerCase().indexOf(type.toLowerCase()) > -1) {
                  return true;
                } else {
                 // alert("Invalid file type. File must be one of following
					// types " + validMimeTypes);
                	scope.showModal('Information',"Invalid file type.  File must be one of following types " + validMimeTypes,'info');
                	scope.$apply();
                  return false;
                }
              };
        	
            element.bind('dragover', processDragOverOrEnter);
            element.bind('dragenter', processDragOverOrEnter);
            element.bind('dragleave', function() {
            	$('.dropzone').addClass('drag-leave');
            });
            
            element.bind('drop', function(evt) {
            	var file, name, reader, size, type, fileSelected;
                if (event != null) {
                  event.preventDefault();
                }
                reader = new FileReader();
                reader.onload = function(evt) {
                  if (checkSize(size) && isTypeValid(type)) {
                    return scope.$apply(function() {
                      //scope.file = evt.target.result;
                      //scope.$parent.file = evt.target.result;
                      scope.fileSelected = fileSelected;
                      scope.$parent.fileSelected = fileSelected;
                      if (angular.isString(scope.fileName)) {
                    	scope.$parent.fileName = file.name;
                        return scope.fileName = name;
                      }
                    });
                  }
                };
                file = event.dataTransfer.files[0];
                fileSelected = event.dataTransfer.files[0];
                name = file.name;
                type = name.split('.').pop();
                size = file.size;
                //scope.$parent.fileName = file.name;
                reader.readAsDataURL(file);
                scope.$apply();
                return false;
            });
        }
    }
}])

// Directive for Normal File Browse and Check Size
.directive('fileBrowse', ['$rootScope', function($rootScope) {
	  return {
	    restrict: 'EA',
	    link: function (scope, element, attrs) {
	    	element.on('change', function  (evt) {
	    		var file,fileSelected;
	    		scope.files = evt.target.files;
	    		
	    		var reader = new FileReader();
                reader.onload = function (loadEvent) {
                	if((scope.files[0].size / 1024) / 1024 > attrs.maxFileSize) {
                		scope.showModal('Information',"File must be smaller than " + attrs.maxFileSize + " MB",'info');
    	    			scope.$apply();
    	    			return false;
    	    		}
                	else {
	                    scope.$apply(function () {
	                        //scope.file = loadEvent.target.result;
	                        //scope.$parent.file = loadEvent.target.result;
	                        scope.fileSelected = fileSelected;
	                        scope.$parent.fileSelected = fileSelected;
	                        scope.fileName = scope.files[0].name;
	                        scope.$parent.fileName = scope.files[0].name;
	                    });
                	}
                }
                file = evt.target.files[0];
                fileSelected = evt.target.files[0];
                reader.readAsDataURL(file);
                scope.$apply();
                return false;
                
            });
	    }
	  };
	}])


// directive for download
.directive('fileDownload',['$rootScope', function($rootScope){
    return{
        restrict:'A',
        scope:{
            fileDownload:'=',
            fileName:'=',
        },

        link:function(scope,elem,atrs){


            scope.$watch('fileDownload',function(newValue, oldValue){

                if(newValue!=undefined && newValue!=null){
                    console.debug('Downloading a new file'); 
                    var isFirefox = typeof InstallTrigger !== 'undefined';
                    var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
                    var isIE = /*@cc_on!@*/false || !!document.documentMode;
                    var isEdge = !isIE && !!window.StyleMedia;
                    var isChrome = !!window.chrome && !!window.chrome.webstore;
                    var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
                    var isBlink = (isChrome || isOpera) && !!window.CSS;

                    if(isFirefox || isIE || isChrome){
                        if(isChrome){
                            console.log('Manage Google Chrome download');
                            var url = window.URL || window.webkitURL;
                            var fileURL = url.createObjectURL(scope.fileDownload);
                            var downloadLink = angular.element('<a></a>');//create a new  <a> tag element
                            downloadLink.attr('href',fileURL);
                            downloadLink.attr('download',scope.fileName);
                            downloadLink.attr('target','_self');
                            downloadLink[0].click();//call click function
                            url.revokeObjectURL(fileURL);//revoke the object from URL
                        }
                        if(isIE){
                            console.log('Manage IE download>10');
                            window.navigator.msSaveOrOpenBlob(scope.fileDownload,scope.fileName); 
                        }
                        if(isFirefox){
                            console.log('Manage Mozilla Firefox download');
                            var url = window.URL || window.webkitURL;
                            var fileURL = url.createObjectURL(scope.fileDownload);
                            var a=elem[0];//recover the <a> tag from directive
                            a.href=fileURL;
                            a.download=scope.fileName;
                            a.target='_self';
                            a.click();//we call click function
                        }


                    }else{
                        alert('SORRY YOUR BROWSER IS NOT COMPATIBLE');
                    }
                }
            });

        }
    }
}]);
