angular.module('app')
	.directive('confirmPopup', function () {
        return {
            restrict: 'E',
            scope: {
            	confirmTitle: '=',
            	confirmContent: '=',
            	onConfirm: '&',
            	onCancel: '&'
            },
            templateUrl: 'views/partials/popup-confirm.html'
        };
    });