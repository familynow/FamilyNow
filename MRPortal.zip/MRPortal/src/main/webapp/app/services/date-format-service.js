'use strict';

/**
 * Date Format Service provides services to convert sql date to date,time, AM PM
 * and also vice versa
 */
app
		.service(
				'DateFormatService',
				[
						'$http',
						'APP_CONFIG',
						function($http, APP_CONFIG) {
							/*
							 * This method formats a date to
							 */
							this.getTimeAMPM = function(receivedDate) {
								var clientData = {};

								var newDate = new Date(receivedDate);
								var hours = newDate.getHours() > 12 ? newDate
										.getHours() - 12 : newDate.getHours();
								var am_pm = newDate.getHours() >= 12 ? "PM"
										: "AM";
								hours = hours == 0 ? 12 : hours;
								hours = hours < 10 ? "0" + hours : hours;
								var minutes = newDate.getMinutes() < 10 ? "0"
										+ newDate.getMinutes() : newDate
										.getMinutes();
								var time = hours + ":" + minutes;

								var idate = newDate.getDate() < 10 ? "0"
										+ newDate.getDate() : newDate.getDate();
								var imonth = newDate.getMonth() + 1 < 10 ? "0"
										+ (newDate.getMonth() + 1) : newDate
										.getMonth() + 1;
								clientData.receivedDate = newDate.getFullYear()
										+ "-" + imonth + "-" + idate;
								clientData.receivedTime = time;
								clientData.receivedAMPM = am_pm;
								return clientData;
							};

							this.getProperDate = function(inputDate,
									inputTime, inputAmPm) {
								var newDate = new Date(inputDate);
								if (inputTime != null && inputAmPm != null) {
									var t = inputTime + " " + inputAmPm;
									var parts = t.match(/(\d+)\:(\d+) (\w+)/);
									var hours = /am/i.test(parts[3]) ? (parts[1] == 12 ? parseInt(
											parts[1], 10) - 12
											: parseInt(parts[1], 10))
											: (parts[1] == 12 ? parseInt(
													parts[1], 10) : parseInt(
													parts[1], 10) + 12);
									var minutes = parseInt(parts[2], 10);

									newDate.setHours(hours);
									newDate.setMinutes(minutes);
								}
								return newDate;
							};
						} ]);