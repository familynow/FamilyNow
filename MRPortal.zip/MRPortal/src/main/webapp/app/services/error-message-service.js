'use strict';
/**
 * Error Message Service maintains all the error messages to be displayed on UI. 
 * This Service is written in such a way that it loads only the required error messages which are not in UI cache.
 * 
 */
app.service('ErrorMessageService', ['$http','APP_CONFIG',function($http,APP_CONFIG) {
	
	var $this = this;
	
	// cache object which will have error message objects as an array
	// // json structure : [{"errorMsgKey":"intake.dispoDate.complete","errorLocation":"ApplicationResources.properties","errorCategory":"ERROR",
	//						"errorMsgText":"Disposition date is required.","searchResults":null}]
	// TODO : this object can be maintained in session storage (local storage) if needed.
	this.errorMessage = [];
	
	/**
	 * this method retrieves error message from cache object, given a error message key.
	 */
	this.getErrorMessage = function(key){
		for(var i in $this.errorMessage){
			if($this.errorMessage[i] == key || $this.errorMessage[i].errorCode == key){
				return $this.errorMessage[i].errorMessage;
			}
		}
		return '';
	}
	
	/**
	 * this method adds error message for a new key into cache
	 */
	this.addErrorMessageToCache = function(newKey){
		console.log('addErrorMessageToCache ', newKey);
		for(var i in newKey){
			$this.errorMessage.push(newKey[i]);
		}
	}
	
	/**
	 * this method finds a list of given error messages in cache. it returns an array of keys which
	 * are not found in cache. this method can be used to load only required domain codes from server on page load.
	 */
	this.findErrorMessageInCache = function(keys){
		var keysNotInCache = [];
		if(_.isArray(keys)){
			for(var i in keys){
				if($this.getErrorMessage(keys[i]) === undefined){	
					keysNotInCache.push(keys[i]);
				}
			}
		}
		return keysNotInCache;
	}
	
	this.getErrorMessages = function(){
		return this.errorMessage;
	}
	
	/**
	 * this method returns the error message promise
	 */
	this.getErrorMessagePromise = function(keysTobeLoaded){
		return $http({method: 'GET', url:  'errorController/findErrorMessages'});
	}
	
}]);