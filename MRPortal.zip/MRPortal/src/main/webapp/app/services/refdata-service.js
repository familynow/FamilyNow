'use strict';

/**
 * Refdata service maintains reference data (all static data needed for dropdowns) in cache.This service enables 
 * the caller to identify if refdata related to a domain code is already loaded into cache. It enables the caller 
 * to retrieve and update cache.
 */
app.service('RefdataService', ['$http','APP_CONFIG',function($http,APP_CONFIG,$q) {
	
	var $this = this;
	// cache object which will have reference data objects mapped with its domain code.
	// json structure : {"domainCode":[{"refdatacode":"","shortdescription":""},{}]}
	// TODO : this object can be maintained in session storage (local storage) if needed.
	this.refdata = {};
	
	/**
	 * this method retrieves reference data array from cache object, given a domainCode.
	 */
	this.getRefdata = function(domainCode){
		return $this.refdata[domainCode];
	}
	
	/**
	 * this method adds reference data for a new domain code into cache
	 */
	this.addRefdataToCache = function(newRefData){
		$this.refdata = _.assign($this.refdata,newRefData);
	}
	/**
	 * this method finds a list of given domain codes in cache. it returns an array of domaincodes which
	 * are not found in cache. this method can be used to load only required domain codes from server on page load.
	 */
	this.findDomainCodesInCache = function(domainCodes){
		var domainCodesNotInCache = [];
		if(_.isArray(domainCodes)){
			for(var i in domainCodes){
				if($this.getRefdata(domainCodes[i]) === undefined){
					domainCodesNotInCache.push(domainCodes[i]);
				}
			}
		}
		return domainCodesNotInCache;
	}
	
	this.getRefdataPromise = function(domainCodesTobeLoaded){
		return $http({method: 'GET', url:  'findRefDataByDomainCodes/'+domainCodesTobeLoaded.join(',')});
	}
}]);