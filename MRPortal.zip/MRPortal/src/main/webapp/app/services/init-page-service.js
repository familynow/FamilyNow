'use strict';
/**
 * On page load service - this enables the developers to pre load any info if required before page gets loaded.
 * this invokes refdata service and error messages service to preload info and retain the results
 * in cache of both the service objects.
 */
app.factory('InitPageService', ['$http', '$q','RefdataService','ErrorMessageService' ,function($http, $q, refdataService,errorMessageService){
	return{
		initPage : function($scope,domainCodes,errMsgKeys){
			// flag that is checked on html layout to wait until page gets initialized with static data from service
			$scope.isPageInitialized = false;
			$scope.refDataService = refdataService;
			$scope.errorMessageService = errorMessageService;
			
			var promiseArr = {};
			// load only the ones which are required
			var domainCodesTobeLoaded = refdataService.findDomainCodesInCache(domainCodes);
			//load only the error messages which are required and not loaded into UI.
			var keysToBeLoaded = errorMessageService.findErrorMessageInCache(errMsgKeys);
			
			// trigger only if we need some codes to be retrieved from back end service.
			if(domainCodesTobeLoaded.length >0){
				promiseArr['refdata'] = refdataService.getRefdataPromise(domainCodesTobeLoaded);
			}
			
			// trigger only if we need some error message keys to be retrieved from back end service.
			if(errorMessageService.getErrorMessages() === undefined || errorMessageService.getErrorMessages().length == 0){
				promiseArr['errormsgs'] = errorMessageService.getErrorMessagePromise(keysToBeLoaded);
			}
			
			// Check if any ref data/ error messages to be retrieved from back end and initialize the Flag.
			if(!_.isEmpty(promiseArr)){
				$q.all(promiseArr).then(function(responses){
					var refDataResponse = responses.refdata;
					var errorMessageResponse = responses.errormsgs;
					if(refDataResponse != undefined){
						refdataService.addRefdataToCache(refDataResponse.data);
					}
					if(errorMessageResponse != undefined){
						errorMessageService.addErrorMessageToCache(errorMessageResponse.data);
					}
					$scope.isPageInitialized = true;
				});
			}else{
				$scope.isPageInitialized = true;
			}
		}
	};
}]);