package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.service.PriorityToolService;
import com.unisys.cwis.portal.mrp.views.QuestionaireForm;

@RestController
@RequestMapping("/priorityTool")
public class PriorityToolController {
	@Autowired
	private PriorityToolService priorityService;
	private Logger log = Logger.getLogger(PriorityToolController.class.getName());

	public PriorityToolController() {
		log.info("Constructor AllegationGroupController");
	}

	/**
	 * This service returns list of Priority Tools that can be run 
	 * 
	 * @return List<PriorityRecord>
	 */
	@RequestMapping(value = "/getPriorityTools", method = RequestMethod.GET)
	public ResponseEntity<List<PriorityTool>> getPriorityTools() {
		List<PriorityTool> priorityRecords = priorityService.getPriorityTools();
		return new ResponseEntity<List<PriorityTool>>(priorityRecords, HttpStatus.OK);
	}

	/**
	 * This service returns QuestionaireForm with the questions to be displayed
	 * based on priorityToolId
	 * 
	 * @param priorityToolId
	 * @return QuestionaireForm
	 */
	@RequestMapping(value = "/getQuestionaire/{priorityToolId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<QuestionaireForm> getQuestionaire(@PathVariable("priorityToolId") long priorityToolId) {
		log.info("PriorityController getQuestionaire");
		QuestionaireForm questionaireForm = priorityService.getQuestionaire(priorityToolId);
		return new ResponseEntity<QuestionaireForm>(questionaireForm, HttpStatus.OK);
	}
	
}
