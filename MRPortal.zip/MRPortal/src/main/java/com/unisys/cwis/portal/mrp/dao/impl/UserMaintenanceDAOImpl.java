package com.unisys.cwis.portal.mrp.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.sql2o.Connection;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.UserMaintenanceDAO;

@Repository("userMaintenanceDAO")
public class UserMaintenanceDAOImpl extends GenericDAOImpl<MRPUserAccount> implements UserMaintenanceDAO{

	@Override
	public List<PortalUserObject> getListUsers() {
		StringBuffer sqlCommand=new StringBuffer();
		sqlCommand.append("select user_account_id as userId, username as username, ")
		.append("(case when admin_flag=1 then 1 else 0 end) as adminFlag, last_name||', '||first_name as name ") 
		.append("from user_account where MARKED_FOR_DELETE_FLAG !=1 order by Lower(name), username ");	

		Connection aConnection = getReadOnlyController();

		List<PortalUserObject> results = aConnection.createQuery(sqlCommand.toString()).throwOnMappingFailure(false).executeAndFetch(PortalUserObject.class);
		aConnection.close();
		return results;
	}

	@Override
	public void deleteUser(long userId) {
		MRPUserAccount userAccount = findById(userId);
		userAccount.setMarkedForDeleteFlag(1);
		save(userAccount);
	}

}
