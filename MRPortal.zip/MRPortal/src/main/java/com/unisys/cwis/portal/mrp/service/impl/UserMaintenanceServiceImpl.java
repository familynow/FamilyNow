package com.unisys.cwis.portal.mrp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.UserMaintenanceDAO;
import com.unisys.cwis.portal.mrp.service.UserMaintenanceService;

@Service("userMaintenanceService")
@Transactional
public class UserMaintenanceServiceImpl implements UserMaintenanceService{

	@Autowired
	UserMaintenanceDAO userMaintenanceDAO;
	@Override
	public List<PortalUserObject> getListUsers() {
		// TODO Auto-generated method stub
		List<PortalUserObject> userList = userMaintenanceDAO.getListUsers();		
		return userList;
	}
	
	@Override
	public void deleteUser(long userId) {
		userMaintenanceDAO.deleteUser(userId );		
	}

	
}
