package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.service.UserMaintenanceService;

@RestController
@RequestMapping("/userMaintenance")
public class UserMaintenanceController {

	@Autowired
	UserMaintenanceService userMaintenanceService;
	
	/**
	 * This service returns list of active users
	 * 
	 * @return List<PortalUserObject>
	 */
	@RequestMapping(value = "/getListUser/", method = RequestMethod.GET)
	public ResponseEntity<List<PortalUserObject>> getListUser(){
		List<PortalUserObject> users =  userMaintenanceService.getListUsers();
		return new ResponseEntity<List<PortalUserObject>>(users, HttpStatus.OK);
	}
	
	/**
	 * This service is used to delete a user
	 * 
	 * @param userId
	 * @return Boolean
	 */
	@RequestMapping(value = "/deleteUser/{userId}", method = RequestMethod.DELETE)
	public ResponseEntity<Boolean> deleteUser(@PathVariable(value = "userId") long userId){		
		userMaintenanceService.deleteUser(userId);
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
	}
}
