package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;


/**
 * The persistent class for the ALLEGATION database table.
 * 
 */
@Entity
@Table(name="ALLEGATION")
@NamedQuery(name="Allegation.findAll", query="SELECT a FROM Allegation a")
public class Allegation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ALLEGATION_ID_SEQ_GENERATOR", sequenceName="ALLEGATION_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALLEGATION_ID_SEQ_GENERATOR")
	@Column(name="ALLEGATION_ID", unique=true, nullable=false)
	private long allegationId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ABUSE_OR_NEGLECT_DATE_TIME")
	private Date abuseOrNeglectDateTime;

	@Column(name="ACV_PARTICIPANT_ID")
	private long acvParticipantId;

	@Column(name="ALLEGATION_TYPE_CODE")
	private String allegationTypeCode;

	@Column(name="AP_PARTICIPANT_ID")
	private long apParticipantId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="TIME_ZONE_OF_ABUSE_OR_NEGLECT")
	private String timeZoneOfAbuseOrNeglect;

	//bi-directional many-to-one association to AllegationGroup
	@ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name = "ALLEGATION_GROUP_ID", referencedColumnName = "ALLEGATION_GROUP_ID", insertable = true, updatable = false)
	@JsonBackReference
	private AllegationGroup allegationGroup;

	public Allegation() {
	}

	public long getAllegationId() {
		return this.allegationId;
	}

	public void setAllegationId(long allegationId) {
		this.allegationId = allegationId;
	}

	public Date getAbuseOrNeglectDateTime() {
		return this.abuseOrNeglectDateTime;
	}

	public void setAbuseOrNeglectDateTime(Date abuseOrNeglectDateTime) {
		this.abuseOrNeglectDateTime = abuseOrNeglectDateTime;
	}
	
	public long getAcvParticipantId() {
		return acvParticipantId;
	}

	public void setAcvParticipantId(long acvParticipantId) {
		this.acvParticipantId = acvParticipantId;
	}

	public String getAllegationTypeCode() {
		return allegationTypeCode;
	}

	public void setAllegationTypeCode(String allegationTypeCode) {
		this.allegationTypeCode = allegationTypeCode;
	}

	public long getApParticipantId() {
		return apParticipantId;
	}

	public void setApParticipantId(long apParticipantId) {
		this.apParticipantId = apParticipantId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getTimeZoneOfAbuseOrNeglect() {
		return this.timeZoneOfAbuseOrNeglect;
	}

	public void setTimeZoneOfAbuseOrNeglect(String timeZoneOfAbuseOrNeglect) {
		this.timeZoneOfAbuseOrNeglect = timeZoneOfAbuseOrNeglect;
	}

	public AllegationGroup getAllegationGroup() {
		return this.allegationGroup;
	}

	public void setAllegationGroup(AllegationGroup allegationGroup) {
		this.allegationGroup = allegationGroup;
	}

}