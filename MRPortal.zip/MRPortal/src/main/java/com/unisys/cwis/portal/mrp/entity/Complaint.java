package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;


/**
 * The persistent class for the COMPLAINT database table.
 * 
 */
@Entity
@Table(name="COMPLAINT")
@NamedQuery(name="Complaint.findAll", query="SELECT c FROM Complaint c")
public class Complaint implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="COMPLAINT_ID_SEQ_GENERATOR", sequenceName="COMPLAINT_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COMPLAINT_ID_SEQ_GENERATOR")
	@Column(name="COMPLAINT_ID", unique=true, nullable=false)
	private long complaintId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	//bi-directional many-to-one association to AddtlComplaintNarrative
	/*@OneToMany(mappedBy="complaint", cascade=CascadeType.ALL)
	private Set<AddtlComplaintNarrative> addtlComplaintNarratives;

	//bi-directional many-to-one association to AllegationGroup
	@OneToMany(mappedBy="complaint", cascade=CascadeType.ALL)
	private Set<AllegationGroup> allegationGroups;

	//bi-directional many-to-one association to ComplaintParticipant
	@OneToMany(mappedBy="complaint", cascade=CascadeType.ALL)
	private Set<ComplaintParticipant> complaintParticipants;

	//bi-directional many-to-one association to DocumentOutput
	@OneToMany(mappedBy="complaint", cascade=CascadeType.ALL)
	private Set<DocumentOutput> documentOutputs;*/
	
	@ManyToOne
	@JsonBackReference
	@JoinColumn(name="USER_ACCOUNT_ID",updatable=false,insertable=false)
	private MRPUserAccount userAccount;
	
	
	@Column(name="USER_ACCOUNT_ID", nullable=false, insertable=true, updatable=true)
	private long userAccountId;
	
	@Column(name="COMPLAINT_STATUS")
	private String complaintStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="RECEIVED_DATE")
	private Date receivedDate;
	
	@Column(name="SCREENING_DECISION")
	private String screeningDecision;
	
	@Temporal(TemporalType.DATE)
	@Column(name="SUBMITTED_DATE")
	private Date submittedDate;
	
	@Column(name="PROFILE_DATA_AVLBL_FLAG")
	private BigDecimal profileDataAvailableFlag;
	
	@Column(name="PARTICIPANT_DATA_AVLBL_FLAG")
	private BigDecimal participantDataAvailableFlag;
	
	@Column(name="ALLEGATION_DATA_AVLBL_FLAG")
	private BigDecimal allegationDataAvailableFlag;
	
	@Column(name="DOCUMENT_UPLOADED_FLAG")
	private BigDecimal documentUploadedFlag;
	
	@Column(name="NARRATIVE_DATA_AVLBL_FLAG")
	private BigDecimal narrativeDataAvailableFlag;
	 
	@Column(name="COMPLAINT_NAME")
	private String complaintName;
	
	@Column(name="feedback_type_code")
	private String feedbackTypeCode;
	
	@Column(name="SUPPORTING_DOC_CODE")
	private String supportingDocCode;
	
	@Column(name="IS_SYNCHED_WITH_INATAKE")
	private long isSynchedWithIntake;
	
	@Transient
	private long intakeId;
	
	public Complaint() {
	}

	public long getComplaintId() {
		return this.complaintId;
	}

	public void setComplaintId(long complaintId) {
		this.complaintId = complaintId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/*public Set<AddtlComplaintNarrative> getAddtlComplaintNarratives() {
		return this.addtlComplaintNarratives;
	}

	public void setAddtlComplaintNarratives(Set<AddtlComplaintNarrative> addtlComplaintNarratives) {
		this.addtlComplaintNarratives = addtlComplaintNarratives;
	}*/

	/*public AddtlComplaintNarrative addAddtlComplaintNarrative(AddtlComplaintNarrative addtlComplaintNarrative) {
		getAddtlComplaintNarratives().add(addtlComplaintNarrative);
		addtlComplaintNarrative.setComplaint(this);

		return addtlComplaintNarrative;
	}

	public AddtlComplaintNarrative removeAddtlComplaintNarrative(AddtlComplaintNarrative addtlComplaintNarrative) {
		getAddtlComplaintNarratives().remove(addtlComplaintNarrative);
		addtlComplaintNarrative.setComplaint(null);

		return addtlComplaintNarrative;
	}

	public Set<AllegationGroup> getAllegationGroups() {
		return this.allegationGroups;
	}

	public void setAllegationGroups(Set<AllegationGroup> allegationGroups) {
		this.allegationGroups = allegationGroups;
	}*/

	/*public AllegationGroup addAllegationGroup(AllegationGroup allegationGroup) {
		getAllegationGroups().add(allegationGroup);
		allegationGroup.setComplaint(this);

		return allegationGroup;
	}

	public AllegationGroup removeAllegationGroup(AllegationGroup allegationGroup) {
		getAllegationGroups().remove(allegationGroup);
		allegationGroup.setComplaint(null);

		return allegationGroup;
	}

	public Set<ComplaintParticipant> getComplaintParticipants() {
		return this.complaintParticipants;
	}

	public void setComplaintParticipants(Set<ComplaintParticipant> complaintParticipants) {
		this.complaintParticipants = complaintParticipants;
	}*/

	/*public ComplaintParticipant addComplaintParticipant(ComplaintParticipant complaintParticipant) {
		getComplaintParticipants().add(complaintParticipant);
		complaintParticipant.setComplaint(this);

		return complaintParticipant;
	}

	public ComplaintParticipant removeComplaintParticipant(ComplaintParticipant complaintParticipant) {
		getComplaintParticipants().remove(complaintParticipant);
		complaintParticipant.setComplaint(null);

		return complaintParticipant;
	}

	public Set<DocumentOutput> getDocumentOutputs() {
		return this.documentOutputs;
	}

	public void setDocumentOutputs(Set<DocumentOutput> documentOutputs) {
		this.documentOutputs = documentOutputs;
	}*/

	/*public DocumentOutput addDocumentOutput(DocumentOutput documentOutput) {
		getDocumentOutputs().add(documentOutput);
		documentOutput.setComplaint(this);

		return documentOutput;
	}

	public DocumentOutput removeDocumentOutput(DocumentOutput documentOutput) {
		getDocumentOutputs().remove(documentOutput);
		documentOutput.setComplaint(null);

		return documentOutput;
	}*/

	public MRPUserAccount getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(MRPUserAccount userAccount) {
		this.userAccount = userAccount;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public long getUserAccountId() {
		return userAccountId;
	}

	public void setUserAccountId(long userAccountId) {
		this.userAccountId = userAccountId;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getScreeningDecision() {
		return screeningDecision;
	}

	public void setScreeningDecision(String screeningDecision) {
		this.screeningDecision = screeningDecision;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public BigDecimal getProfileDataAvailableFlag() {
		return profileDataAvailableFlag;
	}

	public void setProfileDataAvailableFlag(BigDecimal profileDataAvailableFlag) {
		this.profileDataAvailableFlag = profileDataAvailableFlag;
	}

	public BigDecimal getParticipantDataAvailableFlag() {
		return participantDataAvailableFlag;
	}

	public void setParticipantDataAvailableFlag(BigDecimal participantDataAvailableFlag) {
		this.participantDataAvailableFlag = participantDataAvailableFlag;
	}

	public BigDecimal getAllegationDataAvailableFlag() {
		return allegationDataAvailableFlag;
	}

	public void setAllegationDataAvailableFlag(BigDecimal allegationDataAvailableFlag) {
		this.allegationDataAvailableFlag = allegationDataAvailableFlag;
	}

	public BigDecimal getDocumentUploadedFlag() {
		return documentUploadedFlag;
	}

	public void setDocumentUploadedFlag(BigDecimal documentUploadedFlag) {
		this.documentUploadedFlag = documentUploadedFlag;
	}

	public BigDecimal getNarrativeDataAvailableFlag() {
		return narrativeDataAvailableFlag;
	}

	public void setNarrativeDataAvailableFlag(BigDecimal narrativeDataAvailableFlag) {
		this.narrativeDataAvailableFlag = narrativeDataAvailableFlag;
	}

	public String getComplaintName() {
		return complaintName;
	}

	public void setComplaintName(String complaintName) {
		this.complaintName = complaintName;
	}

	public String getSupportingDocCode() {
		return supportingDocCode;
	}

	public void setSupportingDocCode(String supportingDocCode) {
		this.supportingDocCode = supportingDocCode;
	}

	public String getFeedbackTypeCode() {
		return feedbackTypeCode;
	}

	public void setFeedbackTypeCode(String feedbackTypeCode) {
		this.feedbackTypeCode = feedbackTypeCode;
	}

	public long isSynchedWithIntake() {
		return isSynchedWithIntake;
	}

	public void setSynchedWithIntake(long isSynchedWithIntake) {
		this.isSynchedWithIntake = isSynchedWithIntake;
	}

	public long getIntakeId() {
		return intakeId;
	}

	public void setIntakeId(long intakeId) {
		this.intakeId = intakeId;
	}
	
}