package com.unisys.cwis.portal.mrp.dao;

import java.util.List;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.views.PortalUserObject;

public interface UserMaintenanceDAO extends GenericDAO<MRPUserAccount>{

	List<PortalUserObject> getListUsers();

	void deleteUser(long userId);
}
