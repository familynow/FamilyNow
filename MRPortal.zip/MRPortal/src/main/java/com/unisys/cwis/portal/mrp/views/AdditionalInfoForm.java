package com.unisys.cwis.portal.mrp.views;

import java.util.ArrayList;
import java.util.List;

import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;

public class AdditionalInfoForm {
	private String feedbackTypeCode;
	
	private List<AddtlComplaintNarrative> additionalInfoList = new ArrayList<>();
	public String getFeedbackTypeCode() {
		return feedbackTypeCode;
	}
	public void setFeedbackTypeCode(String feedbackType) {
		this.feedbackTypeCode = feedbackType;
	}
	public List<AddtlComplaintNarrative> getAdditionalInfoList() {
		return additionalInfoList;
	}
	public void setAdditionalInfoList(List<AddtlComplaintNarrative> additionalInfoList) {
		this.additionalInfoList = additionalInfoList;
	}
}
