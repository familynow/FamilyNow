package com.unisys.cwis.portal.mrp.dao.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.sql2o.Connection;

import com.jcabi.aspects.Loggable;
import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.common.entity.RefData;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.AdditionalInfoDao;
import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;

/**
 * DAO implementation to save answers for getting additional info.
 * 
 * @author Anuroop.
 *
 */
@Repository("additionalInfoDao")
public class AdditionalInfoDaoImpl extends GenericDAOImpl<AddtlComplaintNarrative> implements AdditionalInfoDao {

	@Override
	public List<AddtlComplaintNarrative> getAdditionalInfo(long complaintId) {
		@SuppressWarnings("unchecked")
		
	/**
	 * Below code is to get narratives using single query
	 */
		StringBuffer query = new StringBuffer("");
		query.append("select rf.ref_data_code as refDataCode, rf.long_desc as longDescription, acn.NARRATIVE_ID as narrativeId, "
				+ "acn.NARRATIVE_TEXT as narrativeText, CASE WHEN acn.NARRATIVE_TOPIC_CODE IS NOT NULL THEN acn.NARRATIVE_TOPIC_CODE ELSE rf.ref_data_code END  as narrativeTopicCode, acn.COMPLAINT_ID as complaintId "
				+ "from (SELECT domain_code, sort_value, ref_data_code, long_desc FROM ref_data) rf left join "
				+ "(SELECT NARRATIVE_ID, NARRATIVE_TEXT, NARRATIVE_TOPIC_CODE, COMPLAINT_ID "
				+ "FROM ADDTL_COMPLAINT_NARRATIVES WHERE COMPLAINT_ID = "+complaintId+") acn "
				+ "on acn.NARRATIVE_TOPIC_CODE = rf.ref_data_code where rf.domain_code = 'ComplaintNarrativeRefCode' order by rf.sort_value");
		
		
		Connection aConnection = getReadOnlyController();

		List<AddtlComplaintNarrative>  narrtives = aConnection.createQuery(query.toString()).throwOnMappingFailure(false)
				.executeAndFetch(AddtlComplaintNarrative.class);
		aConnection.close();

		return narrtives;
		/*List<AddtlComplaintNarrative> additionalInfos = this.getSession().createCriteria(AddtlComplaintNarrative.class).
				add(Restrictions.eq("complaintId", complaintId)).add(Restrictions.eq("markedForDeleteFlag", new BigDecimal(0))).list();
		
		
		
		Set<String> allQuestions = getAllQuestions();
		Set<String> answeredQuestions = extractAnsweredQuestions(additionalInfos);
		Set<String> unansweredQuestions = getUnansweredQuestions(allQuestions, answeredQuestions);
		List<AddtlComplaintNarrative> additionalInfosWithUnansweredQuestions = addEmptyQuestions(unansweredQuestions, additionalInfos); 
		
		return additionalInfosWithUnansweredQuestions;*/
	}
	
	@Override
	public void saveAnswers(List<AddtlComplaintNarrative> additionalInfoList) {
		for(AddtlComplaintNarrative additionalInfo : additionalInfoList) {
			if(additionalInfo.getNarrativeText() != null) {
				if(audit(additionalInfo)) {
					save(additionalInfo);//	
				} else {
					AddtlComplaintNarrative acn = getSession().get(AddtlComplaintNarrative.class, additionalInfo.getNarrativeId());
					acn.setNarrativeText(additionalInfo.getNarrativeText());//
				}
			}
		}
	}


	/**
	 * Method to audit change.
	 * 
	 * @param additionalInfo The new information that needs to be audited.
	 * @return True if the row is created for the first time. False otherwise.
	 * False means the item is being modified.
	 */
	private boolean audit(AddtlComplaintNarrative additionalInfo) {
		if(additionalInfo.getNarrativeId() == 0) {
			additionalInfo.setCreatedBy(getCurrentUser());
			additionalInfo.setCreatedDate(new Date());
			additionalInfo.setMarkedForDeleteFlag(new BigDecimal(0));
			additionalInfo.setModifiedBy(getCurrentUser());
			additionalInfo.setModifiedDate(new Date());
			
			return true;
		} else {
			additionalInfo.setModifiedBy(getCurrentUser());
			additionalInfo.setModifiedDate(new Date());
			
			return false;
		}
	}

	/**
	 * Add unanswered questions to the list of answered questions.
	 * 
	 * @param unansweredQuestionSet Questions that need to be answered.
	 * @param additionalInfoList Answered questions
	 * @return Complete list of additional info containing answered
	 * and unanswered questions both.
	 */
	private List<AddtlComplaintNarrative> addEmptyQuestions(Set<String> unansweredQuestionSet,
			List<AddtlComplaintNarrative> additionalInfoList) {
		for(String unansweredQuestion : unansweredQuestionSet) {
			AddtlComplaintNarrative narrative = new AddtlComplaintNarrative();
			narrative.setNarrativeTopicCode(unansweredQuestion);
			
			additionalInfoList.add(narrative);
		}
		
		return additionalInfoList;
	}


	/**
	 * Compare the two sets and find out questions which are not answered.
	 * 
	 * @param allQuestions Set of all questions.
	 * @param answeredQuestions Set of all answered questions.
	 * @return Set of unanswered questions.
	 */
	private Set<String> getUnansweredQuestions(Set<String> allQuestions, Set<String> answeredQuestions) {
		Set<String> unansweredQuestions = new HashSet<>(allQuestions);
		
		for(String anweredQuestion : answeredQuestions) {
			if(!unansweredQuestions.add(anweredQuestion)) {
				unansweredQuestions.remove(anweredQuestion);
			}
		}
		
		return unansweredQuestions;
	}


	/**
	 * Get the list of questions that have answers.
	 * 
	 * @param additionalInfos Additional info
	 * @return Set of questions that are answered.
	 */
	private Set<String> extractAnsweredQuestions(List<AddtlComplaintNarrative> additionalInfos) {
		Set<String> answeredQuestions = new HashSet<>();
		
		for(AddtlComplaintNarrative additionalInfo : additionalInfos) {
			if(isAnswered(additionalInfo)) {
				answeredQuestions.add(additionalInfo.getNarrativeTopicCode());
			}
		}
		
		return answeredQuestions;
	}

	private boolean isAnswered(AddtlComplaintNarrative additionalInfo) {
		//TODO:Anuroop: Check for boundary conditions like only white spaces.
		
		/* Duplicate question bug solution:
		 * 
		 * The correct test to find out if a question is answered or not is to find
		 * if row is created i.e. primary key is generated for that answer or not.
		 * Checking for null is a false test which was the reason of previous bug. 
		 */
		if(additionalInfo.getNarrativeId() == 0) {
			return false;
		}
		
		return true;
	}

	/**
	 * Get all the additional info questions from ref_data. 
	 * 
	 * @return Set of additional info questions.
	 */
	private Set<String> getAllQuestions() {
		@SuppressWarnings("unchecked")
		List<RefData> refDatas = this.getSession().createCriteria(RefData.class).
				add(Restrictions.eq("domainCode", "ComplaintNarrativeRefCode")).add(Restrictions.eq("markedForDeleteFlag", new BigDecimal(0))).list();
		
		Set<String> allQuestions = new HashSet<>();
		for(RefData refData : refDatas) {
			allQuestions.add(refData.getRefDataCode());
		}
		
		return allQuestions;
	}


	/**
	 * Helper to get current user.
	 * 
	 * @return Object representing current user.
	 */
	@Loggable
    private String getCurrentUser() {
    	ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		return userObject.getUserId();
		//TODO:Anuroop: Correct this.
		//return "Gremlin";
    }
}