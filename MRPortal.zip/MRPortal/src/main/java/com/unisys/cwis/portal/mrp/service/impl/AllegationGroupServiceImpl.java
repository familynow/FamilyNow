package com.unisys.cwis.portal.mrp.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.AllegationGroupDao;
import com.unisys.cwis.portal.mrp.dao.ComplaintDao;
import com.unisys.cwis.portal.mrp.entity.Allegation;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.AllegationGroupService;
import com.unisys.cwis.portal.mrp.views.AllegationGroupForm;
import com.unisys.cwis.portal.mrp.views.AllegationGroupRecord;
import com.unisys.cwis.portal.mrp.views.ComplaintPartResultRecord;


@Service("AllegationGroupService")
@Transactional
public class AllegationGroupServiceImpl implements AllegationGroupService {

	@Autowired
	private AllegationGroupDao allegationGroupDao;
	
	@Autowired
	private ComplaintDao complaintDao;

	public AllegationGroupForm getAllegationParticipants(long complaintId, long allegationGroupId) {
		AllegationGroupForm allegationGroupForm = new AllegationGroupForm();		
		allegationGroupForm.setAllegationNotes(allegationGroupDao.getAllegationNotes(complaintId));		
		if (allegationGroupId > 0) {
			AllegationGroup allegationGroup = allegationGroupDao.findById(allegationGroupId);
			List<Allegation> allegations = new ArrayList<Allegation>(allegationGroup.getAllegations());
			allegationGroupForm.setAllegationType(allegations.get(0).getAllegationTypeCode());
			allegationGroupForm.setAbuseOrNeglectDateTime(allegations.get(0).getAbuseOrNeglectDateTime());
			allegationGroupForm.setTimeZoneOfAbuseOrNeglect(allegations.get(0).getTimeZoneOfAbuseOrNeglect());
		}

		List<ComplaintPartResultRecord> allegedVictims = new ArrayList<ComplaintPartResultRecord>();
		List<ComplaintPartResultRecord> allegedPerpetrators = new ArrayList<ComplaintPartResultRecord>();
		
		allegedVictims = allegationGroupDao.getAllegationParticipants(complaintId, "ACV", allegationGroupId);
		allegedPerpetrators = allegationGroupDao.getAllegationParticipants(complaintId, "AP", allegationGroupId);
		allegationGroupForm.setAllegedVictims(allegedVictims);
		allegationGroupForm.setAllegedPerpetrators(allegedPerpetrators);
		allegationGroupForm.setAllegationGroupId(allegationGroupId);
		allegationGroupForm.setComplaintId(complaintId);
		return allegationGroupForm;
	}

	public List<AllegationGroupRecord> retrieveAll(long complaintId) {
		List<AllegationGroupRecord> records = allegationGroupDao.retrieveAll(complaintId);
		
		return records;
	}

	public AllegationGroup delete(long allegationGroupId) {
		AllegationGroup allegationGroup = allegationGroupDao.findById(allegationGroupId);
		allegationGroup.setMarkedForDeleteFlag(true);
		allegationGroupDao.save(allegationGroup);
		List<AllegationGroupRecord> records = allegationGroupDao.retrieveAll(allegationGroup.getComplaint().getComplaintId());
		if(records == null || records.size()<1){
			Complaint complaint = complaintDao.findById(allegationGroup.getComplaint().getComplaintId());
			complaint.setAllegationDataAvailableFlag(new BigDecimal(0));
			complaintDao.save(complaint);
		}
		return allegationGroup;
	}

	public void save(AllegationGroupForm allegationGroupForm, PortalUserObject userObject) {
		AllegationGroup allegationGroup = new AllegationGroup();		
		allegationGroup.setComplaint(complaintDao.findById(allegationGroupForm.getComplaintId()));		
		allegationGroup.setAllegationNotes(allegationGroupForm.getAllegationNotes());
		allegationGroup.setCreatedBy(userObject.getUserId());
		allegationGroup.setCreatedDate(new Date());
		if (allegationGroupForm.getAllegationGroupId() > 0) {
			allegationGroup = allegationGroupDao.findById(allegationGroupForm.getAllegationGroupId());
		}
		allegationGroup.setModifiedBy(userObject.getUserId());
		allegationGroup.setModifiedDate(new Date());
		allegationGroup.setMarkedForDeleteFlag(false);
		// delete Allegations related to current allegationGroupId.
		String deleteAllegationsSql = "DELETE FROM ALLEGATION a WHERE a.ALLEGATION_GROUP_ID = "
				+ allegationGroupForm.getAllegationGroupId();
		allegationGroupDao.deleteBySQL(deleteAllegationsSql);
		allegationGroup.getAllegations().clear();

		Set<Allegation> allegations = new HashSet<Allegation>();
		for (ComplaintPartResultRecord allegedVictim : allegationGroupForm.getAllegedVictims()) {
			if (allegedVictim.getSelected()) {
				for (ComplaintPartResultRecord allegedPerpetrator : allegationGroupForm.getAllegedPerpetrators()) {
					if (allegedPerpetrator.getSelected()) {
						Allegation allegation = new Allegation();
						allegation.setAbuseOrNeglectDateTime(allegationGroupForm.getAbuseOrNeglectDateTime());
						allegation.setTimeZoneOfAbuseOrNeglect(allegationGroupForm.getTimeZoneOfAbuseOrNeglect());
						allegation.setCreatedBy(userObject.getUserId());
						allegation.setCreatedDate(new Date());
						allegation.setModifiedBy(userObject.getUserId());
						allegation.setModifiedDate(new Date());		
						allegation.setAcvParticipantId(allegedVictim.getParticipantId());
						allegation.setApParticipantId(allegedPerpetrator.getParticipantId());
						allegation.setAllegationTypeCode(allegationGroupForm.getAllegationType());
						allegation.setMarkedForDeleteFlag(new BigDecimal(0));
						allegation.setAllegationGroup(allegationGroup);
						allegations.add(allegation);
					}
				}
			}
		}
		allegationGroup.setAllegations(allegations);
		allegationGroupDao.save(allegationGroup);
		Complaint complaint = complaintDao.findById(allegationGroup.getComplaint().getComplaintId());
		complaint.setAllegationDataAvailableFlag(new BigDecimal(1));
		complaintDao.save(complaint);
	}

	public Boolean checkForDuplicateAllegation(long complaintId, long allegationGroupId, String allegationType,
			long allegedVictimId, long allegedPerpetratorId) {
		return allegationGroupDao.checkForDuplicateAllegation(complaintId, allegationGroupId, allegationType,
				allegedVictimId, allegedPerpetratorId);
	}

	@Override
	public void saveNarrative(AllegationGroupForm allegationGroupForm) {
		//Complaint complaint = complaintDao.findById(allegationGroupForm.getComplaintId());
		allegationGroupDao.saveNarrative(allegationGroupForm);
		
		/*if(complaint.getAllegationGroups()!=null && complaint.getAllegationGroups().size()>0){
			for(AllegationGroup allegationGroup :complaint.getAllegationGroups()){
				allegationGroup.setAllegationNotes(allegationGroupForm.getAllegationNotes());
				allegationGroupDao.save(allegationGroup);
			}
		}*/
	}

	@Override
	public List<AllegationGroup> getAllegationDetails(long complaintId) {
		// TODO Auto-generated method stub
		return allegationGroupDao.getAllegationDetails(complaintId);
	}

}
