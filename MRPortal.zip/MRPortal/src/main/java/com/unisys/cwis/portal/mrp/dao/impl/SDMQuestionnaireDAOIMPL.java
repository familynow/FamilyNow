package com.unisys.cwis.portal.mrp.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.dao.SDMQuestionnaireDAO;
import com.unisys.cwis.portal.mrp.entity.PriorityList;

@Repository("questionnaireDao")
public class SDMQuestionnaireDAOIMPL extends GenericDAOImpl<PriorityList> implements SDMQuestionnaireDAO{
	
	private Logger log = Logger.getLogger(SDMQuestionnaireDAOIMPL.class.getName());	
	public void createQuestion(PriorityList qustionDetails){
		getSession().save(qustionDetails);
	}
	@Override
	public PriorityList getQuestionDetails(long questionId) {
		// TODO Auto-generated method stub
		PriorityList priorityList = this.findById(questionId);
		return priorityList;
	}
}
