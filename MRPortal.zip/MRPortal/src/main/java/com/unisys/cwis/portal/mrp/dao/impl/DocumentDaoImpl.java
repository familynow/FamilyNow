package com.unisys.cwis.portal.mrp.dao.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import org.bson.types.ObjectId;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.DB;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.unisys.cwis.portal.common.core.MongoDBClient;
import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.common.util.PortalUtils;
import com.unisys.cwis.portal.mrp.dao.DocumentDao;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.entity.DocumentOutput;

@Repository("documentDao")
public class DocumentDaoImpl extends GenericDAOImpl<DocumentOutput> implements DocumentDao {

	public static final String MONGODB_COLLECTION_NAME = "DocumentImages";
	@Override
	public String saveDocumentsInMongo(MultipartFile docFile) {


		ObjectId ObjId = null;
		DB mongoDB = PortalUtils.getReadOnlyMongoDBController();
		GridFS gfsObj = new GridFS(mongoDB, MONGODB_COLLECTION_NAME);
		// File docFile = new File("D:\\MongoDB\\image\\test.docx");
		MongoDBClient mongoClient = new MongoDBClient();
		try {
			ObjId = mongoClient.saveDocument(gfsObj, docFile);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return ObjId.toString();
	
	}
	

	@Override
	public List<DocumentOutput> getDocumentList(long complaintId) {
		Session session = this.getSession();
		Query query = session.createQuery("select d from DocumentOutput d where d.complaintId=:complaintId and d.markedForDeleteFlag=:flag");
		query.setParameter("complaintId", complaintId);
		query.setBigDecimal("flag", new BigDecimal(0));
		List<DocumentOutput> list = query.list();
		
		return list;
	}
	
	/**
	 * This method is used to find document by ID from DB
	 * 
	 * @param id
	 * @return input
	 */
	@Override
	public GridFSDBFile getDocumentById(String id) {
		ObjectId objId = new ObjectId(id);
		GridFSDBFile input = null;
		DB mongoDB = PortalUtils.getReadOnlyMongoDBController();
		GridFS gfsObj = new GridFS(mongoDB, MONGODB_COLLECTION_NAME);
		MongoDBClient mongoClient = new MongoDBClient();
		try {
			input = mongoClient.getDocumentById(gfsObj, objId);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return input;
	}


	@Override
	public boolean updateDocumentUploadStatus(long complaintId, String code) {
		Session session = this.getSession();
		Complaint complaint  = session.get(Complaint.class, complaintId);
		complaint.setDocumentUploadedFlag(new BigDecimal(1));
		complaint.setSupportingDocCode(code);
		session.update(complaint);
		return true;
	}
	

}
