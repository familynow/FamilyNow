package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mongodb.gridfs.GridFSDBFile;
import com.unisys.cwis.portal.mrp.entity.DocumentOutput;

public interface DocumentService {

	/**
	 * This method takes the file and upload it to mongo DB.
	 * @param file
	 * @return
	 */
	String uploadDocumentToMongoDB(MultipartFile file);

	/**
	 * This method returns the list of document for complaint id.
	 * @param documentId
	 * @return
	 */
	List<DocumentOutput> getDocumentList(long documentId);
	
	/**
	 * Upload Document and Save Document Data.
	 */
	
	DocumentOutput saveDocumentDetailAndUploadFile(DocumentOutput documentOutput, MultipartFile file);
	
	/**
	 * Update document details.
	 * @param documentOutput
	 * @return
	 */
	DocumentOutput updateDocumentDetail(DocumentOutput documentOutput);

	/**
	 * This method will update marked as delete flag to 1
	 * @param documentId
	 */
	boolean deleteDocumentDetail(long documentId);

	/**
	 * This method return document based on guid
	 * @param id
	 * @return
	 */
	GridFSDBFile getDocumentInputFileById(String id);

	/**
	 * This method return mime type.
	 * @param fileName
	 * @return
	 */
	String getMimeTypeFromFileName(String fileName);

	/**
	 * This method update complaint with document status
	 * @param str
	 * @return
	 */
	boolean updateDocumentUploadStatus(long complaintId, String str);
	
	
}
