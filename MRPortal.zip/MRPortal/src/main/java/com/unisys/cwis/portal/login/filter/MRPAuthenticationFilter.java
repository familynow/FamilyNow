package com.unisys.cwis.portal.login.filter;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.ServletRequestAttributes;

import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.common.views.LoginForm;
import com.unisys.cwis.portal.common.views.PortalUserObject;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;

/**
 * Servlet Filter implementation class MRPAuthenticationFilter
 */
@WebFilter("/MRPAuthenticationFilter")
public class MRPAuthenticationFilter implements Filter {

    /**
     * Default constructor. 
     */
    public MRPAuthenticationFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		/**
		 *  Check logged in user id from session against user id received from UI - if matches - GO, if does not match - user is unauthorized, throw error
		 *  Arka/Miju/Atif  
		 *  Assumption : Post successful log in, PortalUserObject shall be created and set n session variable "USER_OBJECT" - Shankar 
		 */
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse httpResponse = (HttpServletResponse) res;
		String path = request.getRequestURI();
		LoginForm loginForm = (LoginForm) request.getSession().getAttribute("loginForm");
		boolean isLoggedIn=false;
		boolean isAdmin=false;
		final String authHeader = request.getHeader("Authorization");
		if(null != loginForm){
			if(null == loginForm.getUserName() || "".equals(loginForm.getUserName().trim())){
				isLoggedIn=false;
			}else{
				isLoggedIn=true;
				if(loginForm.isAdmin()){
					isAdmin=true;
				}
			}
		}
		//System.out.println("isLoggedIn "+isLoggedIn);
		boolean unprotedted=isUnprotectedResource(path);
		if(unprotedted){
			//System.out.println("path is "+path + " unprotected");
			chain.doFilter(req, res);
		}else{
			if(isLoggedIn){
				try{
					boolean unauthorizedUser=false;
					if (authHeader == null || !authHeader.startsWith("Bearer ")) {
						unauthorizedUser=true;
						httpResponse.setStatus(401);
			        }else{
			        	final String token = authHeader.substring(7);
				        try {
				            final Claims claims = Jwts.parser().setSigningKey("secretkey")
				                .parseClaimsJws(token).getBody();
				            request.setAttribute("claims", claims);
				        }
				        catch (final SignatureException e) {
				        	System.out.println("SignatureException - unauthorized : isLoggedIn "+isLoggedIn);
				        	unauthorizedUser=true;
				        	httpResponse.setStatus(401);
				        }
				        //admin check - 
				        for(int i=0;i<MRPConstant.ADMIN_ONLY_PATHS.length;i++){
							if(path.contains(MRPConstant.ADMIN_ONLY_PATHS[i]) && !isAdmin){
								unauthorizedUser=true;
								httpResponse.setStatus(401);
								break;
							}
						}
				        if(!unauthorizedUser)
				        	chain.doFilter(req, res);
			        }
				}catch(Exception e ){
					System.out.println("Exception - unauthorized : isLoggedIn "+isLoggedIn);
					e.printStackTrace();
					httpResponse.setStatus(401);
				}
			}else{
				System.out.println("Protected resource - login to access "+path);
				httpResponse.sendRedirect(MRPConstant.UNAUTHORIZED_ERROR_PAGE);
			}
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	
	private static boolean isUnprotectedResource (String path){
		//boolean unprotected = false;
		if(path != null && !"".equals(path)){
			//System.out.println("path is "+path);System.out.println("path is "+path);
			
			for(int i=0;i<MRPConstant.UNRESTRICTED_PARTIAL_PATHS.length;i++){
//				if(path.contains("partials")){
//					System.out.println("path is "+path +" comparing with - "+MRPConstant.UNRESTRICTED_PARTIAL_PATHS[i]+" "
//							+ " and returning "+path.contains(MRPConstant.UNRESTRICTED_PARTIAL_PATHS[i]));
//				}
				if(path.contains(MRPConstant.UNRESTRICTED_PARTIAL_PATHS[i])){
					return true;
				}
			}
			//System.out.println("path is "+path+" unprotected partial path ? "+unprotected);
			for(int i=0;i<MRPConstant.UNRESTRICTED_APP_URLS.length;i++){
				if(path.equalsIgnoreCase(MRPConstant.UNRESTRICTED_APP_URLS[i])){
					return true;
				}
			}
			//System.out.println("path is "+path+" unprotected app url ? "+unprotected);
			if(path.equalsIgnoreCase(MRPConstant.UNRESTRICTED_REF_DATA_URL)){
				return true;
			}
		}
		//System.out.println("path is "+path+" and returning - unprotected "+unprotected);
		return false;
	}
	
	public static void main(String args[]){
		String path="/MRPortal/lib/jquery/bootstrap.js";
		System.out.println(isUnprotectedResource(path));
	}

}
