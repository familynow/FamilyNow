package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import com.unisys.cwis.portal.common.views.PortalUserObject;


public interface UserMaintenanceService {
	List<PortalUserObject> getListUsers();
	void deleteUser(long userId);
}
