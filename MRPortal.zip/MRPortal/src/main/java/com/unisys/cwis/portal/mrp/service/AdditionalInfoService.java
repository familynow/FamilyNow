package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;
import com.unisys.cwis.portal.mrp.views.AdditionalInfoForm;

/**
 * Service to save answers for gathering additional information.
 */
public interface AdditionalInfoService {
	
	/**
	 * Save the response received from logged in user.
	 * 
	 * @param additionalInfoFromUser The answers, their corresponding questions and feedback type.
	 */
	public void saveAnswers(AdditionalInfoForm additionalInfoFromUser);

	public List<AddtlComplaintNarrative> getAdditionalInfo(long complaintId);

	/**
	 * Get feedback type of a given complaint.
	 * 
	 * @param complaintId Complaint ID of which feedback type needs to be determined.
	 * @return Feedback type.
	 */
	public String getFeedbackType(long complaintId);
}