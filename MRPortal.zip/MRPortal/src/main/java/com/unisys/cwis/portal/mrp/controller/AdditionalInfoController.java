/**
 * 
 */
package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.jcabi.aspects.Loggable;
import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;
import com.unisys.cwis.portal.mrp.service.AdditionalInfoService;
import com.unisys.cwis.portal.mrp.views.AdditionalInfoForm;

/**
 * Resource controller to expose web services to save answers for the questions
 * asked to gather additional information.
 *
 * @author Anuroop
 *
 */
@RestController
@Transactional
@RequestMapping("/additionalInfo")
@SessionAttributes("additionalInfoForm")
public class AdditionalInfoController {
	
	private Logger logger = Logger.getLogger(AdditionalInfoController.class.getName());
	
	@Autowired
	private AdditionalInfoService additionalInfoService;
	
    public AdditionalInfoController() {
    	logger.debug("AdditionalInfoController object created.");
    }
    
    /**
     * Get additional information for an existing complaint. This will return all
     * the questions even which were not answered by the user.
     * 
     * @param complaintId The complaint ID for which additional information
     * needs to be retrieved.
     * 
     * @return Additional info JSON.
     */
    @Loggable
    @RequestMapping(value = "/questionAnswers/{complaintId}", method = RequestMethod.GET)
    public ResponseEntity<AdditionalInfoForm> getQA(@PathVariable("complaintId")long complaintId) {
    	
    	List<AddtlComplaintNarrative> additionalInfos = additionalInfoService.getAdditionalInfo(complaintId);
    	String feedbackType = additionalInfoService.getFeedbackType(complaintId);
    	
    	AdditionalInfoForm form = new AdditionalInfoForm();
    	form.setAdditionalInfoList(additionalInfos);
		form.setFeedbackTypeCode(feedbackType);
    	
		return new ResponseEntity<AdditionalInfoForm>(form, HttpStatus.OK);
    }
    
    @Loggable
    @RequestMapping(value = "/answers/", method = RequestMethod.POST)
    public ResponseEntity<AdditionalInfoForm> saveAnswers(@RequestBody AdditionalInfoForm additionalInfos) {
		additionalInfoService.saveAnswers(additionalInfos);
		return new ResponseEntity<AdditionalInfoForm>(additionalInfos, HttpStatus.OK);
    }
}