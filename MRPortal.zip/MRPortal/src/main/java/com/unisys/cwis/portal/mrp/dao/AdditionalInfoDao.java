package com.unisys.cwis.portal.mrp.dao;

import java.util.List;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;

/**
 * DAO layer to manage additional info.
 * 
 * @author Anuroop
 *
 */
public interface AdditionalInfoDao extends GenericDAO<AddtlComplaintNarrative> {

	/**
	 * Get additional information associated with an existing complaint.
	 * 
	 * @param complaintId Complaint ID for which additional information needs to
	 * be retrieved.
	 * 
	 * @return Additional information (list of question-answers) for a given
	 * complaint id.
	 */
	public List<AddtlComplaintNarrative> getAdditionalInfo(long complaintId);

	public void saveAnswers(List<AddtlComplaintNarrative> additionalInfo);
}