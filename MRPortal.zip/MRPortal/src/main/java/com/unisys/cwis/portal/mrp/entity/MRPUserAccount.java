package com.unisys.cwis.portal.mrp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="USER_ACCOUNT")
public class MRPUserAccount {


	
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="USER_ACCOUNT_USERACCOUNTID_GENERATOR", sequenceName="USER_ACCOUNT_ID_SEQ",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_ACCOUNT_USERACCOUNTID_GENERATOR")
	@Column(name="USER_ACCOUNT_ID")
	private long userAccountId;
	
	@Column(name="ADDRESS_LINE_1")
	private String addressLine1;
	
	@Column(name="ADDRESS_LINE_2")
	private String addressLine2;
	
	@Column(name="ADMIN_FLAG")
	private Boolean adminFlag;
	
	@Column(name="CITY")
	private String city;
	
	@Column(name="EMAIL_ADDRESS")
	private String email;
	
	@Column(name="WORK_PHONE_NBR_EXTENSION")
	private String workPhoneNumberExtention;
	
	@Column(name="FIRST_NAME")
	private String firstName;
	
	@Column(name="GENDER_CODE")
	private String genderCode;
	
	@Column(name="LAST_NAME")
	private String lastName;
	
	@Column(name="MIDDLE_NAME")
	private String middleName;
	
	@Column(name="MOBILE_NUMBER")
	private String mobileNumber;
	
	@Column(name="ORGANIZATION_NAME")
	private String organizationName;
	
	@Column(name="OTHER")
	private String other;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="REPORTER_PERSON_CATEGORY_CODE")
	private String reporterPersonCategory;
	
	@Column(name="REPORTER_PERSON_ROLE_CODE")
	private String reporterPersonRoleCode;
	
	@Column(name="STATE_CODE")
	private String stateCode;
	
	@Column(name="USERNAME")
	private String userName;
	
	@Column(name="WORK_NUMBER")
	private String workNumber;
	
	@Column(name="ZIP_CODE")
	private String zipCode;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="CREATED_DATE")
	private Date createdDate;
	
	@Column(name="MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;
	
	@Column(name="MARKED_FOR_DELETE_FLAG")
	private Integer markedForDeleteFlag;
	
	/*@OneToMany(mappedBy="userAccount",cascade={CascadeType.ALL},orphanRemoval=true)
	private Set<Complaint> complaints;*/
	
	@Column(name="CONTACT_EMAIL")
	private String contactEmail;
	
	@javax.persistence.Transient
	private Boolean passwordChanged;
	
	@Column(name="USER_TOKEN")
	private String userToken;
	
	@Column(name = "ACTIVE_FLAG")
	private Integer activeFlag; 
	
	@Column(name = "TOKEN_TIMESTAMP")
	private Date tokenTimestamp;
	
	//private DateTimeFormatter dtf;
	public MRPUserAccount(){
		
	}

	public Date getTokenTimestamp() {
		return tokenTimestamp;
	}

	public void setTokenTimestamp(Date date) {
		this.tokenTimestamp = date;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public Boolean getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(Boolean adminFlag) {
		this.adminFlag = adminFlag;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWorkPhoneNumberExtention() {
		return workPhoneNumberExtention;
	}

	public void setWorkPhoneNumberExtention(String workPhoneNumberExtention) {
		this.workPhoneNumberExtention = workPhoneNumberExtention;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getReporterPersonCategory() {
		return reporterPersonCategory;
	}

	public void setReporterPersonCategory(String reporterPersonCategory) {
		this.reporterPersonCategory = reporterPersonCategory;
	}

	public String getReporterPersonRoleCode() {
		return reporterPersonRoleCode;
	}

	public void setReporterPersonRoleCode(String reporterPersonRoleCode) {
		this.reporterPersonRoleCode = reporterPersonRoleCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getWorkNumber() {
		return workNumber;
	}

	public void setWorkNumber(String workNumber) {
		this.workNumber = workNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getMarkedForDeleteFlag() {
		return markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(Integer markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public long getUserAccountId() {
		return userAccountId;
	}

	public void setUserAccountId(long userAccountId) {
		this.userAccountId = userAccountId;
	}

	/*public Set<Complaint> getComplaints() {
		return complaints;
	}

	public void setComplaints(Set<Complaint> complaints) {
		this.complaints = complaints;
	}*/

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Boolean getPasswordChanged() {
		return passwordChanged;
	}

	public void setPasswordChanged(Boolean passwordChanged) {
		this.passwordChanged = passwordChanged;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public Integer getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Integer activeFlag) {
		this.activeFlag = activeFlag;
	}
}
