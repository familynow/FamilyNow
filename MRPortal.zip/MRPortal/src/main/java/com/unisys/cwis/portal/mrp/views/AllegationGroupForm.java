package com.unisys.cwis.portal.mrp.views;

import java.util.Date;
import java.util.List;

public class AllegationGroupForm {

	long allegationGroupId;
	long complaintId;
	String allegationType;	
	Date abuseOrNeglectDateTime;
	String timeZoneOfAbuseOrNeglect;
	String allegationNotes;
	List<ComplaintPartResultRecord> allegedVictims;
	List<ComplaintPartResultRecord> allegedPerpetrators;
	
	public long getAllegationGroupId() {
		return allegationGroupId;
	}
	public void setAllegationGroupId(long allegationGroupId) {
		this.allegationGroupId = allegationGroupId;
	}
	public long getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(long complaintId) {
		this.complaintId = complaintId;
	}
	public String getAllegationType() {
		return allegationType;
	}
	public void setAllegationType(String allegationType) {
		this.allegationType = allegationType;
	}
	public Date getAbuseOrNeglectDateTime() {
		return abuseOrNeglectDateTime;
	}
	public void setAbuseOrNeglectDateTime(Date abuseOrNeglectDateTime) {
		this.abuseOrNeglectDateTime = abuseOrNeglectDateTime;
	}
	public String getTimeZoneOfAbuseOrNeglect() {
		return timeZoneOfAbuseOrNeglect;
	}
	public void setTimeZoneOfAbuseOrNeglect(String timeZoneOfAbuseOrNeglect) {
		this.timeZoneOfAbuseOrNeglect = timeZoneOfAbuseOrNeglect;
	}
	public String getAllegationNotes() {
		return allegationNotes;
	}
	public void setAllegationNotes(String allegationNotes) {
		this.allegationNotes = allegationNotes;
	}
	public List<ComplaintPartResultRecord> getAllegedVictims() {
		return allegedVictims;
	}
	public void setAllegedVictims(List<ComplaintPartResultRecord> allegedVictims) {
		this.allegedVictims = allegedVictims;
	}
	public List<ComplaintPartResultRecord> getAllegedPerpetrators() {
		return allegedPerpetrators;
	}
	public void setAllegedPerpetrators(
			List<ComplaintPartResultRecord> allegedPerpetrators) {
		this.allegedPerpetrators = allegedPerpetrators;
	}	
	
}
