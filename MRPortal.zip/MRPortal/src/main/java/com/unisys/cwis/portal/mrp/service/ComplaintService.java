package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import com.unisys.cwis.portal.mrp.entity.Complaint;

public interface ComplaintService {

	Complaint saveComplaint(long complaintId);
	
	/**
	 * Return List of Complaint based on user id.
	 * @param userId
	 * @return
	 */
	List<Complaint> getComplaintList(long userId);

	/**
	 * Set marked_as_delete_flag to 1
	 * @param complaintId
	 * @return
	 */
	boolean deletecomplaint(long complaintId);
	
	Complaint updateIntakeToComplaint(Complaint complaint);
}
