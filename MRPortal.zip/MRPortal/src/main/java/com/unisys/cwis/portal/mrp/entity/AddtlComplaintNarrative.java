package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the ADDTL_COMPLAINT_NARRATIVES database table.
 * 
 */
@Entity
@Table(name="ADDTL_COMPLAINT_NARRATIVES")
@NamedQuery(name="AddtlComplaintNarrative.findAll", query="SELECT a FROM AddtlComplaintNarrative a")

// We don't want following fields to be serialized to JSON as they are not needed by client.
@JsonIgnoreProperties( { "createdBy", "createdDate", "markedForDeleteFlag", "modifiedBy", "modifiedDate"})
public class AddtlComplaintNarrative implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="COMPLAINT_NARRATIVE_ID_SEQ_GENERATOR", sequenceName="COMPLAINT_NARRATIVE_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COMPLAINT_NARRATIVE_ID_SEQ_GENERATOR")
	@Column(name="NARRATIVE_ID")
	private long narrativeId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Lob
	@Column(name="NARRATIVE_TEXT")
	private String narrativeText;

	@Column(name="NARRATIVE_TOPIC_CODE")
	private String narrativeTopicCode;

	//bi-directional many-to-one association to Complaint
	@ManyToOne
	@JoinColumn(name="COMPLAINT_ID", updatable=false, insertable=false)
	@JsonBackReference
	private Complaint complaint;

	@Column(name="COMPLAINT_ID")
	private long complaintId;
	
	@Transient
	private String refDataCode;
	
	@Transient
	private String longDescription;
	
	public AddtlComplaintNarrative() {
	}

	public long getNarrativeId() {
		return this.narrativeId;
	}

	public void setNarrativeId(long narrativeId) {
		this.narrativeId = narrativeId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getNarrativeText() {
		return this.narrativeText;
	}

	public void setNarrativeText(String narrativeText) {
		this.narrativeText = narrativeText;
	}

	public String getNarrativeTopicCode() {
		return this.narrativeTopicCode;
	}

	public void setNarrativeTopicCode(String narrativeTopicCode) {
		this.narrativeTopicCode = narrativeTopicCode;
	}

	public Complaint getComplaint() {
		return this.complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

	public long getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(long complaintId) {
		this.complaintId = complaintId;
	}

	public String getRefDataCode() {
		return refDataCode;
	}

	public void setRefDataCode(String refDataCode) {
		this.refDataCode = refDataCode;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	
}