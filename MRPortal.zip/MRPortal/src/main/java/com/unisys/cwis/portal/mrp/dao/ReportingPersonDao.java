/**
 * 
 */
package com.unisys.cwis.portal.mrp.dao;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.mrp.entity.Complaint;

/**
 * @author IbrarAti
 *
 */
public interface ReportingPersonDao extends GenericDAO<MRPUserAccount>{
	
	/**
	 * This method return the user account detail
	 * based on the user id.
	 * @param userId
	 * @return
	 */
	public MRPUserAccount getReportingPerson(long userId);
	
	/**
	 * This method saves the user account details.
	 * @param userAccount
	 * @return
	 */
	public MRPUserAccount saveReportingPerson(MRPUserAccount userAccount);
	
	/**
	 * This  create a new complaint.
	 * @param userId
	 * @return
	 */
	public Complaint createComplaint(long userId);
	
	

}
