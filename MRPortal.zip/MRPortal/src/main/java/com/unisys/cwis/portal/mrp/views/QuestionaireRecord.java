package com.unisys.cwis.portal.mrp.views;

public class QuestionaireRecord {

	private long priorityListId;
	private String questionNumber;
	private String question;
	private String questionDesc;
	private String priorityOnYes;
	private String priorityOnNo;
	private String selectedAnswer;
	private String selectedPriority;	
	private String nextOnYes;
	private String nextOnNo;
	private String priorityToolId;
	
	
	public long getPriorityListId() {
		return priorityListId;
	}
	public void setPriorityListId(long priorityListId) {
		this.priorityListId = priorityListId;
	}
	public String getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(String questionNumber) {
		this.questionNumber = questionNumber;
	}	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestionDesc() {
		return questionDesc;
	}
	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}
	public String getPriorityOnYes() {
		return priorityOnYes;
	}
	public void setPriorityOnYes(String priorityOnYes) {
		this.priorityOnYes = priorityOnYes;
	}
	
	public String getPriorityOnNo() {
		return priorityOnNo;
	}
	public void setPriorityOnNo(String priorityOnNo) {
		this.priorityOnNo = priorityOnNo;
	}
	public String getSelectedAnswer() {
		return selectedAnswer;
	}
	public void setSelectedAnswer(String selectedAnswer) {
		this.selectedAnswer = selectedAnswer;
	}
	public String getSelectedPriority() {
		return selectedPriority;
	}
	public void setSelectedPriority(String selectedPriority) {
		this.selectedPriority = selectedPriority;
	}
	public String getNextOnYes() {
		return nextOnYes;
	}
	public void setNextOnYes(String nextOnYes) {
		this.nextOnYes = nextOnYes;
	}
	public String getNextOnNo() {
		return nextOnNo;
	}
	public void setNextOnNo(String nextOnNo) {
		this.nextOnNo = nextOnNo;
	}
	public String getPriorityToolId() {
		return priorityToolId;
	}
	public void setPriorityToolId(String priorityToolId) {
		this.priorityToolId = priorityToolId;
	}
	
}
