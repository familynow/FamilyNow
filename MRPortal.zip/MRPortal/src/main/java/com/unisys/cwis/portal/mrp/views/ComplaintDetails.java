package com.unisys.cwis.portal.mrp.views;

import java.util.List;

import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.entity.ComplaintParticipant;

public class ComplaintDetails {
	private Complaint complaint;
	private MRPUserAccount userAccount;
	private List<ComplaintParticipant> listParticipant;
	private List<AllegationGroup> allegations;
	
	
	public Complaint getComplaint() {
		return complaint;
	}
	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}
	public MRPUserAccount getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(MRPUserAccount userAccount) {
		this.userAccount = userAccount;
	}
	public List<ComplaintParticipant> getListParticipant() {
		return listParticipant;
	}
	public void setListParticipant(List<ComplaintParticipant> listParticipant) {
		this.listParticipant = listParticipant;
	}
	public List<AllegationGroup> getAllegations() {
		return allegations;
	}
	public void setAllegations(List<AllegationGroup> allegations) {
		this.allegations = allegations;
	}
	
}
