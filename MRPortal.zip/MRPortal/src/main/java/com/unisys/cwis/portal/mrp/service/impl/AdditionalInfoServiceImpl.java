package com.unisys.cwis.portal.mrp.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.mrp.dao.AdditionalInfoDao;
import com.unisys.cwis.portal.mrp.dao.ComplaintDao;
import com.unisys.cwis.portal.mrp.entity.AddtlComplaintNarrative;
import com.unisys.cwis.portal.mrp.service.AdditionalInfoService;
import com.unisys.cwis.portal.mrp.views.AdditionalInfoForm;

@Service("additionalInfoService")
@Transactional
public class AdditionalInfoServiceImpl implements AdditionalInfoService {

	@Autowired
	private AdditionalInfoDao additionalInfoDao;

	@Autowired
	private ComplaintDao complaintDao;

	@Override
	public void saveAnswers(AdditionalInfoForm additionalInfoFromUser) {
		complaintDao.saveFeedbackType(getComplaintId(additionalInfoFromUser), additionalInfoFromUser.getFeedbackTypeCode());
		complaintDao.updateNarrativeFlag(getComplaintId(additionalInfoFromUser), new BigDecimal(1));
		additionalInfoDao.saveAnswers(additionalInfoFromUser.getAdditionalInfoList());
	}

	/**
	 * Helper to iterate through all the additional infos and find complaint ID.
	 * 
	 * @param additionalInfoFromUser List of additional info from where complaint ID must be
	 * found.
	 * 
	 * @return complaint id
	 */
	private long getComplaintId(AdditionalInfoForm additionalInfoFromUser) throws IllegalStateException {
		long complaintId = 0;

		for(AddtlComplaintNarrative additionalInfo : additionalInfoFromUser.getAdditionalInfoList()) {
			if(additionalInfo.getComplaintId() != 0) {
				complaintId = additionalInfo.getComplaintId();
				return complaintId;
			}
		}
		
		throw new IllegalStateException("No Complaint ID found in any additional info.");
	}

	@Override
	public List<AddtlComplaintNarrative> getAdditionalInfo(long complaintId) {
		return additionalInfoDao.getAdditionalInfo(complaintId);
	}

	@Override
	public String getFeedbackType(long complaintId) {
		return complaintDao.getFeedbackType(complaintId);
	}
}