package com.unisys.cwis.portal.mrp.service;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

public interface SDMQuestionnaireService {
	
	public QuestionaireRecord createQuestion(QuestionaireRecord qustionDetails, PortalUserObject userObject);
	public QuestionaireRecord getQuestionDetails(long questionId); 
	
}
