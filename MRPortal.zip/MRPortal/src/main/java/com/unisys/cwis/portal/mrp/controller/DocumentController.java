package com.unisys.cwis.portal.mrp.controller;

import java.io.IOException;
import java.io.InputStream;




import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.gridfs.GridFSDBFile;
import com.unisys.cwis.portal.mrp.entity.DocumentOutput;
import com.unisys.cwis.portal.mrp.service.DocumentService;


@Controller
@RequestMapping("/document")
public class DocumentController {
	
	@Autowired
	DocumentService documentService;

	
	/**
	 * This service is used to upload supporting documents for provider applicant
	 * 
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/uploadSupportingDocumentAndSaveOutput/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> uploadDocumentSupportingDocumentPDP(
			@RequestParam(value = "file") MultipartFile file, @RequestParam(value="documentOutput") String documentOutputStr)  {
		ObjectMapper mapper = new ObjectMapper();
		DocumentOutput documentOutput = null;
				
		try {
			 documentOutput = mapper.readValue(documentOutputStr, DocumentOutput.class);
			 documentOutput = documentService.saveDocumentDetailAndUploadFile(documentOutput, file);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return new ResponseEntity<Object>(documentOutput, HttpStatus.OK);
	}
	
	
	/**
	 * This service is used to upload supporting documents for provider applicant
	 * 
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/saveDocumentOutput", method = RequestMethod.POST)
	public ResponseEntity<DocumentOutput> saveDocumentOutput(@RequestBody DocumentOutput documentOutput)  {
		
		return new ResponseEntity<DocumentOutput>(documentService.updateDocumentDetail(documentOutput), HttpStatus.OK);
	}
	
	
	/**
	 * This method return the list of document details based on complaint id.
	 * @param documentId
	 * @return
	 */	
	@RequestMapping(value = "/getDocumentList/{complaintId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDocumentList(
			@PathVariable(value = "complaintId") long complaintId) {
		return new ResponseEntity<Object>(documentService.getDocumentList(complaintId), HttpStatus.OK);
	}
	
	
	/**
	 * This service is used to find document ID for supporting document
	 * 
	 * @param ObjectId
	 * @param response
	 */
	@RequestMapping(value = "/download/{ObjectId}", method = RequestMethod.GET)
	public void getDocumentByObjectId(@PathVariable("ObjectId") String ObjectId, HttpServletResponse response) {
		try {

			GridFSDBFile is = documentService.getDocumentInputFileById(ObjectId);
			String mimeType = documentService.getMimeTypeFromFileName(is.getFilename());
			response.addHeader("Content-disposition", "attachment;filename=" + is.getFilename());
			response.setContentType(mimeType);
			
			InputStream input = is.getInputStream();
			org.apache.commons.io.IOUtils.copy(input, response.getOutputStream());
			response.flushBuffer();
			
		} catch (Exception ex) {
			//log.error("Error writing file to output stream.");
			throw new RuntimeException("IOError writing file to output stream");
		}
	}
	
	
	/**
	 * This method do soft delete of document and update the delete flag as true.
	 * @param documentId
	 * @return
	 */
	@RequestMapping(value = "/delete/{documentId}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Boolean> deleteDocumentDetail(
			@PathVariable(value = "documentId") long documentId) {
		documentService.deleteDocumentDetail(documentId);
		return new ResponseEntity<Boolean>(true, HttpStatus.OK);
	}
	
	/**
	 * This service is used to upload supporting documents for provider applicant
	 * 
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/saveDocumentUploadStatus", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<DocumentOutput> saveDocumentUploadStatus(@RequestParam(value="docStatus")String docStatus, @RequestParam(value="complaintId")String complaintId) {
		documentService.updateDocumentUploadStatus(Long.valueOf(complaintId), docStatus);
		return new ResponseEntity<DocumentOutput>(new DocumentOutput(), HttpStatus.OK);
	}
	
}
