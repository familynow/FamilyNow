package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the COMPLAINT_PARTICIPANT database table.
 * 
 */
@Entity
@Table(name="COMPLAINT_PARTICIPANT")
@NamedQuery(name="ComplaintParticipant.findAll", query="SELECT c FROM ComplaintParticipant c")
public class ComplaintParticipant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="COMPLAINT_PARTICIPANT_IDSEQ_GENERATOR", sequenceName="COMPLAINT_PARTICIPANT_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COMPLAINT_PARTICIPANT_IDSEQ_GENERATOR")
	@Column(name="COMPLAINT_PARTICIPANT_ID", unique=true, nullable=false)
	private long complaintParticipantId;

	@Column(name="ACCESS_TO_CHILD_VICTIM_CODE")
	private String accessToChildVictimCode;

	@Column(name="ADDRESS_LINE_1")
	private String address_line_1;

	@Column(name="ADDRESS_LINE_2")
	private String address_line_2;

	@Temporal(TemporalType.DATE)
	@Column(name="BIRTH_DATE")
	private Date birthDate;

	@Column(name="CHILD_VICTIM_ACCESS_NARRATIVE")
	private String childVictimAccessNarrative;

	private String city;

	@Column(name="COMPLAINT_REFERENCE_NAME")
	private String complaintReferenceName;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="EMAIL_ADDRESS")
	private String emailAddress;

	private String extension;

	@Column(name="FIRST_NAME")
	private String firstName;

	@Column(name="GENDER_CODE")
	private String genderCode;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="LOCATION_OF_ABUSE_CODE")
	private String locationOfAbuseCode;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;


	@Column(name="MIDDLE_NAME")
	private String middleName;

	@Column(name="MOBILE_NUMBER")
	private BigDecimal mobileNumber;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	private String other;

	@Column(name="PERSON_INSIDE_HOUSE")
	private String personInsideHouse;

	@Column(name="RACE_CODE")
	private String raceCode;

	@Column(name="ROLE_CODE")
	private String roleCode;

	@Column(name="STATE_CODE")
	private String stateCode;

	@Column(name="SUFFIX_CODE")
	private String suffixCode;

	@Column(name="UNKNOWN_ADDRESS")
	private BigDecimal unknownAddress;

	@Column(name="WORK_NUMBER")
	private String workNumber;

	@Column(name="ZIP_CODE")
	private String zipCode;
	
	@Transient
	private boolean unknowAddressFlag;

	@Transient
	private boolean addressAvailableFlag;
	
	@Transient
	private String errorMessage;
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isAddressAvailableFlag() {
		return addressAvailableFlag;
	}

	public void setAddressAvailableFlag(boolean addressAvailableFlag) {
		this.addressAvailableFlag = addressAvailableFlag;
	}

	public boolean isUnknowAddressFlag() {
		return unknowAddressFlag;
	}

	public void setUnknowAddressFlag(boolean unknowAddressFlag) {
		this.unknowAddressFlag = unknowAddressFlag;
	}

	//bi-directional many-to-one association to Complaint
	@ManyToOne
	@JoinColumn(name="COMPLAINT_ID", referencedColumnName = "COMPLAINT_ID",insertable = true,updatable=true)
	@JsonBackReference
	private Complaint complaint;

	public ComplaintParticipant() {
	}

	public long getComplaintParticipantId() {
		return this.complaintParticipantId;
	}

	public void setComplaintParticipantId(long complaintParticipantId) {
		this.complaintParticipantId = complaintParticipantId;
	}

	public String getAccessToChildVictimCode() {
		return this.accessToChildVictimCode;
	}

	public void setAccessToChildVictimCode(String accessToChildVictimCode) {
		this.accessToChildVictimCode = accessToChildVictimCode;
	}

	public String getAddress_line_1() {
		return this.address_line_1;
	}

	public void setAddress_line_1(String address_line_1) {
		this.address_line_1 = address_line_1;
	}

	public String getAddress_line_2() {
		return this.address_line_2;
	}

	public void setAddress_line_2(String address_line_2) {
		this.address_line_2 = address_line_2;
	}

	public Date getBirthDate() {
		return this.birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getChildVictimAccessNarrative() {
		return this.childVictimAccessNarrative;
	}

	public void setChildVictimAccessNarrative(String childVictimAccessNarrative) {
		this.childVictimAccessNarrative = childVictimAccessNarrative;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getComplaintReferenceName() {
		return this.complaintReferenceName;
	}

	public void setComplaintReferenceName(String complaintReferenceName) {
		this.complaintReferenceName = complaintReferenceName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getExtension() {
		return this.extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGenderCode() {
		return this.genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLocationOfAbuseCode() {
		return this.locationOfAbuseCode;
	}

	public void setLocationOfAbuseCode(String locationOfAbuseCode) {
		this.locationOfAbuseCode = locationOfAbuseCode;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public BigDecimal getMobileNumber() {
		return this.mobileNumber;
	}

	public void setMobileNumber(BigDecimal mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOther() {
		return this.other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getPersonInsideHouse() {
		return this.personInsideHouse;
	}

	public void setPersonInsideHouse(String personInsideHouse) {
		this.personInsideHouse = personInsideHouse;
	}

	public String getRaceCode() {
		return this.raceCode;
	}

	public void setRaceCode(String raceCode) {
		this.raceCode = raceCode;
	}

	public String getRoleCode() {
		return this.roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getStateCode() {
		return this.stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getSuffixCode() {
		return this.suffixCode;
	}

	public void setSuffixCode(String suffixCode) {
		this.suffixCode = suffixCode;
	}

	public BigDecimal getUnknownAddress() {
		return this.unknownAddress;
	}

	public void setUnknownAddress(BigDecimal unknownAddress) {
		this.unknownAddress = unknownAddress;
	}

	public String getWorkNumber() {
		return this.workNumber;
	}

	public void setWorkNumber(String workNumber) {
		this.workNumber = workNumber;
	}

	public String getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Complaint getComplaint() {
		return this.complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

}