package com.unisys.cwis.portal.mrp.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.sql2o.Connection;
import org.sql2o.Query;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.dao.AllegationGroupDao;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.views.AllegationGroupForm;
import com.unisys.cwis.portal.mrp.views.AllegationGroupRecord;
import com.unisys.cwis.portal.mrp.views.ComplaintPartResultRecord;

@Repository("allegationGroupDao")
public class AllegationGroupDaoImpl extends GenericDAOImpl<AllegationGroup> implements AllegationGroupDao {
	private Logger log = Logger.getLogger(AllegationGroupDaoImpl.class.getName());

	public List<AllegationGroupRecord> retrieveAll(long complaintId) {

		StringBuffer sql = new StringBuffer();
		log.info("**Inside Retrieve ALL Participants Method**");
		 
		
		 sql.append(" select ag.ALLEGATION_NOTES as allegationNotes, ag.allegation_group_id  As allegationGroupId, ")
		 .append(" (select Distinct(a.ABUSE_OR_NEGLECT_DATE_TIME) from allegation a where a.allegation_group_id = ag.allegation_group_id)")
		 .append(" As allegationDateTime, (select Distinct(a.allegation_type_code) from allegation a where a.allegation_group_id = ag.allegation_group_id) As allegationType, ")
		 .append(" ( select REGEXP_REPLACE( LISTAGG(CASE WHEN cp.last_name IS NOT NULL THEN cp.last_name || ', ' ELSE '' END ")
		 .append(" || CASE WHEN cp.first_name IS NOT NULL THEN cp.first_name ELSE '' END,'; ') WITHIN GROUP")
		 .append(" ( ORDER BY cp.LAST_NAME ||cp.First_name),'([^;]+)(;[ ]*\\1)+', '\\1\\3' ) ")
		 .append(" FROM complaint_participant cp LEFT JOIN allegation a  ON  ")
		 .append(" a.ACV_participant_id=cp.complaint_participant_id where a.allegation_group_id = ag.allegation_group_id )AS allegedVictims ,")
		 .append(" ( select REGEXP_REPLACE (LISTAGG(cp.complaint_participant_id, ',' ) WITHIN GROUP( ORDER BY cp.complaint_participant_id) ,'([^,]+)(,[ ]*\\1)+', '\\1\\3')")
		 .append(" FROM complaint_participant cp LEFT JOIN allegation a  ON  a.ACV_participant_id=cp.complaint_participant_id") 
		 .append(" where a.allegation_group_id = ag.allegation_group_id ) as acvId,")
		 .append("( select REGEXP_REPLACE (LISTAGG(cp.complaint_participant_id, ',') WITHIN GROUP( ORDER BY cp.complaint_participant_id) ,'([^,]+)(,[ ]*\\1)+', '\\1\\3')")
		 .append("FROM complaint_participant cp LEFT JOIN allegation a  ON  a.AP_participant_id=cp.complaint_participant_id ")
		 .append("where a.allegation_group_id = ag.allegation_group_id ) as apId,")
		 .append("( SELECT REGEXP_REPLACE(LISTAGG(CASE WHEN cp.last_name IS NOT NULL THEN cp.last_name || ', ' ELSE '' END || ")
		 .append("CASE WHEN cp.first_name IS NOT NULL THEN cp.first_name ELSE '' END,'; ') ")
		 .append("WITHIN GROUP( ORDER BY cp.LAST_NAME ||cp.First_name),'([^;]+)(;[ ]*\\1)+', '\\1\\3' )")
		 .append(" FROM complaint_participant cp LEFT JOIN allegation a ON a.AP_participant_id=cp.complaint_participant_id ")
		 .append(" where a.allegation_group_id = ag.allegation_group_id ) AS allegedPerpetrators FROM  ALLEGATION_GROUP ag ")
		.append(" WHERE ag.complaint_ID="+complaintId +" and ag.MARKED_FOR_DELETE_FLAG != 1");

		 Connection aConnection = getReadOnlyController();

		 Query q = aConnection.createQuery(sql.toString());
			System.out.println(q.toString());
			
		List<AllegationGroupRecord> results = aConnection.createQuery(sql.toString()).throwOnMappingFailure(false).executeAndFetch(AllegationGroupRecord.class);
		aConnection.close();
		return results; 
	}

	public List<ComplaintPartResultRecord> getAllegationParticipants(long complaintId, String roleCode,
			long allegationGroupId) {
		StringBuffer sql = new StringBuffer();
		log.info("**Inside Retrieve Participants Method**");

		sql.append("select cp.complaint_participant_id as participantId, ")
				.append("trim(CASE WHEN cp.last_name IS NOT NULL THEN cp.last_name || ', ' ELSE '' END || ")
				.append("CASE WHEN cp.first_name IS NOT NULL THEN cp.first_name ELSE '' END || ")
				.append("CASE WHEN cp.middle_name IS NOT NULL THEN ' ' || cp.middle_name ELSE '' END) as participantName, ")
				.append("round(months_between(sysdate, cp.birth_date) /12) as age, cp.gender_code as gender ");
		if (roleCode.equals("ACV")) {
			sql.append(",(select count(distinct(a.acv_participant_id)) as count from allegation a ")
					.append("where a.allegation_group_id = ").append(allegationGroupId)
					.append(" and a.acv_participant_id = cp.complaint_participant_id) as Selected ");
		}
		if (roleCode.equals("AP")) {
			sql.append(",(select count(distinct(a.ap_participant_id)) as count from allegation a ")
					.append("where a.allegation_group_id = ").append(allegationGroupId)
					.append(" and a.ap_participant_id = cp.complaint_participant_id) as Selected ");
		}
		sql.append("from complaint_participant cp where cp.complaint_id=")
				.append(complaintId).append(" AND cp.role_code like '%").append(roleCode)
				.append("%' AND (cp.marked_for_delete_flag is null or cp.marked_for_delete_flag =0) ")
				.append("group by cp.complaint_participant_id, cp.last_name, cp.first_name, cp.middle_name, ")
				.append("cp.race_code, cp.gender_code, cp.birth_date ")
				.append("order by cp.complaint_participant_id");
		
		Connection aConnection = getReadOnlyController();
		List<ComplaintPartResultRecord> results =  aConnection.createQuery(sql.toString()).executeAndFetch(ComplaintPartResultRecord.class);
		aConnection.close();
		
		return results;
	}

	public Boolean checkForDuplicateAllegation(long complaintId, long allegationGroupId, String allegationType,
			long allegedVictimId, long allegedPerpetratorId) {
		StringBuffer sql = new StringBuffer();

		sql.append("select count(*) as allegations from allegation a")
				.append(" left join allegation_group ag on ag.allegation_group_id = a.allegation_group_id ")
				.append(" where ag.complaint_id = ").append(complaintId).append(" and a.acv_participant_id = ")
				.append(allegedVictimId).append(" and a.ap_participant_id = ").append(allegedPerpetratorId)
				.append(" and a.allegation_type_code='").append(allegationType).append("'");
		if (allegationGroupId > 0) {
			sql.append(" and a.allegation_group_id != ").append(allegationGroupId);
		}
		sql.append(" and ag.marked_for_delete_flag !=1 ");
		
		Connection aConnection = getReadOnlyController();
		List<ComplaintPartResultRecord> resultRecord = aConnection.createQuery(sql.toString())
				.executeAndFetch(ComplaintPartResultRecord.class);
		aConnection.close();

		if (null != resultRecord && resultRecord.size() > 0) {
			Integer allegationCount = Integer.parseInt(resultRecord.get(0).getAllegations());
			if (allegationCount > 0)
				return true;
			else
				return false;
		} else
			return false;
	}
	public String getAllegationNotes(long complaintId){
		StringBuffer sql = new StringBuffer();
		sql.append("select allegation_notes from allegation_group where marked_for_delete_flag!=1 and complaint_Id = ").append(complaintId);
		
		Connection aConnection = getReadOnlyController();
		List<String> resultRecord = aConnection.createQuery(sql.toString())
				.executeAndFetch(String.class);
		aConnection.close();
		if (null != resultRecord && resultRecord.size() > 0) {
			String allegationNotes = resultRecord.get(0);
			return allegationNotes;
		} else
			return "";
	}

	@Override
	public void saveNarrative(AllegationGroupForm allegationGroupForm) {
		// AllegationGroupForm allegationGroupForm
		Criteria criteria = this.getSession().createCriteria(AllegationGroup.class,"allegation");
		criteria.add(Restrictions.eq("complaint.complaintId", allegationGroupForm.getComplaintId()));
		criteria.add(Restrictions.eq("markedForDeleteFlag", Boolean.FALSE));
		List<AllegationGroup> allegationGroups = (List<AllegationGroup>) criteria.list();
		if(allegationGroups!=null && allegationGroups.size()>0){
			for(AllegationGroup allegationGroup :allegationGroups){
				allegationGroup.setAllegationNotes(allegationGroupForm.getAllegationNotes());
				this.save(allegationGroup);
			}
		}
	}

	@Override
	public List<AllegationGroup> getAllegationDetails(long complaintId) {
		// TODO Auto-generated method stub
		Criteria criteria = this.getSession().createCriteria(AllegationGroup.class,"allegation");
		criteria.add(Restrictions.eq("complaint.complaintId", complaintId));
		criteria.add(Restrictions.eq("markedForDeleteFlag", Boolean.FALSE));
		List<AllegationGroup> allegationGroups = (List<AllegationGroup>) criteria.list();
		
		Set<AllegationGroup> groups = new HashSet<AllegationGroup>(allegationGroups);
		allegationGroups = new ArrayList<AllegationGroup>(groups);
		for(int i=0;i<allegationGroups.size();i++){
			System.out.println("Group Id -  "+allegationGroups.get(i).getAllegationGroupId());
		}
		return allegationGroups;
	}
}
