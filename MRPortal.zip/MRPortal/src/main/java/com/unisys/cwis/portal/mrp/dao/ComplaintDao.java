package com.unisys.cwis.portal.mrp.dao;

import java.math.BigDecimal;
import java.util.List;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.Complaint;

public interface ComplaintDao extends GenericDAO<Complaint>{
	
	/**
	 * Return List of complaint based on complaint id.
	 * @param userId
	 * @return
	 */
	List<Complaint> getComplaintList(long userId);

	/**
	 * Set marked_as_delete_flag to true.
	 * @param complaintId
	 */
	boolean deleteComplaint(long complaintId);

	String getFeedbackType(long complaintId);

	void saveFeedbackType(long complaintId, String feedbackType);
	
	/**
	 * Update narrative flag for additional info.
	 * 
	 * @param complaintId The complaint ID for which narrative flag needs to be
	 * updated.
	 * @param flag 1 means show tick mark, 0 means don't show tick mark.
	 */
	void updateNarrativeFlag(long complaintId, BigDecimal flag);
	
}
