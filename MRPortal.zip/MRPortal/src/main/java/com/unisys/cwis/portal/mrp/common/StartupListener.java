package com.unisys.cwis.portal.mrp.common;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.sql.DataSource;

import org.sql2o.Sql2o;

import com.unisys.cwis.portal.common.core.DatabaseController;
import com.unisys.cwis.portal.commons.cache.CacheManager;


public class StartupListener implements ServletContextListener {
	
	@Override
	public void contextInitialized(ServletContextEvent contextEnv) {
		try{
			/*System.out.println("contextEnv is "+contextEnv);
			ApplicationContext appCtx = WebApplicationContextUtils.getWebApplicationContext(contextEnv.getServletContext());
			System.out.println("appCtx is "+appCtx);*/
			DatabaseController dbController = new DatabaseController();//appCtx.getBean("dbConfigBean");
			System.out.println("dbController is "+dbController);
			Context initContext = new InitialContext();
			DataSource ds = (DataSource) initContext.lookup("java:jboss/jdbc/MRPDS");
			System.out.println("ds is "+ds);
			Sql2o readOnlyController = new Sql2o(ds);
			dbController.setDatabaseController(readOnlyController);
			
			// Load Cache
			CacheManager cacheManager = new CacheManager();		
			cacheManager.init();

		}catch(Exception e){
			e.printStackTrace();
		}
		
		//ArrayList<ReferenceData> retList = cacheManager.getDomainValues("504Form");
		//System.out.println("retList.size " + retList.size());
	}

	@Override
	public void contextDestroyed(ServletContextEvent contextEnv) {
		// Load Cache
		CacheManager cacheManager = new CacheManager();		
		cacheManager.reset();
	}

}
