package com.unisys.cwis.portal.mrp.dao;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mongodb.gridfs.GridFSDBFile;
import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.DocumentOutput;

public interface DocumentDao extends GenericDAO<DocumentOutput> {
	
	/**
	 * This method is to save document in mongo db.
	 * @param docFile
	 * @return
	 */
	public String saveDocumentsInMongo(MultipartFile docFile);

	/**
	 * This method return the list of document based on complaint id.
	 * @param complaintId
	 * @return
	 */
	public List<DocumentOutput> getDocumentList(long complaintId);
	
	
	/**
	 * This method is used to find document by ID from DB
	 * 
	 * @param id
	 * @return input
	 */
	public GridFSDBFile getDocumentById(String id);

	/**
	 * This method update the status of complaint for document as yes or no
	 * @param complaintId
	 * @param str
	 * @return
	 */
	public boolean updateDocumentUploadStatus(long complaintId, String str);
	

}
