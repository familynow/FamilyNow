package com.unisys.cwis.portal.mrp.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.ComplaintService;




@RestController
@RequestMapping("/complaint")
public class ComplaintController {
	
	@Autowired
	ComplaintService complaintService;
	/**
	 * This service is used to get list of complaints logged by logged in user
	 * @param reportingPersonId
	 * @return
	 */
	@RequestMapping(value = "/complaintlist/{reportingPersonId}", method = RequestMethod.GET)
	public ResponseEntity<List<Complaint>> getComplaintList(@PathVariable("reportingPersonId") String reportingPersonId){
		List<Complaint> user = complaintService.getComplaintList(Long.valueOf(reportingPersonId));
		return new ResponseEntity<List<Complaint>>(user,HttpStatus.OK);
	}
	
	/**
	 * This method is used to delete a particular complant by its owner
	 * @param complaintId
	 * @return
	 */
	
	@RequestMapping(value = "/deletecomplaint/{complaintId}", method = RequestMethod.DELETE)
	public ResponseEntity<Boolean> deleteInquiry(@PathVariable(value = "complaintId") long complaintId){
		
		complaintService.deletecomplaint(complaintId);
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
	}

}
