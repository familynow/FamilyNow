package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.service.PriorityToolService;
import com.unisys.cwis.portal.mrp.service.SDMQuestionnaireService;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

@RestController
@RequestMapping("/manageSDMTool")
public class ManageSDMToolController {
	@Autowired
	private PriorityToolService priorityService;
	@Autowired
	private SDMQuestionnaireService questionnaireService;
	private Logger log = Logger.getLogger(ManageSDMToolController.class.getName());

	public ManageSDMToolController() {
		log.info("Constructor ManageSDMToolController");
	}

	/**
	 * This service returns list of Priority Tools that can be run 
	 * 
	 * @return List<PriorityRecord>
	 */
	@RequestMapping(value = "/getSDMList", method = RequestMethod.GET)
	public ResponseEntity<List<PriorityTool>> getPriorityTools() {
		List<PriorityTool> priorityRecords = priorityService.getPriorityTools();
		return new ResponseEntity<List<PriorityTool>>(priorityRecords, HttpStatus.OK);
	}

	/**
	 * This service returns details for a PriorityTool with the questions to be displayed
	 * based on priorityToolId
	 * 
	 * @param priorityToolId
	 * @return QuestionaireForm
	 */
	@RequestMapping(value = "/getSDMToolDetails/{priorityToolId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<PriorityTool> getSDMToolDetails(@PathVariable("priorityToolId") long priorityToolId) {
		log.info("PriorityController getQuestionaire");
		PriorityTool priorityTool = priorityService.getPriorityToolDetails(priorityToolId);
		return new ResponseEntity<PriorityTool>(priorityTool, HttpStatus.OK);
	}
	
	/**
	 * This service returns details for a question with the question mapping and description
	 * based on priorityToolId
	 * 
	 * @param priorityToolId
	 * @return QuestionaireForm
	 */
	@RequestMapping(value = "/getQuestionDetails/{questionId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<QuestionaireRecord> getQuestionDetails(@PathVariable("questionId") long questionId) {
		log.info("PriorityController getQuestionaire");
		QuestionaireRecord questionaireRecord = questionnaireService.getQuestionDetails(questionId);
		return new ResponseEntity<QuestionaireRecord>(questionaireRecord, HttpStatus.OK);
	}
	

	/**
	 * This method saves a question for a priority tool
	 * based on priorityToolId
	 * 
	 * @param QuestionaireRecord
	 * @return QuestionaireRecord
	 */
	@RequestMapping(value = "/saveQuestion/", method = RequestMethod.POST)
	public ResponseEntity<QuestionaireRecord> saveQuestion(@RequestBody QuestionaireRecord questionaireRecord) {
		log.info("ComplaintController.saveQuestion");
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		questionaireRecord=questionnaireService.createQuestion(questionaireRecord, userObject);
		return new ResponseEntity<QuestionaireRecord>(questionaireRecord, HttpStatus.OK);
	}
	/**
	 * This method saves a priority tool
	 * 
	 * @param PriorityTool
	 * @return PriorityTool
	 */
	@RequestMapping(value = "/saveSDMTool/", method = RequestMethod.POST)
	public ResponseEntity<PriorityTool> saveSDMTool(@RequestBody PriorityTool priorityTool) {
		log.info("ComplaintController.saveSDMTool");
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		priorityTool=priorityService.createSDMTool(priorityTool, userObject);
		return new ResponseEntity<PriorityTool>(priorityTool, HttpStatus.OK);
	}
	/**
	 * This method deletes a priority tool based on priorityToolId
	 * 
	 * @param priorityToolId
	 * @return PriorityTool
	 */
	@RequestMapping(value = "/deleteSDMTool/{priorityToolId:[\\d]+}", method = RequestMethod.DELETE)
	public ResponseEntity<PriorityTool> deleteSDMTool(@PathVariable("priorityToolId") long priorityToolId) {
		log.info("ComplaintController.deleteSDMTool");
		priorityService.deleteSDMTool(priorityToolId);
		return new ResponseEntity<PriorityTool>(new PriorityTool(), HttpStatus.OK);
	}
	/**
	 * This method deletes all questions of a priority tool based on priorityToolId
	 * 
	 * @param priorityToolId
	 * @return PriorityTool
	 */
	@RequestMapping(value = "/deleteSDMQuestions/{priorityToolId:[\\d]+}", method = RequestMethod.DELETE)
	public ResponseEntity<PriorityTool> deleteSDMQuestions(@PathVariable("priorityToolId") long priorityToolId) {
		log.info("ComplaintController.deleteSDMTool");
		priorityService.deleteSDMQuestions(priorityToolId);
		return new ResponseEntity<PriorityTool>(new PriorityTool(), HttpStatus.OK);
	}
	
}
