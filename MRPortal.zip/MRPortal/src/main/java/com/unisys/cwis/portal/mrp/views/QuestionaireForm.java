package com.unisys.cwis.portal.mrp.views;

import java.util.List;

public class QuestionaireForm {
	long priorityToolId;
	String priority;
	String status;
	List<QuestionaireRecord> questionaires;
	
	public long getPriorityToolId() {
		return priorityToolId;
	}
	public void setPriorityToolId(long priorityToolId) {
		this.priorityToolId = priorityToolId;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<QuestionaireRecord> getQuestionaires() {
		return questionaires;
	}
	public void setQuestionaires(List<QuestionaireRecord> questionaires) {
		this.questionaires = questionaires;
	}
		
}
