package com.unisys.cwis.portal.mrp.dao;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.PriorityList;

public interface PriorityListDao extends GenericDAO<PriorityList>{
	
}
