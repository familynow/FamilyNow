/**
 * 
 */
package com.unisys.cwis.portal.mrp.service;

import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.Complaint;

/**
 * @author IbrarAti
 * 
 *  
 */
public interface ReportingPersonService {

	/**
	 * This method return the user account detail
	 * based on the user id.
	 * @param userId
	 * @return
	 */
	public MRPUserAccount getReportingPerson(long userId);
	
	/**
	 * This method saves the user account details.
	 * @param userAccount
	 * @param userObject 
	 * @return
	 */
	public MRPUserAccount saveReportingPerson(MRPUserAccount userAccount, PortalUserObject userObject);
	
	/**
	 * This method create a new complaint corresponding 
	 * to the associated user_account id.
	 * @return
	 */
	public Complaint createComplaint(long userId);
}
