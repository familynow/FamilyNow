package com.unisys.cwis.portal.mrp.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.sql2o.Connection;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.dao.PriorityToolDao;
import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

@Repository("priorityDao")
public class PriorityToolDaoImpl extends GenericDAOImpl<PriorityTool> implements PriorityToolDao{
	
	private Logger log = Logger.getLogger(PriorityToolDaoImpl.class.getName());	
	public List<PriorityTool> getPriorityTools() {
		StringBuffer sqlCommand=new StringBuffer();
		sqlCommand.append(" select pt.priority_tool_id as priorityToolId, pt.PRIORITY_ALLEGATION_CATEGORY as priorityAllegationCategory, pt.allegation_description_text as allegationDescriptionText, ")
		.append("pt.priority_tool_name as priorityToolName, pt.PRIORITY_ENTERED_BY as priorityEnteredBy, pt.created_date as createdDate from priority_tool pt left join ref_data rd ")
		.append("on rd.ref_data_code = pt.priority_allegation_category ")
		.append("where pt.priority_end_date is null and rd.domain_code = 'PriorityAllegationCategory' order by rd.sort_value ");
		
		Connection aConnection = getReadOnlyController();
		
		List<PriorityTool> results = aConnection.createQuery(sqlCommand.toString()).throwOnMappingFailure(false).executeAndFetch(PriorityTool.class);
		aConnection.close();
		
		return results; 
	}

	public List<QuestionaireRecord> getQuestionaire(long priorityToolId) {
		// TODO Auto-generated method stub
		StringBuffer sqlCommand=new StringBuffer();
		sqlCommand.append("SELECT pl.priority_list_id AS priorityListId, ")
			.append(" pl.priority_question_number AS questionNumber, pl.priority_question_text AS question, pl.question_description_text AS questionDesc, ")       
			.append("CASE WHEN pl.yes_priority IS NULL THEN pl.yes_priority_question_number ELSE pl.yes_priority END AS priorityOnYes, ")
			.append("CASE WHEN pl.no_priority IS NULL THEN pl.no_priority_question_number ELSE pl.no_priority END AS priorityOnNo ")
			.append("FROM priority_list pl  WHERE pl.priority_tool_id = ").append(priorityToolId);		

		Connection aConnection = getReadOnlyController();

		List<QuestionaireRecord> results = aConnection.createQuery(sqlCommand.toString()).throwOnMappingFailure(false).executeAndFetch(QuestionaireRecord.class);
		aConnection.close();
		
		return results; 
	}

	@Override
	public void deleteSDMQuestions(long priorityToolId) {
		log.debug("priorityToolId is " +priorityToolId);
		Query query = getSession().createQuery("delete PriorityList where priorityToolId = :ID");
		query.setParameter("ID", priorityToolId);
		int result = query.executeUpdate();
		log.debug("result is " +result);
	}	
}
