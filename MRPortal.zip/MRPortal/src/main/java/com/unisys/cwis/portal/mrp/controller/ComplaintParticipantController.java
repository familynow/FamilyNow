package com.unisys.cwis.portal.mrp.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.ComplaintParticipant;
import com.unisys.cwis.portal.mrp.service.ComplaintParticipantService;
import com.unisys.cwis.portal.mrp.views.ComplaintParticipantForm;

@RestController
@RequestMapping("/complaintParticipant")
public class ComplaintParticipantController {
	@Autowired
	private ComplaintParticipantService complaintParticipantService;
	private Logger log = Logger.getLogger(ComplaintParticipantController.class.getName());

	public ComplaintParticipantController() {
		log.info("Constructor ComplaintParticipantController");
	}

	/**
	 * This service retrieve list of complaint participants based on intake id
	 * provided as parameter.
	 * 
	 * @param complaintId
	 * @return List<IntakePartResultRecord>
	 */
	@RequestMapping(value = "/retrieveAllComplaintParticipants/{complaintId}", method = RequestMethod.GET)
	public ResponseEntity<ComplaintParticipantForm> retrieveAllIntakeParticipants(
			@PathVariable("complaintId") long complaintId) {
		ComplaintParticipantForm results = complaintParticipantService.retrieveAllComplaintParticipants(complaintId);
		return new ResponseEntity<ComplaintParticipantForm>(results, HttpStatus.OK);
	}
	/**
	 * This service is used to edit and ComplaintParticipant record
	 * 
	 * @param complaintParticipantId
	 * @return ComplaintParticipant
	 */
	@RequestMapping(value = "/editComplaintParticipant/{complaintParticipantId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<ComplaintParticipantForm> editComplaintParticipant(
			@PathVariable("complaintParticipantId") long complaintParticipantId) {
		log.info("ComplaintController.editComplaint " + complaintParticipantId);
		ComplaintParticipantForm complaintParticipant = complaintParticipantService.editComplaintParticipant(complaintParticipantId);
		return new ResponseEntity<ComplaintParticipantForm>(complaintParticipant, HttpStatus.OK);
	}

	/**
	 * This service is used to set the ComplaintParticipant Name as ComplaintName
	 * based on complaintParticipantId
	 * 
	 * @param complaintParticipantId
	 * @param complaintId
	 * @return ComplaintParticipant
	 */
	@RequestMapping(value = "/makeComplaintName/{complaintParticipantId}/{complaintId}", method = RequestMethod.GET)
	public ResponseEntity<ComplaintParticipantForm> makeComplaintName(
			@PathVariable("complaintParticipantId") long complaintParticipantId, @PathVariable("complaintId") long complaintId) {
		log.info("ComplaintController.createComplaint " + complaintParticipantId);
		log.info("complaintId " + complaintId);
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		ComplaintParticipantForm complaintParticipantForm = complaintParticipantService.makeComplaintName(complaintParticipantId, complaintId, userObject);
		return new ResponseEntity<ComplaintParticipantForm>(complaintParticipantForm, HttpStatus.OK);
	}

	/**
	 * This service is used to save ComplaintParticipant details to DB
	 * 
	 * @param complaintParticipant
	 * @return ComplaintParticipant
	 */
	@RequestMapping(value = "/saveComplaintParticipant/", method = RequestMethod.POST)
	public ResponseEntity<ComplaintParticipantForm> saveComplaintParticipant(@RequestBody ComplaintParticipant complaintParticipant) {
		log.info("ComplaintController.saveComplaintParticipant");
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		ComplaintParticipantForm complaintParticipantForm = complaintParticipantService.saveComplaintParticipant(complaintParticipant, userObject);
		return new ResponseEntity<ComplaintParticipantForm>(complaintParticipantForm, HttpStatus.OK);
	}
	
	/**
	 * 
	 */
	@RequestMapping(value = "/deleteParticipant/{complaintParticipantId}/{complaintId}", method = RequestMethod.GET)
	public ResponseEntity<ComplaintParticipantForm> deleteParticipant(
			@PathVariable("complaintParticipantId") long complaintParticipantId, @PathVariable("complaintId") long complaintId) {
		log.info("ComplaintController.createComplaint " + complaintParticipantId);
		log.info("complaintId " + complaintId);
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		ComplaintParticipantForm complaintParticipantForm = complaintParticipantService.deleteComplaintParticipant(complaintParticipantId, complaintId, userObject);
		return new ResponseEntity<ComplaintParticipantForm>(complaintParticipantForm, HttpStatus.OK);
	}
}
