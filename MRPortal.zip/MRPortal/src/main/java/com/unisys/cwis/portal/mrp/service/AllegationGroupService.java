package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.views.AllegationGroupForm;
import com.unisys.cwis.portal.mrp.views.AllegationGroupRecord;

public interface AllegationGroupService {

	AllegationGroupForm getAllegationParticipants(long complaintId, long allegationGroupId);

	List<AllegationGroupRecord> retrieveAll(long complaintId);

	AllegationGroup delete(long allegationGroupId);

	void save(AllegationGroupForm allegationGroupForm, PortalUserObject userObject);

	Boolean checkForDuplicateAllegation(long complaintId, long allegationGroupId, String allegationType,
			long allegedVictimId, long allegedPerpetratorId);

	void saveNarrative(AllegationGroupForm allegationGroupForm);
	
	List<AllegationGroup> getAllegationDetails(long complaintId);
	

}
	