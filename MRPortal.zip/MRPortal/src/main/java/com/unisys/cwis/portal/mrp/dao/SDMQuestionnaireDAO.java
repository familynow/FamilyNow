package com.unisys.cwis.portal.mrp.dao;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.PriorityList;

public interface SDMQuestionnaireDAO extends GenericDAO<PriorityList>{
	public void createQuestion(PriorityList qustionDetails);
	public PriorityList getQuestionDetails(long questionId);
}
