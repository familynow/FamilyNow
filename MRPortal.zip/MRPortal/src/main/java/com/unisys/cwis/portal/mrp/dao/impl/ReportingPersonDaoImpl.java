package com.unisys.cwis.portal.mrp.dao.impl;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.mrp.dao.ReportingPersonDao;
import com.unisys.cwis.portal.mrp.entity.Complaint;

@Repository("reportingPersonDao")
public class ReportingPersonDaoImpl<T> extends GenericDAOImpl<MRPUserAccount> implements ReportingPersonDao {

	@Override
	public MRPUserAccount getReportingPerson(long userId) {
		Criteria criteria = this.getSession().createCriteria(MRPUserAccount.class,"inquiry");
		criteria.add(Restrictions.eq("userAccountId", userId));
		criteria.add(Restrictions.eq("markedForDeleteFlag", new Integer(0)));
		MRPUserAccount user = (MRPUserAccount) criteria.uniqueResult();
		return user;
	}

	@Override
	public MRPUserAccount saveReportingPerson(MRPUserAccount userAccount) {
		if(userAccount.getUserAccountId()>0)
			this.getSession().merge(userAccount);
		else
			this.save(userAccount);
		return userAccount;
	}

	@Override
	public Complaint createComplaint(long userId) {
		
		Complaint complaint = new Complaint();
		complaint.setCreatedBy(String.valueOf(userId));
		complaint.setCreatedDate(new Date());
		complaint.setModifiedBy(String.valueOf(userId));
		complaint.setModifiedDate(new Date());
		complaint.setMarkedForDeleteFlag(new BigDecimal(0));
		MRPUserAccount user = new MRPUserAccount();
		user.setUserAccountId(userId);
		complaint.setUserAccount(user);
		complaint.setComplaintStatus("INPROGRESS");
		complaint.setUserAccountId(userId);
		complaint.setProfileDataAvailableFlag(new BigDecimal(1));
		Session session = this.getSession();
		session.save(complaint);
		return complaint;
	}

}
