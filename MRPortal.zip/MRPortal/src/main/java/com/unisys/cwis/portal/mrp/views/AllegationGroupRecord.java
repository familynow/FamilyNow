package com.unisys.cwis.portal.mrp.views;

import java.util.Date;


public class AllegationGroupRecord implements Comparable<AllegationGroupRecord> {

	long allegationGroupId;	
	Date allegationDateTime;
	String allegationType;	
	String allegedVictims;
	String allegedPerpetrators;
	String allegationNotes;
	String acvId;
	String apId;
	
	
	public long getAllegationGroupId() {
		return allegationGroupId;
	}
	public void setAllegationGroupId(long allegationGroupId) {
		this.allegationGroupId = allegationGroupId;
	}	
	public Date getAllegationDateTime() {
		return allegationDateTime;
	}
	public void setAllegationDateTime(Date allegationDateTime) {
		this.allegationDateTime = allegationDateTime;
	}
	public String getAllegationType() {
		return allegationType;
	}
	public void setAllegationType(String allegationType) {
		this.allegationType = allegationType;
	}
	public String getAllegedVictims() {
		return allegedVictims;
	}
	public void setAllegedVictims(String allegedVictims) {
		this.allegedVictims = allegedVictims;
	}
	public String getAllegedPerpetrators() {
		return allegedPerpetrators;
	}
	public void setAllegedPerpetrators(String allegedPerpetrators) {
		this.allegedPerpetrators = allegedPerpetrators;
	}
	public String getAllegationNotes() {
		return allegationNotes;
	}
	public void setAllegationNotes(String allegationNotes) {
		this.allegationNotes = allegationNotes;
	}
	public String getAcvId() {
		return acvId;
	}
	public void setAcvId(String acvId) {
		this.acvId = acvId;
	}
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	@Override
	public int compareTo(AllegationGroupRecord allegation) {
		return this.allegationGroupId<allegation.getAllegationGroupId()? -1:this.allegationGroupId>allegation.getAllegationGroupId()?1:0;
	}
	
	
	
}
