/**
 * 
 */
package com.unisys.cwis.portal.mrp.service.impl;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.common.configuration.SecurityUtils;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.ReportingPersonDao;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.ReportingPersonService;

/**
 * @author IbrarAti
 *
 */
@Service("reportingPersonService")
@Transactional
public class ReportingPersonServiceImpl implements ReportingPersonService {

	@Autowired
	ReportingPersonDao reportingPersonDao;

	@Override
	public MRPUserAccount getReportingPerson(long userId) {
		MRPUserAccount user = reportingPersonDao.getReportingPerson(userId);
		return user;
		//return reportingPersonDao.getReportingPerson(userId);
		
	}

	@Override
	public MRPUserAccount saveReportingPerson(MRPUserAccount userAccount, PortalUserObject userObject) {
		MRPUserAccount reportingPerson = reportingPersonDao.findById(userAccount.getUserAccountId());
		if(!reportingPerson.getPassword().equals(userAccount.getPassword())){
			SecurityUtils securityUtils = new SecurityUtils();
			String encryptedPassword = securityUtils.encryptText(userAccount.getPassword());
			userAccount.setPassword(encryptedPassword);
		}
		/*else{
			userAccount.setPasswordChanged(true);
		}
		if(userAccount.getPasswordChanged()){
			SecurityUtils securityUtils = new SecurityUtils();
			String encryptedPassword = securityUtils.encryptText(userAccount.getPassword());
			userAccount.setPassword(encryptedPassword);
		}	*/	
		userAccount.setModifiedBy(userObject.getUserName());
		userAccount.setModifiedDate(new Date());
		//userAccount.setComplaints(null);
		return reportingPersonDao.saveReportingPerson(userAccount);
	}

	@Override
	public Complaint createComplaint(long userId) {
		
		return reportingPersonDao.createComplaint(userId);
	}
	
	

}
