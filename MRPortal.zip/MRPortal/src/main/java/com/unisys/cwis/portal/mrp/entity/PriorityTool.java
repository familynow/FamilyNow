package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the PRIORITY_TOOL database table.
 * 
 */
@Entity
@Table(name = "PRIORITY_TOOL")
@NamedQuery(name = "PriorityTool.findAll", query = "SELECT p FROM PriorityTool p")
public class PriorityTool implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRIORITY_TOOL_ID_SEQ")
	@SequenceGenerator(name = "PRIORITY_TOOL_ID_SEQ", sequenceName = "PRIORITY_TOOL_ID_SEQ", allocationSize = 1)
	@Column(name = "PRIORITY_TOOL_ID", unique = true, nullable = false)
	private long priorityToolId;

	@Column(name = "PRIORITY_ALLEGATION_CATEGORY")
	private String priorityAllegationCategory;

	@Column(name = "ALLEGATION_DESCRIPTION_TEXT")
	private String allegationDescriptionText;

	@Column(name = "PRIORITY_TOOL_NAME")
	private String priorityToolName;

	@Column(name = "PRIORITY_ENTERED_BY")
	private String priorityEnteredBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "PRIORITY_START_DATE")
	private Date priorityStartDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "PRIORITY_END_DATE")
	private Date priorityEndDate;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	 

	// bi-directional many-to-one association to PriorityList
	@OneToMany(mappedBy = "priorityTool", fetch=FetchType.EAGER)
	private List<PriorityList> priorityLists;

	public PriorityTool() {
	}

	public long getPriorityToolId() {
		return this.priorityToolId;
	}

	public void setPriorityToolId(long priorityToolId) {
		this.priorityToolId = priorityToolId;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getPriorityAllegationCategory() {
		return this.priorityAllegationCategory;
	}

	public void setPriorityAllegationCategory(String priorityAllegationCategory) {
		this.priorityAllegationCategory = priorityAllegationCategory;
	}

	public Date getPriorityEndDate() {
		return this.priorityEndDate;
	}

	public void setPriorityEndDate(Date priorityEndDate) {
		this.priorityEndDate = priorityEndDate;
	}

	public String getPriorityEnteredBy() {
		return this.priorityEnteredBy;
	}

	public void setPriorityEnteredBy(String priorityEnteredBy) {
		this.priorityEnteredBy = priorityEnteredBy;
	}

	public Date getPriorityStartDate() {
		return this.priorityStartDate;
	}

	public void setPriorityStartDate(Date priorityStartDate) {
		this.priorityStartDate = priorityStartDate;
	}

	public String getPriorityToolName() {
		return this.priorityToolName;
	}

	public void setPriorityToolName(String priorityToolName) {
		this.priorityToolName = priorityToolName;
	}

	/*
	 * public List<Priority> getPriorities() { return this.priorities; }
	 * 
	 * public void setPriorities(List<Priority> priorities) { this.priorities =
	 * priorities; }
	 * 
	 * public Priority addPriority(Priority priority) {
	 * getPriorities().add(priority); priority.setPriorityTool(this);
	 * 
	 * return priority; }
	 * 
	 * public Priority removePriority(Priority priority) {
	 * getPriorities().remove(priority); priority.setPriorityTool(null);
	 * 
	 * return priority; }
	 */

	public String getAllegationDescriptionText() {
		return allegationDescriptionText;
	}

	public void setAllegationDescriptionText(String allegationDescriptionText) {
		this.allegationDescriptionText = allegationDescriptionText;
	}

	public List<PriorityList> getPriorityLists() {
		return this.priorityLists;
	}

	public void setPriorityLists(List<PriorityList> priorityLists) {
		this.priorityLists = priorityLists;
	}

	public PriorityList addPriorityList(PriorityList priorityList) {
		getPriorityLists().add(priorityList);
		//priorityList.setPriorityTool(this);

		return priorityList;
	}

	public PriorityList removePriorityList(PriorityList priorityList) {
		getPriorityLists().remove(priorityList);
		//priorityList.setPriorityTool(null);

		return priorityList;
	}

}