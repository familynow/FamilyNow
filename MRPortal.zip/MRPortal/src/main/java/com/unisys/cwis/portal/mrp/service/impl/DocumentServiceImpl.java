package com.unisys.cwis.portal.mrp.service.impl;

import java.math.BigDecimal;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.util.Date;
import java.util.List;

import javax.activation.MimeType;
import javax.activation.MimetypesFileTypeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.gridfs.GridFSDBFile;
import com.unisys.cwis.portal.mrp.dao.DocumentDao;
import com.unisys.cwis.portal.mrp.entity.DocumentOutput;
import com.unisys.cwis.portal.mrp.service.DocumentService;

@Service("documentService")
@Transactional
public class DocumentServiceImpl implements DocumentService {
	
	@Autowired
	DocumentDao documentDao;

	@Override
	public String uploadDocumentToMongoDB(MultipartFile file) {


		String objectId = documentDao.saveDocumentsInMongo(file);
		if (objectId != null)
			System.out.println();//log.info("Document Stored Successfully | Document ID : " + objectId);
		else
			System.out.println();//log.info("Opps...something wrong in storing document ");
		// we need to store file in mongoDB and get their object ID.		

		return objectId;
	
	}

	@Override
	public List<DocumentOutput> getDocumentList(long complaintId) {
		return documentDao.getDocumentList(complaintId);
	}

	@Override
	public DocumentOutput saveDocumentDetailAndUploadFile(DocumentOutput documentOutput,
			MultipartFile file) {
		documentOutput.setEcmGuid(uploadDocumentToMongoDB(file));
		documentDao.updateDocumentUploadStatus(documentOutput.getComplaintId(),"YES");
		return updateDocumentDetail(documentOutput);
		
	}

	@Override
	public boolean deleteDocumentDetail(long documentId) {
		DocumentOutput documentOutput = documentDao.findById(documentId);
		documentOutput.setMarkedForDeleteFlag(new BigDecimal(1));
		documentDao.save(documentOutput);
		return true;
	}
	
	/**
	 * This method is used to find Document by Id  
	 * 
	 * @param id
	 * @return GridFSDBFile
	 */
	@Override
	public GridFSDBFile getDocumentInputFileById(String id) {

		return documentDao.getDocumentById(id);
	}
	
	/**
	 * This method is used to find mime type of file 
	 * 
	 * 
	 * @param fileName
	 * @return contentType
	 */
	@Override
	public String getMimeTypeFromFileName(String fileName) {
		MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
		return fileTypeMap.getContentType(fileName);
	}

	@Override
	public DocumentOutput updateDocumentDetail(DocumentOutput documentOutput) {
		if(documentOutput.getDocumentId()<1){
			documentOutput.setCreatedBy("1");	
			documentOutput.setCreatedDate(new Date());
			documentOutput.setMarkedForDeleteFlag(new BigDecimal(0));
		}
		documentOutput.setModifiedBy("1");
		documentOutput.setModifiedDate(new Date());
		documentDao.save(documentOutput);
		return documentOutput;
	}

	@Override
	public boolean updateDocumentUploadStatus(long complaintId,
			String str) {
		documentDao.updateDocumentUploadStatus(complaintId,str);
		return true;
	}
	

}
