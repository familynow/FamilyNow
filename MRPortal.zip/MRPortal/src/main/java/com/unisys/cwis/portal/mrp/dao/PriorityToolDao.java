package com.unisys.cwis.portal.mrp.dao;

import java.util.List;

import com.unisys.cwis.portal.common.dao.GenericDAO;
import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

public interface PriorityToolDao extends GenericDAO<PriorityTool> {
	/**
	 * This method returns list of Priority Tools that can be run 
	 *
	 * @return List<PriorityRecord>
	 */
	public List<PriorityTool> getPriorityTools();

	/**
	 * This service returns QuestionaireForm with the questions to be displayed
	 * based on priorityToolId
	 * 
	 * @param priorityId
	 * @param priorityToolId
	 * @return List<QuestionaireRecord>
	 */
	public List<QuestionaireRecord> getQuestionaire(long priorityToolId);
	
	public void deleteSDMQuestions(long priorityToolId);
	
}
