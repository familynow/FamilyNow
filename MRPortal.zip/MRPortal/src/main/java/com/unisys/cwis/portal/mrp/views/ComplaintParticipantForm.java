package com.unisys.cwis.portal.mrp.views;

import java.util.List;

import com.unisys.cwis.portal.mrp.entity.ComplaintParticipant;

public class ComplaintParticipantForm {

	private ComplaintParticipant complaintParticipant;
	private List<ComplaintParticipant> listParticipant;

	public ComplaintParticipant getComplaintParticipant() {
		return complaintParticipant;
	}

	public void setComplaintParticipant(ComplaintParticipant complaintParticipant) {
		this.complaintParticipant = complaintParticipant;
	}

	public List<ComplaintParticipant> getListParticipant() {
		return listParticipant;
	}

	public void setListParticipant(List<ComplaintParticipant> listParticipant) {
		this.listParticipant = listParticipant;
	}
	
}
