package com.unisys.cwis.portal.mrp.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.ReportingPersonService;



@RestController
@RequestMapping("/reportingPerson")
public class ReportingPersonController {
	
	@Autowired
	ReportingPersonService reportingPersonService;
	
	/**
	 * This method is used to get the person profile from db based on user id
	 * @param reportingPersonId
	 * @return
	 */
	
	@RequestMapping(value = "/personProfile/{reportingPersonId}", method = RequestMethod.GET)
	public ResponseEntity<Object> getReportingPersonDetail(@PathVariable("reportingPersonId") String reportingPersonId){
		MRPUserAccount user = new MRPUserAccount();
		if(reportingPersonId==null || reportingPersonId.equals("undefined"))
			return new ResponseEntity<Object>(user,HttpStatus.OK);
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		if(userObject.isAdminFlag())
			user = reportingPersonService.getReportingPerson(Long.valueOf(reportingPersonId));
		else if(userObject.getUserId().equals(reportingPersonId))
			user = reportingPersonService.getReportingPerson(Long.valueOf(reportingPersonId));
		return new ResponseEntity<Object>(user,HttpStatus.OK);
	}
	
	/**
	 * This method is there to save the updated person profile to db
	 * @param reportingPerson
	 * @return
	 */
	@RequestMapping(value = "/saveReportingPersonDetail", method = RequestMethod.POST)
	public ResponseEntity<Object> createEditReportingPerson(@RequestBody MRPUserAccount reportingPerson){
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		MRPUserAccount account = new MRPUserAccount();
		if(!userObject.isAdminFlag()){
			if(userObject.getUserId().equalsIgnoreCase(reportingPerson.getUserAccountId()+"")){
				account = reportingPersonService.saveReportingPerson(reportingPerson,userObject);
			}
		}else
			account = reportingPersonService.saveReportingPerson(reportingPerson,userObject);
		return new ResponseEntity<Object>(account,HttpStatus.OK);
	}
	
	/**
	 * This method is responsible to save a person's details and to create a complaint on behalf of the reporting person
	 * @param reportingPerson
	 * @return
	 */
	@RequestMapping(value = "/updatePersonAndCreateComplaint", method = RequestMethod.POST)
	public ResponseEntity<Map<String,Object>> updatePersonAndCreateComplaint(@RequestBody MRPUserAccount reportingPerson){
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		Complaint complaint = null;
		MRPUserAccount account = new MRPUserAccount();
		if(!userObject.isAdminFlag()){
			if(userObject.getUserId().equalsIgnoreCase(reportingPerson.getUserAccountId()+"")){
				account = reportingPersonService.saveReportingPerson(reportingPerson,userObject);
				complaint = reportingPersonService.createComplaint(account.getUserAccountId());
			}
		}else{
			account = reportingPersonService.saveReportingPerson(reportingPerson,userObject);
			complaint = reportingPersonService.createComplaint(account.getUserAccountId());
		}
		Map<String,Object> response = new HashMap<String, Object>();
		response.put("userAccount", account);
		response.put("complaint", complaint);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
}
