package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the DOCUMENT_OUTPUT database table.
 * 
 */
@Entity
@Table(name="DOCUMENT_OUTPUT")
@NamedQuery(name="DocumentOutput.findAll", query="SELECT d FROM DocumentOutput d")
public class DocumentOutput implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DOCUMENT_OUTPUT_ID_SEQ", sequenceName = "DOCUMENT_OUTPUT_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOCUMENT_OUTPUT_ID_SEQ")
	@Column(name="DOCUMENT_ID", unique=true, nullable=false)
	private long documentId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Temporal(TemporalType.DATE)
	@Column(name="DOCUMENT_DATE")
	private Date documentDate;

	@Column(name="DOCUMENT_NAME")
	private String documentName;

	@Column(name="DOCUMENT_TYPE_CODE")
	private String documentTypeCode;

	@Column(name="ECM_GUID")
	private String ecmGuid;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="OTHER_DOCUMENT_TYPE")
	private String otherDocumentType;
	
	@Column(name="UPLOADED_DOCUMENT_NAME")
	private String fileName;
	
	@Column(name="COMMENTS")
	private String comments;

	//bi-directional many-to-one association to Complaint
	@ManyToOne
	@JoinColumn(name="COMPLAINT_ID",insertable=false, updatable=false)
	@JsonBackReference
	private Complaint complaint;
	
	@Column(name="COMPLAINT_ID", nullable=false, insertable=true, updatable=true)
	private long complaintId;

	public DocumentOutput() {
	}

	public long getDocumentId() {
		return this.documentId;
	}

	public void setDocumentId(long documentId) {
		this.documentId = documentId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getDocumentDate() {
		return this.documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getDocumentName() {
		return this.documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentTypeCode() {
		return this.documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public String getEcmGuid() {
		return this.ecmGuid;
	}

	public void setEcmGuid(String ecmGuid) {
		this.ecmGuid = ecmGuid;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOtherDocumentType() {
		return this.otherDocumentType;
	}

	public void setOtherDocumentType(String otherDocumentType) {
		this.otherDocumentType = otherDocumentType;
	}

	public Complaint getComplaint() {
		return this.complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

	public long getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(long complaintId) {
		this.complaintId = complaintId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	

}