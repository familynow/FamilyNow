package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.unisys.cwis.portal.mrp.entity.MRPUserAccount;
import com.unisys.cwis.portal.common.util.MRPUtil;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.AllegationGroupService;
import com.unisys.cwis.portal.mrp.service.ComplaintParticipantService;
import com.unisys.cwis.portal.mrp.service.ComplaintService;
import com.unisys.cwis.portal.mrp.service.ReportingPersonService;
import com.unisys.cwis.portal.mrp.views.ComplaintDetails;
import com.unisys.cwis.portal.mrp.views.ComplaintParticipantForm;


@RestController
@RequestMapping("/complaintSummary")
public class ComplaintSummaryController {
	@Autowired
	private ComplaintService complaintService;
	@Autowired
	private AllegationGroupService allegationGroupService;
	@Autowired
	ReportingPersonService reportingPersonService;
	@Autowired
	private ComplaintParticipantService complaintParticipantService;
	private Logger logger = Logger.getLogger(ComplaintSummaryController.class.getName());
	
	/** 
	 * 
	 * @param complaintId
	 * @return
	 * This method saves a complaint which is in In Progress status and changes the status to Submitted
	 */
	@RequestMapping(value = "/saveComplaint/", method = RequestMethod.POST)
	public ResponseEntity<ComplaintDetails> saveComplaint(@RequestBody long complaintId) {
		logger.debug("complaintId - "+complaintId);
		Complaint complaint = complaintService.saveComplaint(complaintId);
		logger.debug("other service calls start - ");
		MRPUserAccount user = complaint.getUserAccount();
		ComplaintParticipantForm participants = complaintParticipantService.retrieveAllComplaintParticipants(complaintId);
		List<AllegationGroup> allegations = allegationGroupService.getAllegationDetails(complaintId);
		logger.debug("other service calls end - ");
		//MRPUtil.objectToXml(allegations);
		ComplaintDetails complaintDetails = new ComplaintDetails();
		complaintDetails.setComplaint(complaint);
		complaintDetails.setAllegations(allegations);
		user.setPassword(null);
		complaintDetails.setUserAccount(user);
		if(participants != null && participants.getListParticipant() != null){
			for(int i=0; i<participants.getListParticipant().size();i++){
				participants.getListParticipant().get(i).setComplaint(null);
			}
			complaintDetails.setListParticipant(participants.getListParticipant());
		}
		MRPUtil.objectToXml(complaintDetails);
		return new ResponseEntity<ComplaintDetails>(complaintDetails, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param complaintId
	 * @return
	 * This method saves a complaint which is in In Progress status and changes the status to Submitted
	 */
	@RequestMapping(value = "/updateIntakeToComplaint/", method = RequestMethod.POST)
	public ResponseEntity<Complaint> updateIntakeToComplaint(@RequestBody Complaint complaint) {
		complaint = complaintService.updateIntakeToComplaint(complaint);
		return new ResponseEntity<Complaint>(complaint, HttpStatus.OK);
	}
}
