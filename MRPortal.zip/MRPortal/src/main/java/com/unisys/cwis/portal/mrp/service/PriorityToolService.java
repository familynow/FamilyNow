package com.unisys.cwis.portal.mrp.service;

import java.util.List;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.views.QuestionaireForm;

public interface PriorityToolService {
	
	public List<PriorityTool> getPriorityTools();
	public QuestionaireForm getQuestionaire(long priorityToolId);
	public PriorityTool createSDMTool(PriorityTool priorityTool, PortalUserObject userObject);
	public PriorityTool getPriorityToolDetails(long priorityToolId);
	public void deleteSDMTool(long priorityToolId);
	public void deleteSDMQuestions(long priorityToolId);
}
