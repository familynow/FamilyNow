package com.unisys.cwis.portal.mrp.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.PriorityToolDao;
import com.unisys.cwis.portal.mrp.dao.SDMQuestionnaireDAO;
import com.unisys.cwis.portal.mrp.entity.PriorityList;
import com.unisys.cwis.portal.mrp.service.SDMQuestionnaireService;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

@Service("questionnaireService")
@Transactional
public class SDMQuestionnaireServiceImpl implements SDMQuestionnaireService{
	
	@Autowired
	SDMQuestionnaireDAO questionnaireDao;

	@Autowired
	PriorityToolDao priorityDao;
	
	public QuestionaireRecord createQuestion(QuestionaireRecord qustionDetails, PortalUserObject userObject){
		PriorityList priorityQuestion = new PriorityList();
		if(qustionDetails.getPriorityToolId() != null && !"".equals(qustionDetails.getPriorityToolId().trim())){
			
			if(qustionDetails.getQuestionNumber() != null && !"".equals(qustionDetails.getQuestionNumber().trim())){
				priorityQuestion.setPriorityQuestionNumber(qustionDetails.getQuestionNumber());
			}else{
				List<QuestionaireRecord> questionnaire= priorityDao.getQuestionaire(Long.parseLong(qustionDetails.getPriorityToolId()));
				long questionNnumber=1;
				if(questionnaire !=null && questionnaire.size()>0)
					questionNnumber=questionnaire.size()+1;
				priorityQuestion.setPriorityQuestionNumber(questionNnumber+"");
			}
			
			priorityQuestion.setPriorityToolId(qustionDetails.getPriorityToolId());
			//priorityQuestion.setPriorityToolId(priorityTool);
			priorityQuestion.setNoPriority(qustionDetails.getPriorityOnNo());
			priorityQuestion.setYesPriority(qustionDetails.getPriorityOnYes());
			priorityQuestion.setYesPriorityQuestionNumber(qustionDetails.getNextOnYes());
			priorityQuestion.setNoPriorityQuestionNumber(qustionDetails.getNextOnNo());
			
			if(qustionDetails.getPriorityListId()<=0){
				priorityQuestion.setCreatedBy(userObject.getUserId());
				priorityQuestion.setCreatedDate(new Date());
			}else{
				priorityQuestion.setCreatedBy(userObject.getUserId());
				priorityQuestion.setCreatedDate(new Date());
				priorityQuestion.setPriorityListId(qustionDetails.getPriorityListId());
			}
			
			priorityQuestion.setModifiedBy(userObject.getUserId());
			priorityQuestion.setModifiedDate(new Date());
			
			priorityQuestion.setQuestionDescriptionText(qustionDetails.getQuestionDesc());
			priorityQuestion.setPriorityQuestionText(qustionDetails.getQuestion());
			
			questionnaireDao.save(priorityQuestion);
			qustionDetails.setPriorityListId(priorityQuestion.getPriorityListId());
			qustionDetails.setQuestionNumber(priorityQuestion.getPriorityQuestionNumber());
			return qustionDetails;
		}
		return qustionDetails;
	}


	@Override
	public QuestionaireRecord getQuestionDetails(long questionId) {
		// TODO Auto-generated method stub
		PriorityList priorityList = questionnaireDao.getQuestionDetails(questionId);
		QuestionaireRecord record = new QuestionaireRecord();
		if(priorityList != null){
			record.setQuestion(priorityList.getPriorityQuestionText());
			record.setQuestionDesc(priorityList.getQuestionDescriptionText());
			record.setQuestionNumber(priorityList.getPriorityQuestionNumber());
			record.setPriorityListId(priorityList.getPriorityListId());
			record.setPriorityOnYes(priorityList.getYesPriority());
			record.setPriorityOnNo(priorityList.getNoPriority());
			record.setNextOnYes(priorityList.getYesPriorityQuestionNumber());
			record.setNextOnNo(priorityList.getNoPriorityQuestionNumber());
			record.setPriorityToolId(priorityList.getPriorityToolId()+"");
		}
		return record;
	}
}
