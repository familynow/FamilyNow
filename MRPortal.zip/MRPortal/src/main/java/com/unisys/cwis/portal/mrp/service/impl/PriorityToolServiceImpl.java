package com.unisys.cwis.portal.mrp.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.dao.PriorityToolDao;
import com.unisys.cwis.portal.mrp.entity.PriorityTool;
import com.unisys.cwis.portal.mrp.service.PriorityToolService;
import com.unisys.cwis.portal.mrp.views.QuestionaireForm;
import com.unisys.cwis.portal.mrp.views.QuestionaireRecord;

@Service("PriorityService")
@Transactional
public class PriorityToolServiceImpl implements PriorityToolService {

	@Autowired
	private PriorityToolDao priorityToolDao;
	private Logger log = Logger.getLogger(PriorityToolServiceImpl.class.getName());
	public List<PriorityTool> getPriorityTools() {
		List<PriorityTool> priorityRecords = priorityToolDao.getPriorityTools();
		return priorityRecords;
	}

	public PriorityTool getPriorityToolDetails(long priorityToolId) {
		PriorityTool priorityRecord = priorityToolDao.findById(priorityToolId);
		return priorityRecord;
	}
	
	public QuestionaireForm getQuestionaire(long priorityToolId) {
		QuestionaireForm questionaireForm = new QuestionaireForm();
		questionaireForm.setPriorityToolId(priorityToolId);
		List<QuestionaireRecord> questionaires = priorityToolDao.getQuestionaire(priorityToolId);
		questionaireForm.setQuestionaires(questionaires);
		return questionaireForm;
	}	
	
	public PriorityTool createSDMTool(PriorityTool priorityTool, PortalUserObject userObject){
		if(priorityTool.getPriorityToolId()<=0){
			priorityTool.setCreatedBy(userObject.getUserId());
			priorityTool.setCreatedDate(new Date());
		}
		priorityTool.setModifiedBy(userObject.getUserId());
		priorityTool.setModifiedDate(new Date());
		priorityTool.setPriorityEnteredBy(userObject.getName());
		priorityToolDao.save(priorityTool);
		return priorityTool;
	}

	@Override
	public void deleteSDMTool(long priorityToolId) {
		PriorityTool priorityRecord = priorityToolDao.findById(priorityToolId);
		priorityRecord.setPriorityEndDate(new Date());
		priorityToolDao.save(priorityRecord);
		//List<PriorityTool> priorityRecords = priorityToolDao.getPriorityTools();
		//return null;
	}

	@Override
	public void deleteSDMQuestions(long priorityToolId) {
		String deleteStatement="delete from priority_list where priority_tool_id="+priorityToolId;
		log.debug("deleting question ");
		//priorityToolDao.deleteSDMQuestions(priorityToolId);
		priorityToolDao.deleteBySQL(deleteStatement);
		/**
		 * Query query = session.createQuery("delete Category where id = :ID");
query.setParameter("ID", new Long(18));
 
int result = query.executeUpdate();
		 */
	}
}
