package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the COMPLAINT_REPORTER database table.
 * 
 */
@Entity
@Table(name="COMPLAINT_REPORTER")
@NamedQuery(name="ComplaintReporter.findAll", query="SELECT c FROM ComplaintReporter c")
public class ComplaintReporter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="COMPLAINT_REPORTER_ID")
	private long complaintReporterId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private BigDecimal markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="USER_ACCOUNT_ID")
	private BigDecimal userAccountId;

	public ComplaintReporter() {
	}

	public long getComplaintReporterId() {
		return this.complaintReporterId;
	}

	public void setComplaintReporterId(long complaintReporterId) {
		this.complaintReporterId = complaintReporterId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getMarkedForDeleteFlag() {
		return this.markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(BigDecimal markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public BigDecimal getUserAccountId() {
		return this.userAccountId;
	}

	public void setUserAccountId(BigDecimal userAccountId) {
		this.userAccountId = userAccountId;
	}

}