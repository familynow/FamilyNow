package com.unisys.cwis.portal.mrp.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.mrp.dao.ComplaintDao;
import com.unisys.cwis.portal.mrp.entity.Complaint;


@Repository("complaintDao")
public class ComplaintDaoImpl<T> extends GenericDAOImpl<Complaint> implements ComplaintDao {

	@Override
	public List<Complaint> getComplaintList(long userId) {
		Session session = this.getSession();
		Query query = session.createQuery("select c from Complaint c where c.userAccountId=:userId and c.markedForDeleteFlag=:flag");
		query.setBigDecimal("flag", new BigDecimal(0));
		query.setParameter("userId", userId);
		
		List<Complaint> list = query.list();
		session.clear();
		
		/*for(Complaint complaint:list){
			if(complaint.getAllegationGroups()!=null && complaint.getAllegationGroups().size()>0){
			Iterator<AllegationGroup> allIterator = complaint.getAllegationGroups().iterator();
				while(allIterator.hasNext()){
					AllegationGroup allGroup = allIterator.next();
					if(allGroup.getMarkedForDeleteFlag().equals(new Boolean(true))){
						allIterator.remove();
					}
				}
			}
		}*/
		
		return list;
	}

	@Override
	public boolean deleteComplaint(long complaintId) {
		Query query = this.getSession().createQuery("select c from Complaint c where c.complaintId=:complaintId").setParameter("complaintId", complaintId);
		Complaint complaint = (Complaint) query.uniqueResult();
		complaint.setMarkedForDeleteFlag(new BigDecimal(1));
		this.save(complaint);
		return true;
	}

	@Override
	public String getFeedbackType(long complaintId) {
		Query query = this.getSession().createQuery("select c from Complaint c where c.complaintId=:complaintId").setParameter("complaintId", complaintId);
		Complaint complaint = (Complaint) query.uniqueResult();
		return complaint.getFeedbackTypeCode();
	}

	@Override
	public void saveFeedbackType(long complaintId, String feedbackTypeCode) {
		Query query = this.getSession().createQuery("select c from Complaint c where c.complaintId=:complaintId").setParameter("complaintId", complaintId);
		Complaint complaint = (Complaint) query.uniqueResult();
		complaint.setFeedbackTypeCode(feedbackTypeCode);
		this.save(complaint);
	}

	@Override
	public void updateNarrativeFlag(long complaintId, BigDecimal flag) {
		Query query = this.getSession().createQuery("select c from Complaint c where c.complaintId=:complaintId").setParameter("complaintId", complaintId);
		Complaint complaint = (Complaint) query.uniqueResult();
		complaint.setNarrativeDataAvailableFlag(flag);
		this.save(complaint);		
	}

}
