package com.unisys.cwis.portal.mrp.dao.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.sql2o.Connection;

import com.unisys.cwis.portal.common.dao.RefDataDao;
import com.unisys.cwis.portal.common.dao.impl.GenericDAOImpl;
import com.unisys.cwis.portal.common.entity.RefData;
import com.unisys.cwis.portal.common.views.RefDataForm;



@Repository("refDataDao")
public class RefDataDaoImpl extends GenericDAOImpl<RefData> implements RefDataDao{

	private Logger log = Logger.getLogger(RefDataDaoImpl.class.getName());
	@Override
	public Set<String> getAllDomainCodes() {
		
		StringBuffer sqlCommand=new StringBuffer();
		sqlCommand.append("select unique domain_code from ref_data");
		Connection aConnection = getReadOnlyController();
		List<String> result = aConnection.createQuery(sqlCommand.toString()).throwOnMappingFailure(false).executeAndFetch(String.class);
		Set<String> set = new HashSet<String>(result);
		aConnection.close();
		return set;
	}
	public List<RefData> getRefDataBySearch(RefDataForm refDataForm){
		StringBuffer sqlCommand=new StringBuffer();
		sqlCommand.append("select REF_DATA_ID as refDataId, DOMAIN_CODE as domainCode, INACTIVE_FLAG as inactiveFlag,"
				+ " REF_DATA_CODE as refDataCode, SHORT_DESC as shortDesc, SORT_VALUE as sortValue from ref_data where ");
		if(refDataForm.getDomainCode() != null && !"".equals(refDataForm.getDomainCode().trim())){
			sqlCommand.append(" domain_code = '"+refDataForm.getDomainCode().trim()+"' and ");
		}
		if(refDataForm.getReferenceCode() != null && !"".equals(refDataForm.getReferenceCode().trim())){
			sqlCommand.append(" lower(REF_DATA_CODE) like '%"+refDataForm.getReferenceCode().trim().toLowerCase()+"%' and ");
		}
		if(refDataForm.getStatusCode() != null && !"".equals(refDataForm.getStatusCode().trim())){
			int flag=0;
			if("1".equalsIgnoreCase(refDataForm.getStatusCode().trim()))
				flag=1;
			sqlCommand.append(" INACTIVE_FLAG = "+flag+" and ");
		}
		if(refDataForm.getDisplayValue() != null && !"".equals(refDataForm.getDisplayValue().trim())){
			sqlCommand.append(" lower(SHORT_DESC) like '%"+refDataForm.getDisplayValue().trim().toLowerCase()+"%'");
		}
		sqlCommand.append("order by SORT_VALUE");
		// now we have to remove and before order by		
		String sql = sqlCommand.toString();	
		if(sql.contains("and order")){			
			sql= sql.replace(" and order", " order");
		}
		log.info("SQL: "+sql);
		Connection aConnection = getReadOnlyController();
		List<RefData> results = aConnection.createQuery(sql).throwOnMappingFailure(false).executeAndFetch(RefData.class);
		aConnection.close();
		return results;
	}
	public RefData getRefDataById(long refDataId){
		RefData refData = this.findById(refDataId);
		return refData;
	}
}
