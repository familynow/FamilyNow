package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;


/**
 * The persistent class for the PRIORITY_LIST database table.
 * 
 */
@Entity
@Table(name="PRIORITY_LIST")
@NamedQuery(name="PriorityList.findAll", query="SELECT p FROM PriorityList p")
public class PriorityList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id	
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PRIORITY_LIST_ID_SEQ")
	@SequenceGenerator(name="PRIORITY_LIST_ID_SEQ", sequenceName="PRIORITY_LIST_ID_SEQ", allocationSize=1)
	@Column(name="PRIORITY_LIST_ID", unique=true, nullable=false)
	private long priorityListId;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="LAST_PRIORITY_QUESTION_FLAG")
	private BigDecimal lastPriorityQuestionFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="NO_PRIORITY")
	private String noPriority;

	@Column(name="NO_PRIORITY_QUESTION_NUMBER")
	private String noPriorityQuestionNumber;

	@Column(name="PRIORITY_QUESTION_NUMBER")
	private String priorityQuestionNumber;

	@Column(name="PRIORITY_QUESTION_TEXT")
	private String priorityQuestionText;
	
	@Column(name="QUESTION_DESCRIPTION_TEXT")
	private String questionDescriptionText;

	@Column(name="YES_PRIORITY")
	private String yesPriority;

	@Column(name="YES_PRIORITY_QUESTION_NUMBER")
	private String yesPriorityQuestionNumber;

	//bi-directional many-to-one association to PriorityTool
	//@ManyToOne
	@Column(name="PRIORITY_TOOL_ID")
	private String priorityToolId;

	@ManyToOne
	@JoinColumn(name="PRIORITY_TOOL_ID",insertable=false, updatable=false)
	@JsonBackReference
	private PriorityTool priorityTool;
	/*//bi-directional many-to-one association to PriorityListResponse
	@OneToMany(mappedBy="priorityList")
	private List<PriorityListResponse> priorityListResponses;*/

	public PriorityList() {
	}

	public long getPriorityListId() {
		return this.priorityListId;
	}

	public void setPriorityListId(long priorityListId) {
		this.priorityListId = priorityListId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getLastPriorityQuestionFlag() {
		return this.lastPriorityQuestionFlag;
	}

	public void setLastPriorityQuestionFlag(BigDecimal lastPriorityQuestionFlag) {
		this.lastPriorityQuestionFlag = lastPriorityQuestionFlag;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getNoPriority() {
		return this.noPriority;
	}

	public void setNoPriority(String noPriority) {
		this.noPriority = noPriority;
	}

	public String getNoPriorityQuestionNumber() {
		return this.noPriorityQuestionNumber;
	}

	public void setNoPriorityQuestionNumber(String noPriorityQuestionNumber) {
		this.noPriorityQuestionNumber = noPriorityQuestionNumber;
	}

	public String getPriorityQuestionNumber() {
		return this.priorityQuestionNumber;
	}

	public void setPriorityQuestionNumber(String priorityQuestionNumber) {
		this.priorityQuestionNumber = priorityQuestionNumber;
	}

	public String getPriorityQuestionText() {
		return this.priorityQuestionText;
	}

	public void setPriorityQuestionText(String priorityQuestionText) {
		this.priorityQuestionText = priorityQuestionText;
	}

	public String getYesPriority() {
		return this.yesPriority;
	}

	public void setYesPriority(String yesPriority) {
		this.yesPriority = yesPriority;
	}

	public String getYesPriorityQuestionNumber() {
		return this.yesPriorityQuestionNumber;
	}

	public void setYesPriorityQuestionNumber(String yesPriorityQuestionNumber) {
		this.yesPriorityQuestionNumber = yesPriorityQuestionNumber;
	}

	/*public PriorityTool getPriorityTool() {
		return this.priorityTool;
	}

	public void setPriorityTool(PriorityTool priorityTool) {
		this.priorityTool = priorityTool;
	}*/

	public String getQuestionDescriptionText() {
		return questionDescriptionText;
	}

	

	public String getPriorityToolId() {
		return priorityToolId;
	}

	public void setPriorityToolId(String priorityToolId) {
		this.priorityToolId = priorityToolId;
	}

	public PriorityTool getPriorityTool() {
		return priorityTool;
	}

	public void setPriorityTool(PriorityTool priorityTool) {
		this.priorityTool = priorityTool;
	}

	public void setQuestionDescriptionText(String questionDescriptionText) {
		this.questionDescriptionText = questionDescriptionText;
	}

	/*public List<PriorityListResponse> getPriorityListResponses() {
		return this.priorityListResponses;
	}

	public void setPriorityListResponses(List<PriorityListResponse> priorityListResponses) {
		this.priorityListResponses = priorityListResponses;
	}

	public PriorityListResponse addPriorityListRespons(PriorityListResponse priorityListRespons) {
		getPriorityListResponses().add(priorityListRespons);
		priorityListRespons.setPriorityList(this);

		return priorityListRespons;
	}

	public PriorityListResponse removePriorityListRespons(PriorityListResponse priorityListRespons) {
		getPriorityListResponses().remove(priorityListRespons);
		priorityListRespons.setPriorityList(null);

		return priorityListRespons;
	}*/
	

}