package com.unisys.cwis.portal.mrp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unisys.cwis.portal.common.constant.MRPConstant;
import com.unisys.cwis.portal.common.views.ErrorMessage;
import com.unisys.cwis.portal.common.views.PortalUserObject;
import com.unisys.cwis.portal.mrp.entity.AllegationGroup;
import com.unisys.cwis.portal.mrp.service.AllegationGroupService;
import com.unisys.cwis.portal.mrp.views.AllegationGroupForm;
import com.unisys.cwis.portal.mrp.views.AllegationGroupRecord;
import com.unisys.cwis.portal.mrp.views.ComplaintPartResultRecord;

@RestController
@RequestMapping("/allegationGroup")
public class AllegationGroupController {
	@Autowired
	private AllegationGroupService allegationGroupService;
	private Logger log = Logger.getLogger(AllegationGroupController.class.getName());

	public AllegationGroupController() {
		log.info("Constructor AllegationGroupController");
	}

	/**
	 * This Service returns an AllegationGroupForm with allegedVictims and
	 * allgedPerpetrators based on complaintId and allegationGroupId
	 * 
	 * @param complaintId
	 * @param allegationGroupId
	 * @return AllegationGroupForm
	 */
	@RequestMapping(value = "/getAllegationParticipants/{complaintId}/{allegationGroupId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<AllegationGroupForm> getAllegationParticipants(@PathVariable("complaintId") long complaintId,
			@PathVariable("allegationGroupId") long allegationGroupId) {
		log.info("Inside AllegationGroupController getAllegationParticipants");
		AllegationGroupForm allegationGroupForm = allegationGroupService.getAllegationParticipants(complaintId,
				allegationGroupId);
		return new ResponseEntity<AllegationGroupForm>(allegationGroupForm, HttpStatus.OK);
	}

	/**
	 * This Service returns a List of AllegationGroupRecords based on complaintId
	 * 
	 * @param complaintId
	 * @return List<AllegationGroupRecord>
	 */
	@RequestMapping(value = "/retrieveAllegationGroups/{complaintId}", method = RequestMethod.GET)
	public ResponseEntity<List<AllegationGroupRecord>> retrieveAllegationGroups(
			@PathVariable("complaintId") long complaintId) {
		List<AllegationGroupRecord> results = allegationGroupService.retrieveAll(complaintId);
		return new ResponseEntity<List<AllegationGroupRecord>>(results, HttpStatus.OK);
	}

	/**
	 * This service is used to delete(Soft) an AllegationGroup based on
	 * allegationGroupId
	 * 
	 * @param allegationGroupId
	 * @return AllegationGroup
	 */
	@RequestMapping(value = "/deleteAllegationGroup/{allegationGroupId:[\\d]+}", method = RequestMethod.GET)
	public ResponseEntity<AllegationGroup> deleteAllegationGroup(
			@PathVariable("allegationGroupId") long allegationGroupId) {
			AllegationGroup allegationGroup = allegationGroupService.delete(allegationGroupId);
			return new ResponseEntity<AllegationGroup>(allegationGroup, HttpStatus.OK);
		
			/*ErrorReporter errorReporter = new ErrorReporter();
			ErrorMessage errorMessage = new ErrorMessage();
			errorMessage.setErrorMessage("Priority tool has already been run for the allegation. Deletion not allowed.");
			errorReporter.addErrorMessage(errorMessage);
			return new ResponseEntity<Object>(errorReporter, HttpStatus.OK);*/
				
	}

	/**
	 * This service is used to save the Allegation and AllegationGroup details
	 * to DB
	 * 
	 * @param allegationGroupForm
	 * @return Object
	 */
	@RequestMapping(value = "/saveAllegationGroup/", method = RequestMethod.POST)
	public ResponseEntity<Object> saveAllegationGroup(@RequestBody AllegationGroupForm allegationGroupForm) {
		Boolean allegationExist = false;
		for (ComplaintPartResultRecord allegedVictim : allegationGroupForm.getAllegedVictims()) {
			if (allegedVictim.getSelected()) {
				for (ComplaintPartResultRecord allegedPerpetrator : allegationGroupForm.getAllegedPerpetrators()) {
					if (allegedPerpetrator.getSelected()) {
						allegationExist = allegationGroupService.checkForDuplicateAllegation(
								allegationGroupForm.getComplaintId(), allegationGroupForm.getAllegationGroupId(),
								allegationGroupForm.getAllegationType(), allegedVictim.getParticipantId(),
								allegedPerpetrator.getParticipantId());
						if (allegationExist) {
							ErrorMessage errorMessage = new ErrorMessage();
							errorMessage.setErrorCode("Error");
							errorMessage.setErrorType("error");
							errorMessage.setErrorMessage("Duplicate entry of Allegation for same pair of Perpetrator and Victim cannot be created");
							return new ResponseEntity<Object>(errorMessage, HttpStatus.OK);
						}
					}
				}
			}
		}
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		PortalUserObject userObject = (PortalUserObject) session.getAttribute(MRPConstant.SESSION_USER_OBJECT);
		allegationGroupService.save(allegationGroupForm,userObject);
		return new ResponseEntity<Object>(allegationGroupForm, HttpStatus.OK);
	}
	/**
	 * This service is used to save the Allegation Notes
	 * to DB
	 * 
	 * @param allegationGroupForm
	 * @return Object
	 */
	@RequestMapping(value = "/saveNarrative/", method = RequestMethod.POST)
	public ResponseEntity<Object> saveNarrative(@RequestBody AllegationGroupForm allegationGroupForm) {
		allegationGroupService.saveNarrative(allegationGroupForm);
		return new ResponseEntity<Object>(allegationGroupForm, HttpStatus.OK);
	}

}
