package com.unisys.cwis.portal.mrp.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.unisys.cwis.portal.mrp.dao.ComplaintDao;
import com.unisys.cwis.portal.mrp.entity.Complaint;
import com.unisys.cwis.portal.mrp.service.ComplaintService;

@Service("complaintService")	
@Transactional
public class ComplaintServiceImpl implements ComplaintService{

	@Autowired
    private ComplaintDao complaintDao;
	

	/**
	 * This method saves a complaint which is in In Progress status and changes the status to Submitted
	 */
	@Override
	public Complaint saveComplaint(long complaintId) {
		Complaint complaint = complaintDao.findById(complaintId);
		complaint.setComplaintStatus("SUBMITTED");
		complaint.setSubmittedDate(new Date());
		complaintDao.save(complaint);
		return complaint;
	}

	/**
	 * This method retrieves the list of complaints created by a particular user
	 */
	@Override
	public List<Complaint> getComplaintList(long userId) {
		
		return complaintDao.getComplaintList(userId);
		
	}

	/**
	 * This method deletes a complaint which is in In Progress status
	 */
	@Override
	public boolean deletecomplaint(long complaintId) {
		complaintDao.deleteComplaint(complaintId );
		return true;
	}

	@Override
	public Complaint updateIntakeToComplaint(Complaint complaint) {
		long intakeId=complaint.getIntakeId();
		complaint = complaintDao.findById(complaint.getComplaintId());
		if(intakeId>0)
			complaint.setSynchedWithIntake(1);
		
		complaintDao.save(complaint);
		return complaint;
	}

}
