package com.unisys.cwis.portal.mrp.views;

import java.util.Date;

public class ComplaintPartResultRecord {

	long participantId;
	String participantName;	
	String	gender;
	String	role;
	Boolean intakeName;
	Boolean unknown;
	long personId;
	Date birthDate;
	String raceCode;
	String age;	
	String allegations;
	Boolean selected;
	
	boolean associatedPerson;
	boolean caseMember;
	
	public long getParticipantId() {
		return participantId;
	}
	public void setParticipantId(long participantId) {
		this.participantId = participantId;
	}	
	public String getParticipantName() {
		return participantName;
	}
	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Boolean getIntakeName() {
		return intakeName;
	}
	public void setIntakeName(Boolean intakeName) {
		this.intakeName = intakeName;
	}
	public Boolean getUnknown() {
		return unknown;
	}
	public void setUnknown(Boolean unknown) {
		this.unknown = unknown;
	}
	public long getPersonId() {
		return personId;
	}
	public void setPersonId(long personId) {
		this.personId = personId;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getRaceCode() {
		return raceCode;
	}
	public void setRace(String raceCode) {
		this.raceCode = raceCode;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}	
	public String getAllegations() {
		return allegations;
	}
	public void setAllegations(String allegations) {
		this.allegations = allegations;
	}
	public Boolean getSelected() {
		return selected;
	}
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
	public boolean isAssociatedPerson() {
		return associatedPerson;
	}
	public void setAssociatedPerson(boolean associatedPerson) {
		this.associatedPerson = associatedPerson;
	}
	public boolean isCaseMember() {
		return caseMember;
	}
	public void setCaseMember(boolean caseMember) {
		this.caseMember = caseMember;
	}
	public void setRaceCode(String raceCode) {
		this.raceCode = raceCode;
	}	
	
}
