package com.unisys.cwis.portal.mrp.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;


/**
 * The persistent class for the ALLEGATION_GROUP database table.
 * 
 */
@Entity
@Table(name="ALLEGATION_GROUP")
@NamedQuery(name="AllegationGroup.findAll", query="SELECT a FROM AllegationGroup a")
public class AllegationGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ALLEGATION_GROUP_ID_SEQ_GENERATOR", sequenceName="ALLEGATION_GROUP_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ALLEGATION_GROUP_ID_SEQ_GENERATOR")
	@Column(name="ALLEGATION_GROUP_ID", unique=true, nullable=false)
	private long allegationGroupId;

	@Column(name="ALLEGATION_NOTES")
	private String allegationNotes;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="MARKED_FOR_DELETE_FLAG")
	private Boolean markedForDeleteFlag;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	//bi-directional many-to-one association to Allegation
	@OneToMany(mappedBy="allegationGroup",fetch = FetchType.EAGER,cascade = CascadeType.ALL)	
	private Set<Allegation> allegations = new HashSet<Allegation>();	

	//bi-directional many-to-one association to Complaint
	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "COMPLAINT_ID", referencedColumnName = "COMPLAINT_ID", insertable = true, updatable = false)
	@JsonBackReference
	private Complaint complaint;

	public AllegationGroup() {
	}

	public long getAllegationGroupId() {
		return this.allegationGroupId;
	}

	public void setAllegationGroupId(long allegationGroupId) {
		this.allegationGroupId = allegationGroupId;
	}

	public String getAllegationNotes() {
		return this.allegationNotes;
	}

	public void setAllegationNotes(String allegationNotes) {
		this.allegationNotes = allegationNotes;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Boolean getMarkedForDeleteFlag() {
		return markedForDeleteFlag;
	}

	public void setMarkedForDeleteFlag(Boolean markedForDeleteFlag) {
		this.markedForDeleteFlag = markedForDeleteFlag;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Set<Allegation> getAllegations() {
		return this.allegations;
	}

	public void setAllegations(Set<Allegation> allegations) {
		this.allegations = allegations;
	}

	public Allegation addAllegation(Allegation allegation) {
		getAllegations().add(allegation);
		allegation.setAllegationGroup(this);

		return allegation;
	}

	public Allegation removeAllegation(Allegation allegation) {
		getAllegations().remove(allegation);
		allegation.setAllegationGroup(null);

		return allegation;
	}

	public Complaint getComplaint() {
		return this.complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

}